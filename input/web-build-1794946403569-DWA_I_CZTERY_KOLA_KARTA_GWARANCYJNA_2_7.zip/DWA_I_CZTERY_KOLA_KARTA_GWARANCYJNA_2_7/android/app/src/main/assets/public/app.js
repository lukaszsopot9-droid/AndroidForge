const PROJECT_URL="https://xyayfisbuyfqsbumdiax.supabase.co";
const $=id=>document.getElementById(id);
let sb=null, repairs=[], clients=[], vehicles=[], activeEdit=null;
const show=(id,on)=>$(id).classList.toggle("hidden",!on);
function toast(s){$("toast").textContent=s;$("toast").style.display="block";setTimeout(()=>$("toast").style.display="none",3500)}
// Aktualizacje aplikacji Android — manifest i APK są publikowane na stronie WWW.
const UPDATE_MANIFEST_URL="https://dwaiczterykola.pl/pobierz/pliki/latest.json";
let availableAppUpdate=null;
let updateOperationRunning=false;
let updateCheckRunning=false;
let updateDownloadRunning=false;
function getAppUpdater(){
  if(!window.Capacitor?.isNativePlatform?.() || !window.Capacitor?.registerPlugin) return null;
  return window.Capacitor.registerPlugin("AppUpdater");
}
function setUpdateStatus(message){
  const el=$("appUpdateStatus");
  if(el) el.textContent=message;
}
async function checkForAppUpdate(manual=false){
  if(updateCheckRunning || updateOperationRunning) return;
  updateCheckRunning=true;
  const checkButton=$("checkAppUpdateButton");
  if(manual && checkButton){checkButton.disabled=true;checkButton.textContent="Sprawdzanie…";}
  try{
    const updater=getAppUpdater();
    if(!updater) throw new Error("Aktualizacje są dostępne w aplikacji Android.");
    const [appInfo,response]=await Promise.all([
      updater.getAppInfo(),
      fetch(UPDATE_MANIFEST_URL+"?t="+Date.now(),{cache:"no-store"})
    ]);
    if(!response.ok) throw new Error("Serwer aktualizacji zwrócił HTTP "+response.status+".");
    const manifest=await response.json();
    const remoteCode=Number(manifest.versionCode);
    if(!Number.isInteger(remoteCode) || remoteCode<1 || !manifest.apkUrl || !/^https:\/\//i.test(manifest.apkUrl))
      throw new Error("Plik latest.json ma nieprawidłowy format (wymagane versionCode i apkUrl).");
    const localCode=Number(appInfo.versionCode||0);
    if(remoteCode<=localCode){
      availableAppUpdate=null;
      $("appUpdateNotice")?.classList.add("hidden");
      if(manual) toast("Masz aktualną wersję aplikacji.");
      return;
    }
    availableAppUpdate=manifest;
    $("appUpdateVersion").textContent="Dostępna wersja "+(manifest.versionName||remoteCode);
    $("appUpdateNotes").textContent=manifest.changelog||manifest.releaseNotes||"Dostępna jest nowa wersja aplikacji.";
    $("appUpdateNotice").classList.remove("hidden");
    const status=await updater.getDownloadStatus();
    if(status.status==="successful"){
      setUpdateStatus("Plik APK jest już w folderze Pobrane. Możesz rozpocząć instalację.");
      $("updateAppButton").textContent="Zainstaluj pobraną aktualizację";
    }else if(status.status==="pending" || status.status==="running"){
      setUpdateStatus("Pobieranie APK do folderu Pobrane trwa w tle…");
      $("updateAppButton").textContent="Sprawdź pobieranie i zainstaluj";
    }else if(!updateDownloadRunning){
      updateDownloadRunning=true;
      setUpdateStatus("Wykryto nową wersję. Pobieram APK do folderu Pobrane…");
      $("updateAppButton").textContent="Ponów pobieranie";
      try{
        const queued=await updater.downloadUpdate({url:manifest.apkUrl});
        setUpdateStatus("Pobieranie rozpoczęte. Plik zostanie zapisany w folderze Pobrane ("+(queued.fileName||"APK")+").");
      }catch(downloadError){
        setUpdateStatus("Nie udało się rozpocząć pobierania: "+(downloadError.message||"błąd Androida"));
      }finally{updateDownloadRunning=false;}
    }
    if(manual) toast("Znaleziono aktualizację "+(manifest.versionName||remoteCode)+".");
  }catch(error){
    console.warn("Sprawdzanie aktualizacji:",error);
    if(manual) toast("Nie udało się sprawdzić aktualizacji: "+(error.message||error));
    setUpdateStatus(error.message||"Nie udało się sprawdzić aktualizacji.");
  }finally{
    updateCheckRunning=false;
    if(manual && checkButton){checkButton.disabled=false;checkButton.textContent="Sprawdź aktualizacje";}
  }
}
async function installAvailableAppUpdate(){
  if(updateOperationRunning) return;
  if(!availableAppUpdate){await checkForAppUpdate(true);if(!availableAppUpdate)return;}
  const updater=getAppUpdater();
  if(!updater) return;
  updateOperationRunning=true;
  const button=$("updateAppButton");
  button.disabled=true;
  try{
    let status=await updater.getDownloadStatus();
    if(status.status!=="successful"){
      if(status.status!=="pending" && status.status!=="running"){
        setUpdateStatus("Uruchamiam pobieranie APK do folderu Pobrane…");
        await updater.downloadUpdate({url:availableAppUpdate.apkUrl});
      }else setUpdateStatus("Pobieranie APK trwa. Czekaj…");
      let finished=false;
      for(let i=0;i<300;i++){
        await new Promise(resolve=>setTimeout(resolve,1000));
        status=await updater.getDownloadStatus();
        if(status.status==="successful"){finished=true;break;}
        if(status.status==="failed") throw new Error(status.error||"Android nie ukończył pobierania APK.");
        setUpdateStatus("Pobieranie APK do folderu Pobrane…");
      }
      if(!finished) throw new Error("Pobieranie trwa zbyt długo. Sprawdź internet i folder Pobrane.");
    }
    setUpdateStatus("APK zapisany w folderze Pobrane. Otwieram instalator Androida…");
    const result=await updater.installDownloadedUpdate();
    if(result.needsPermission){
      setUpdateStatus("Zezwól aplikacji na instalowanie nieznanych aplikacji w ustawieniach Androida. Wróć tutaj i naciśnij przycisk ponownie.");
      button.textContent="Zainstaluj pobraną aktualizację";
    }else{
      setUpdateStatus("Potwierdź aktualizację w systemowym oknie Androida.");
      button.textContent="Otwórz instalator ponownie";
    }
  }catch(error){
    setUpdateStatus(error.message||"Nie udało się zaktualizować aplikacji.");
  }finally{
    button.disabled=false;
    updateOperationRunning=false;
  }
}
function init(){const key=localStorage.getItem("dk_publishable");if(!key){show("setup",true);return}sb=window.supabase.createClient(PROJECT_URL,key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});sb.auth.onAuthStateChange((_e,session)=>{if(session){show("login",false);show("setup",false);show("app",true);show("logout",true);loadAll()}else{show("app",false);show("logout",false);show("login",true)}});sb.auth.getSession().then(({data})=>{if(data.session){show("app",true);show("logout",true);loadAll()}else show("login",true)})}
$("saveConfig").onclick=()=>{const k=$("apiKey").value.trim();if(!k.startsWith("sb_publishable_")){toast("Wpisz klucz sb_publishable.");return}localStorage.setItem("dk_publishable",k);location.reload()};
$("signIn").onclick=async()=>{ $("loginMsg").textContent="Logowanie…";const {error}=await sb.auth.signInWithPassword({email:$("email").value.trim(),password:$("password").value});$("loginMsg").textContent=error?error.message:"Zalogowano."};
$("logout").onclick=async()=>{await sb.auth.signOut()};
$("refresh").onclick=loadAll;
async function loadAll(){ $("statusLine").textContent="Pobieranie danych z chmury…";try{const [a,b,c]=await Promise.all([sb.from("naprawy").select("*").order("created_at",{ascending:false}).limit(500),sb.from("klienci").select("*").order("id").limit(500),sb.from("pojazdy").select("*").order("id").limit(500)]);for(const r of [a,b,c])if(r.error)throw r.error;repairs=a.data||[];clients=b.data||[];vehicles=c.data||[];render();$("statusLine").textContent=`Połączono • ${repairs.length} napraw • ${clients.length} klientów`;}catch(e){$("statusLine").textContent="Błąd pobierania danych";toast(e.message)}}
function card(title,sub,meta,click){const d=document.createElement("article");d.className="item";d.innerHTML=`<strong></strong><p></p><span class="pill"></span>`;d.querySelector("strong").textContent=title||"—";d.querySelector("p").textContent=sub||"";d.querySelector("span").textContent=meta||"";if(click)d.onclick=click;return d}
function normalizeSearch(value){
  return String(value??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[\s-]/g,"");
}
function render(){
  const q=normalizeSearch($("searchRepairs").value);
  const isCompletedRepair = repair => ["wydanoklientowi","wydanyklientowi","rezygnacjaznaprawy"].includes(normalizeSearch(repair.status));
  $("repairList").replaceChildren(...repairs.filter(x=>!isCompletedRepair(x)&&[x.numer_protokolu,x.numer,x.klient,x.pojazd,x.rejestracja].some(v=>normalizeSearch(v).includes(q))).map(repairCard));
  const completedQuery=normalizeSearch($("searchCompleted").value);
  $("completedRepairList").replaceChildren(...repairs.filter(isCompletedRepair).filter(x=>[x.numer_protokolu,x.numer,x.klient,x.pojazd,x.rejestracja].some(v=>normalizeSearch(v).includes(completedQuery))).map(repairCard));
  const cq=normalizeSearch($("searchClients").value);
  $("clientList").replaceChildren(...clients.filter(client=>{
    const clientId=String(client.id??"");
    const clientName=normalizeSearch(client.imie_nazwisko);
    const clientVehicles=vehicles.filter(vehicle=>String(vehicle.klient_id??"")===clientId);
    const clientRepairs=repairs.filter(repair=>
      (repair.klient_id!=null && String(repair.klient_id)===clientId) ||
      (clientName && normalizeSearch(repair.klient)===clientName) ||
      clientVehicles.some(vehicle=>vehicle.id!=null && repair.pojazd_id!=null && String(repair.pojazd_id)===String(vehicle.id))
    );
    const searchable=[
      client.imie_nazwisko,client.telefon,client.email,client.miasto,
      ...clientVehicles.flatMap(vehicle=>[vehicle.rejestracja,vehicle.vin,vehicle.marka_model,vehicle.marka,vehicle.model]),
      ...clientRepairs.flatMap(repair=>[repair.rejestracja,repair.vin,repair.pojazd,repair.klient])
    ].map(normalizeSearch).join(" ");
    return searchable.includes(cq);
  }).map(clientCard));
  const vq=normalizeSearch($("searchVehicles").value);
  $("vehicleList").replaceChildren(...vehicles.filter(x=>normalizeSearch(`${x.marka_model||x.marka+" "+x.model} ${x.rejestracja} ${x.vin}`).includes(vq)).map(vehicleCard));
  renderStats();
}
async function sendRepairLocationSms(repair,button){
  const phone=String(repair.telefon||"").trim();
  if(!phone){toast("Wpisz numer telefonu klienta w zleceniu.");return;}
  const mapsUrl="https://www.google.com/maps/dir/?api=1&destination=To%C5%82stoja+5B%2C+42-600+Tarnowskie+G%C3%B3ry&travelmode=driving";
  const message="DWA I CZTERY KOŁA – zapraszamy do naszego serwisu!\nAdres: ul. Tołstoja 5B, 42-600 Tarnowskie Góry.\nNawigacja Google Maps: "+mapsUrl;
  const old=button.textContent;button.disabled=true;button.textContent="Otwieranie SMS…";
  try{await sendStatusSms(phone,message);toast("Otworzono wysyłanie SMS z lokalizacją.");}
  catch(error){toast("Nie udało się otworzyć SMS: "+(error.message||error));}
  finally{button.disabled=false;button.textContent=old;}
}
async function openRepairQr(repair,button){
  if(!repair.id){toast("Najpierw zapisz zlecenie.");return;}
  if(!window.QRCode){toast("Nie załadowała się biblioteka QR. Sprawdź internet.");return;}
  const old=button.textContent;button.disabled=true;button.textContent="Tworzenie kodu QR…";
  try{
    const {data:{session}}=await sb.auth.getSession();
    if(!session)throw new Error("Sesja wygasła. Zaloguj się ponownie.");
    const response=await fetch(PROJECT_URL+"/functions/v1/klient-qr",{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+session.access_token,"apikey":localStorage.getItem("dk_publishable")},body:JSON.stringify({action:"create",repair_id:repair.id})});
    const result=await response.json();
    if(!response.ok)throw new Error(result.error||"Nie udało się utworzyć linku.");
    if(!result.url)throw new Error("Serwer nie zwrócił adresu podglądu.");
    const overlay=document.createElement("div");
    overlay.style.cssText="position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,.78);display:flex;align-items:center;justify-content:center;padding:18px;";
    const panel=document.createElement("div");
    panel.style.cssText="width:min(420px,100%);max-height:90vh;overflow:auto;background:#10243a;color:#eef5ff;border:1px solid #36516d;border-radius:18px;padding:20px;text-align:center;";
    const heading=document.createElement("h2");heading.textContent="Kod QR dla klienta";
    const description=document.createElement("p");description.textContent="Klient może zeskanować kod, aby sprawdzić status zlecenia.";
    const qrHost=document.createElement("div");qrHost.style.cssText="display:flex;justify-content:center;background:#fff;padding:12px;border-radius:10px;margin:14px auto;width:max-content;max-width:100%;";
    new QRCode(qrHost,{text:result.url,width:240,height:240,colorDark:"#101b2b",colorLight:"#ffffff",correctLevel:QRCode.CorrectLevel.M});
    const link=document.createElement("p");link.textContent=result.url;link.style.cssText="overflow-wrap:anywhere;font-size:12px;";
    const actions=document.createElement("div");actions.style.cssText="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:14px;";
    const makeButton=(label,fn)=>{const b=document.createElement("button");b.type="button";b.className="secondary";b.textContent=label;b.onclick=fn;actions.appendChild(b);return b;};
    makeButton("Kopiuj link",async()=>{try{await navigator.clipboard.writeText(result.url);toast("Skopiowano link klienta.");}catch(_){toast("Nie udało się skopiować linku.");}});
    makeButton("Drukuj QR",()=>{const w=window.open("","_blank");if(!w){toast("Zezwól na wyskakujące okna, aby wydrukować QR.");return;}w.document.write("<html><head><title>Kod QR — zlecenie</title><style>body{font-family:Arial;text-align:center;padding:30px}img{width:260px;height:260px}</style></head><body><h2>DWA I CZTERY KOŁA</h2><p>Zeskanuj kod, aby sprawdzić status zlecenia</p>"+qrHost.innerHTML+"<p>"+result.url+"</p></body></html>");w.document.close();w.focus();w.print();});
    makeButton("Zamknij",()=>overlay.remove());
    panel.append(heading,description,qrHost,link,actions);overlay.appendChild(panel);
    overlay.addEventListener("click",e=>{if(e.target===overlay)overlay.remove();});
    document.body.appendChild(overlay);
    toast("Bezpieczny link klienta utworzony.");
  }catch(error){toast("QR: "+(error.message||error));}
  finally{button.disabled=false;button.textContent=old;}
}
function repairCard(repair){
  const item=card(repair.numer_protokolu||repair.numer||"Naprawa",`${repair.klient||""} • ${repair.pojazd||""} • ${repair.rejestracja||""}`,repair.status||"—",()=>editRepair(repair));
  const printButton=document.createElement("button");
  printButton.type="button";
  printButton.className="secondary";
  printButton.textContent="🖨️ Drukuj / PDF";
  printButton.style.cssText="margin-top:10px;width:100%;";
  printButton.onclick=async e=>{
    e.stopPropagation();
    if(printButton.disabled)return;
    try{
      printButton.disabled=true;
      printButton.textContent="Przygotowywanie wydruku…";
      await createRepairPdf(repair);
    }catch(error){toast("Nie udało się przygotować PDF: "+(error?.message||error));}
    finally{printButton.disabled=false;printButton.textContent="🖨️ Drukuj / PDF";}
  };
  item.appendChild(printButton);
  const emailButton=document.createElement("button");
  emailButton.type="button";
  emailButton.className="secondary";
  emailButton.textContent="✉️ Wyślij e-mailem";
  emailButton.style.cssText="margin-top:8px;width:100%;";
  emailButton.onclick=async e=>{
    e.stopPropagation();
    if(emailButton.disabled)return;
    try{
      emailButton.disabled=true;
      emailButton.textContent="Przygotowywanie wiadomości…";
      await createRepairPdf(repair,"email");
    }catch(error){
      if(error?.name!=="AbortError")toast("Nie udało się przygotować wiadomości: "+(error?.message||error));
    }finally{
      emailButton.disabled=false;
      emailButton.textContent="✉️ Wyślij e-mailem";
    }
  };
  item.appendChild(emailButton);
  const locationButton=document.createElement("button");
  locationButton.type="button";locationButton.className="secondary";
  locationButton.textContent="📍 Wyślij klientowi lokalizację SMS";
  locationButton.style.cssText="margin-top:8px;width:100%;";
  locationButton.onclick=e=>{e.stopPropagation();sendRepairLocationSms(repair,locationButton);};
  item.appendChild(locationButton);
  const materialsButton=document.createElement("button");
  materialsButton.type="button";materialsButton.className="secondary";
  materialsButton.textContent="🧰 Części i materiały tego zlecenia";
  materialsButton.style.cssText="margin-top:8px;width:100%;";
  materialsButton.onclick=async e=>{e.stopPropagation();if(!repair.id){toast("Najpierw zapisz zlecenie.");return;}try{materialsButton.disabled=true;await openRepairMaterials(repair.id);}catch(error){toast("Nie udało się otworzyć materiałów: "+(error.message||error));}finally{materialsButton.disabled=false;}};
  item.appendChild(materialsButton);
  const contactButton=document.createElement("button");
  contactButton.type="button";contactButton.className="secondary";
  contactButton.textContent="👤 Zapisz kontakt w telefonie";
  contactButton.style.cssText="margin-top:8px;width:100%;";
  contactButton.onclick=async e=>{
    e.stopPropagation();
    const phone=String(repair.telefon||"").trim();
    const vehicle=String(repair.pojazd||"").trim();
    const repairClientName=String(repair.klient||"").trim();

    const matchedClient=clients.find(client=>
      repair.klient_id!=null && String(client.id??"")===String(repair.klient_id)
    ) || clients.find(client=>
      repairClientName && normalizeSearch(client.imie_nazwisko)===normalizeSearch(repairClientName)
    );

    const clientName=String(matchedClient?.imie_nazwisko||repairClientName).trim();

    if(!phone){toast("W tym zleceniu nie ma numeru telefonu klienta.");return;}
    if(!clientName){toast("Brakuje imienia i nazwiska klienta.");return;}

    const relatedRepairs=repairs.filter(item=>
      (matchedClient && item.klient_id!=null && String(item.klient_id)===String(matchedClient.id)) ||
      (normalizeSearch(clientName) && normalizeSearch(item.klient)===normalizeSearch(clientName))
    );

    const relatedVehicles=vehicles.filter(item=>
      matchedClient && String(item.klient_id??"")===String(matchedClient.id)
    );

    const registrations=[
      ...relatedVehicles.map(item=>item.rejestracja),
      ...relatedRepairs.map(item=>item.rejestracja),
      repair.rejestracja
    ].map(value=>String(value||"").trim()).filter(Boolean);

    const uniqueRegistrations=[...new Set(registrations)];

    if(!uniqueRegistrations.length&&!vehicle){
      toast("Brakuje numeru rejestracyjnego i marki pojazdu.");
      return;
    }

    const contactName=[clientName,uniqueRegistrations.join(", ")].filter(Boolean).join(" – ");
    try{
      const plugin=window.Capacitor?.Plugins?.ContactSaver;
      if(!plugin?.createContact){toast("Funkcja kontaktów jest dostępna po przebudowaniu aplikacji Android.");return;}
      contactButton.disabled=true;
      await plugin.createContact({name:contactName,phone});
    }catch(error){toast("Nie udało się otworzyć książki kontaktów: "+(error?.message||error));}
    finally{contactButton.disabled=false;}
  };
  item.appendChild(contactButton);
  const qrButton=document.createElement("button");
  qrButton.type="button";qrButton.className="secondary";
  qrButton.textContent="🔳 Udostępnij klientowi — wygeneruj QR";
  qrButton.style.cssText="margin-top:8px;width:100%;";
  qrButton.onclick=e=>{e.stopPropagation();openRepairQr(repair,qrButton);};
  item.appendChild(qrButton);
  const button=document.createElement("button");
  button.type="button";
  button.className="secondary";
  button.textContent="Usuń naprawę";
  button.style.cssText="margin-top:10px;width:100%;";
  button.onclick=e=>{e.stopPropagation();deleteRepair(repair);};
  item.appendChild(button);
  return item;
}
async function deleteRepair(repair){
  const label=repair.numer_protokolu||repair.numer||`#${repair.id}`;
  if(!confirm(`Czy na pewno chcesz usunąć naprawę ${label}?\n\nTej operacji nie można cofnąć.`)) return;
  try{
    const photoPaths=getPhotoPaths(repair.zdjecia_lokalne);
    // Pliki Google Drive pozostają w prywatnej galerii klienta także po usunięciu zlecenia.
    // Usuwamy wyłącznie stare pliki Supabase przypisane bezpośrednio do tego zlecenia.
    const legacyPaths=photoPaths.filter(path=>!isDrivePhoto(path));
    if(legacyPaths.length){
      const {error:photoError}=await sb.storage.from(PHOTO_BUCKET).remove(legacyPaths);
      if(photoError) throw photoError;
    }
    const {error}=await sb.from("naprawy").delete().eq("id",repair.id);
    if(error) throw error;
    toast("Naprawa została usunięta.");
    await loadAll();
  }catch(error){
    alert("Nie udało się usunąć naprawy.\n\n"+error.message);
  }
}
function clientCard(client){
  const clientId=String(client.id??"");
  const clientName=normalizeSearch(client.imie_nazwisko);
  const clientVehicles=vehicles.filter(vehicle=>String(vehicle.klient_id??"")===clientId);
  const clientRepairs=repairs.filter(repair=>(repair.klient_id!=null && String(repair.klient_id)===clientId) || (clientName && normalizeSearch(repair.klient)===clientName));
  const registrations=[...clientVehicles.map(vehicle=>vehicle.rejestracja),...clientRepairs.map(repair=>repair.rejestracja)].map(value=>String(value||"").trim()).filter(Boolean);
  const uniqueRegistrations=[...new Set(registrations)];
  const item=card(client.imie_nazwisko,client.email||client.miasto,uniqueRegistrations.length?"Rejestracje: "+uniqueRegistrations.join(", "):"");
  const phone=String(client.telefon||"").trim();
  if(phone){
    const link=document.createElement("a");
    link.href="tel:"+phone.replace(/[^0-9+*#,;]/g,"");
    link.textContent="☎ "+phone;
    link.style.cssText="display:block;margin-top:8px;color:#36b37e;font-weight:600;text-decoration:none;";
    link.onclick=e=>e.stopPropagation();
    item.appendChild(link);
  }
  const button=document.createElement("button");
  button.type="button";
  button.className="secondary";
  button.textContent="Usuń klienta";
  button.style.cssText="margin-top:10px;width:100%;";
  button.onclick=e=>{e.stopPropagation();deleteClient(client);};
  item.appendChild(button);
  return item;
}
async function deleteClient(client){
  const name=client.imie_nazwisko||"tego klienta";
  if(!confirm(`Czy na pewno chcesz usunąć klienta: ${name}?\\n\\nPowiązane naprawy i pojazdy nie będą usuwane.`)) return;
  try{
    const [repairsById,repairsByName,vehiclesByClient]=await Promise.all([
      sb.from("naprawy").select("id",{count:"exact",head:true}).eq("klient_id",client.id),
      sb.from("naprawy").select("id",{count:"exact",head:true}).eq("klient",client.imie_nazwisko||""),
      sb.from("pojazdy").select("id",{count:"exact",head:true}).eq("klient_id",client.id)
    ]);
    for(const result of [repairsById,repairsByName,vehiclesByClient]) if(result.error) throw result.error;
    const repairCount=Math.max(repairsById.count||0,repairsByName.count||0);
    const vehicleCount=vehiclesByClient.count||0;
    if(repairCount||vehicleCount){
      const details=[];
      if(repairCount) details.push(`powiązane naprawy: ${repairCount}`);
      if(vehicleCount) details.push(`powiązane pojazdy: ${vehicleCount}`);
      alert(`Nie można usunąć klienta. Najpierw trzeba przenieść lub usunąć powiązane dane (${details.join(", ")}).\\n\\nŻadne dane nie zostały usunięte.`);
      return;
    }
    const {error}=await sb.from("klienci").delete().eq("id",client.id);
    if(error) throw error;
    toast("Klient został usunięty.");
    await loadAll();
  }catch(error){
    alert("Nie udało się usunąć klienta.\\n\\n"+error.message);
  }
}
function vehicleCard(vehicle){
  const title=vehicle.marka_model||`${vehicle.marka||""} ${vehicle.model||""}`.trim()||"Pojazd";
  const item=card(title,vehicle.rejestracja||"",vehicle.vin||"");
  const historyButton=document.createElement("button");
  historyButton.type="button";
  historyButton.className="secondary";
  historyButton.textContent="Historia napraw";
  historyButton.style.cssText="margin-top:10px;width:100%;";
  historyButton.onclick=e=>{e.stopPropagation();showVehicleHistory(vehicle);};
  item.appendChild(historyButton);
  const warrantyButton=document.createElement("button");
  warrantyButton.type="button";
  warrantyButton.className="secondary";
  warrantyButton.textContent="Karta gwarancyjna";
  warrantyButton.style.cssText="margin-top:8px;width:100%;background:#e9a23b;color:#171d27;";
  warrantyButton.onclick=e=>{e.stopPropagation();openEngineWarranty(vehicle);};
  item.appendChild(warrantyButton);
  const button=document.createElement("button");
  button.type="button";
  button.className="secondary";
  button.textContent="Usuń pojazd";
  button.style.cssText="margin-top:10px;width:100%;";
  button.onclick=e=>{e.stopPropagation();deleteVehicle(vehicle);};
  item.appendChild(button);
  return item;
}
function warrantyField(label,name,value="",type="text",placeholder=""){
  const wrap=document.createElement("label");
  wrap.textContent=label;
  const input=document.createElement("input");
  input.name=name;input.type=type;input.value=value??"";input.placeholder=placeholder;
  if(type==="date") input.value=new Date().toISOString().slice(0,10);
  wrap.appendChild(input);return wrap;
}
function openEngineWarranty(vehicle){
  const client=clients.find(c=>String(c.id)===String(vehicle.klient_id))||{};
  const dlg=document.createElement("dialog");dlg.className="warranty-dialog";
  const style=document.createElement("style");style.textContent='.warranty-dialog{width:min(94vw,620px)}.warranty-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 12px}.warranty-form label{margin:8px 0}.warranty-form label input{display:block}.warranty-note{background:#0c1728;border-left:4px solid #e9a23b;padding:12px;border-radius:8px;color:#d9e3ef;font-size:13px;line-height:1.5}.warranty-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}.warranty-actions button{flex:1}@media(max-width:520px){.warranty-form{grid-template-columns:1fr}}';
  const head=document.createElement("div");head.className="dialogHead";
  const title=document.createElement("h2");title.textContent="Karta gwarancyjna silnika";
  const close=document.createElement("button");close.type="button";close.className="ghost";close.textContent="✕";close.onclick=()=>dlg.close();head.append(title,close);
  const intro=document.createElement("p");intro.className="muted";intro.textContent="Dane klienta i pojazdu zostały uzupełnione automatycznie. Uzupełnij informacje o wymienionym silniku.";
  const form=document.createElement("form");form.className="warranty-form";
  const fields=[
    warrantyField("Imię i nazwisko klienta","client",client.imie_nazwisko||repairs.find(r=>String(r.klient_id)===String(client.id))?.klient||""),
    warrantyField("Telefon kontaktowy","phone",client.telefon||""),
    warrantyField("Marka / model pojazdu","vehicle",vehicle.marka_model||`${vehicle.marka||""} ${vehicle.model||""}`.trim()),
    warrantyField("Numer rejestracyjny","registration",vehicle.rejestracja||""),
    warrantyField("Numer VIN","vin",vehicle.vin||""),
    warrantyField("Typ / rodzaj silnika","engine_type",""),
    warrantyField("Kod silnika","engine_code",""),
    warrantyField("Numer seryjny silnika","engine_serial",""),
    warrantyField("Data montażu silnika","install_date","","date"),
    warrantyField("Okres gwarancji","warranty_period","","text","np. 12 miesięcy"),
    warrantyField("Limit przebiegu (opcjonalnie)","mileage_limit","","text","np. 5 000 km")
  ];
  fields.forEach(f=>form.appendChild(f));
  const note=document.createElement("p");note.className="warranty-note";note.style.gridColumn="1/-1";
  note.textContent="Zakres gwarancji: gwarancja obejmuje wyłącznie wymieniony silnik wskazany w niniejszej karcie. Nie obejmuje robocizny, montażu ani demontażu, pozostałych części, osprzętu ani innych elementów pojazdu. Szczegółowe warunki i wyłączenia należy stosować zgodnie z warunkami gwarancji przekazanymi klientowi.";
  form.appendChild(note);
  const actions=document.createElement("div");actions.className="warranty-actions";actions.style.gridColumn="1/-1";
  const download=document.createElement("button");download.type="button";download.textContent="Pobierz kartę PDF";
  const print=document.createElement("button");print.type="button";print.className="secondary";print.textContent="Drukuj kartę";
  const cancel=document.createElement("button");cancel.type="button";cancel.className="ghost";cancel.textContent="Anuluj";cancel.onclick=()=>dlg.close();
  const collect=()=>Object.fromEntries(new FormData(form).entries());
  download.onclick=async()=>{try{download.disabled=true;download.textContent="Tworzenie PDF…";await createEngineWarrantyPdf(vehicle,collect());toast("Karta gwarancyjna została pobrana.");}catch(err){toast("PDF: "+(err.message||err));}finally{download.disabled=false;download.textContent="Pobierz kartę PDF";}};
  print.onclick=async()=>{try{print.disabled=true;print.textContent="Przygotowywanie…";await createEngineWarrantyPdf(vehicle,collect(),"print");}catch(err){toast("Drukowanie: "+(err.message||err));}finally{print.disabled=false;print.textContent="Drukuj kartę";}};
  actions.append(download,print,cancel);form.appendChild(actions);dlg.append(style,head,intro,form);document.body.appendChild(dlg);
  dlg.addEventListener("close",()=>dlg.remove(),{once:true});
  if(typeof dlg.showModal==="function")dlg.showModal();else dlg.setAttribute("open","");
}
async function createEngineWarrantyPdf(vehicle,data,action="download"){
  const JsPDF=await loadJsPDF();
  const doc=new JsPDF({unit:"mm",format:"a4",compress:true});
  await loadPdfFont(doc,"Lato-Regular.ttf","Lato","normal");
  await loadPdfFont(doc,"Lato-Bold.ttf","Lato","bold");
  const W=210,M=15,CW=180,navy=[24,39,59],orange=[226,145,47],ink=[42,52,65],muted=[104,116,130],line=[215,222,230],pale=[245,247,250];
  const txt=v=>String(v??"").trim()||"—";
  const set=(style="normal",size=9,color=ink)=>{doc.setFont("Lato",style);doc.setFontSize(size);doc.setTextColor(...color);};
  const box=(x,y,w,h,label,value)=>{doc.setDrawColor(...line);doc.setFillColor(255,255,255);doc.roundedRect(x,y,w,h,1.5,1.5,"FD");set("bold",7,muted);doc.text(label.toUpperCase(),x+3,y+4.5);set("normal",9,ink);doc.text(doc.splitTextToSize(txt(value),w-6),x+3,y+10);};
  doc.setFillColor(...navy);doc.rect(0,0,W,43,"F");doc.setFillColor(...orange);doc.roundedRect(M,9,19,19,3,3,"F");set("bold",13,[255,255,255]);doc.text("2|4",M+3.2,21);set("bold",15,[255,255,255]);doc.text("DWA I CZTERY KOŁA",M+25,16);set("normal",8.5,[230,235,242]);doc.text("KARTA GWARANCYJNA WYMIENIONEGO SILNIKA",M+25,23);
  set("normal",8,[230,235,242]);doc.text("ul. Lwa Tołstoja 5B, 42-680 Tarnowskie Góry  •  NIP 645 221 03 54",M+25,31);
  let y=51;const section=t=>{doc.setFillColor(...pale);doc.roundedRect(M,y,CW,8,1.5,1.5,"F");set("bold",8.5,navy);doc.text(t.toUpperCase(),M+3,y+5.4);y+=12;};
  section("Dane klienta");box(M,y,112,17,"Imię i nazwisko",data.client);box(M+115,y,65,17,"Telefon",data.phone);y+=21;
  section("Dane pojazdu");box(M,y,90,17,"Marka / model",data.vehicle);box(M+93,y,87,17,"Numer rejestracyjny",data.registration);y+=21;box(M,y,180,17,"Numer VIN",data.vin);y+=21;
  section("Dane wymienionego silnika");box(M,y,87,17,"Typ / rodzaj silnika",data.engine_type);box(M+93,y,87,17,"Kod silnika",data.engine_code);y+=21;box(M,y,87,17,"Numer seryjny silnika",data.engine_serial);box(M+93,y,87,17,"Data montażu",data.install_date?new Date(data.install_date+"T00:00:00").toLocaleDateString("pl-PL"):"");y+=21;box(M,y,87,17,"Okres gwarancji",data.warranty_period);box(M+93,y,87,17,"Limit przebiegu (jeśli ustalono)",data.mileage_limit);y+=24;
  section("Zakres gwarancji i warunki");
  const terms="Gwarancja obejmuje WYŁĄCZNIE wymieniony silnik opisany w niniejszej karcie. Gwarancja nie obejmuje robocizny, montażu ani demontażu, pozostałych części, osprzętu ani innych elementów pojazdu. Warunki, termin i ewentualny limit przebiegu określono w danych powyżej. Karta dotyczy wyłącznie wskazanego silnika.";
  set("normal",9,ink);const termLines=doc.splitTextToSize(terms,CW-8);doc.setDrawColor(...line);doc.roundedRect(M,y,CW,Math.max(27,termLines.length*4.5+10),1.5,1.5,"FD");doc.text(termLines,M+4,y+7);y+=Math.max(32,termLines.length*4.5+15);
  set("normal",8,muted);doc.text("Data wystawienia: "+new Date().toLocaleDateString("pl-PL"),M,y);y+=12;
  doc.setDrawColor(...line);doc.line(M,y+16,M+76,y+16);doc.line(M+104,y+16,M+180,y+16);set("normal",7.5,muted);doc.text("Podpis osoby wydającej / pieczęć serwisu",M,y+21);doc.text("Podpis klienta",M+104,y+21);
  doc.setDrawColor(...orange);doc.setLineWidth(.8);doc.roundRect(M,y+29,180,23,2,2,"S");set("bold",8,navy);doc.text("MIEJSCE NA PIECZĘĆ",M+90,y+42,{align:"center"});
  const safe=(txt(data.registration)||txt(data.engine_serial)||"silnik").replace(/[^a-z0-9_-]/gi,"_");
  if(action==="print"){
    const url=URL.createObjectURL(doc.output("blob"));const win=window.open(url,"_blank");if(!win){URL.revokeObjectURL(url);throw new Error("Zezwól na otwieranie okien, aby wydrukować PDF.");}win.addEventListener("load",()=>{win.focus();win.print();},{once:true});
  }else doc.save("Karta_gwarancyjna_silnika_"+safe+".pdf");
}

function showVehicleHistory(vehicle){
  const registration=String(vehicle.rejestracja||"").trim().toUpperCase().replace(/[\s-]/g,"");
  const related=repairs.filter(repair=>{
    if(vehicle.id!=null && repair.pojazd_id!=null && String(repair.pojazd_id)===String(vehicle.id)) return true;
    const repairRegistration=String(repair.rejestracja||"").trim().toUpperCase().replace(/[\s-]/g,"");
    return Boolean(registration && repairRegistration===registration);
  }).sort((a,b)=>{
    const da=new Date(a.data_przyjecia||a.created_at||0).getTime();
    const db=new Date(b.data_przyjecia||b.created_at||0).getTime();
    return db-da;
  });

  let dlg=$("vehicleHistoryDialog");
  if(!dlg){
    dlg=document.createElement("dialog");
    dlg.id="vehicleHistoryDialog";
    document.body.appendChild(dlg);
  }
  dlg.replaceChildren();

  const header=document.createElement("div");
  header.className="dialogHead";
  const heading=document.createElement("h2");
  heading.textContent="Historia pojazdu";
  const close=document.createElement("button");
  close.type="button";
  close.className="ghost";
  close.textContent="Zamknij";
  close.onclick=()=>dlg.close();
  header.append(heading,close);
  dlg.appendChild(header);

  const vehicleName=vehicle.marka_model||`${vehicle.marka||""} ${vehicle.model||""}`.trim()||"Pojazd";
  const subtitle=document.createElement("p");
  subtitle.className="muted";
  subtitle.textContent=[vehicleName,vehicle.rejestracja||"",vehicle.vin||""].filter(Boolean).join(" • ");
  dlg.appendChild(subtitle);

  const count=document.createElement("p");
  count.className="muted";
  count.textContent=`Liczba znalezionych napraw: ${related.length}`;
  dlg.appendChild(count);

  if(!related.length){
    const empty=document.createElement("p");
    empty.textContent="Nie znaleziono jeszcze napraw przypisanych do tego pojazdu.";
    dlg.appendChild(empty);
  }

  related.forEach(repair=>{
    const entry=document.createElement("article");
    entry.className="item";
    entry.style.marginTop="10px";

    const title=document.createElement("strong");
    title.textContent=repair.numer_protokolu||repair.numer||"Naprawa";
    entry.appendChild(title);

    const dateValue=repair.data_przyjecia||repair.created_at;
    const dateText=dateValue&&!Number.isNaN(new Date(dateValue).getTime())
      ?new Date(dateValue).toLocaleString("pl-PL")
      :"Brak daty";
    const meta=document.createElement("p");
    meta.textContent=[dateText,repair.status||""].filter(Boolean).join(" • ");
    entry.appendChild(meta);

    const details=document.createElement("p");
    const detailsParts=[];
    if(repair.klient) detailsParts.push("Klient: "+repair.klient);
    if(repair.opis_usterki||repair.zgloszenie) detailsParts.push("Usterka: "+(repair.opis_usterki||repair.zgloszenie));
    if(repair.diagnoza) detailsParts.push("Diagnoza: "+repair.diagnoza);
    if(repair.wykonane_prace) detailsParts.push("Wykonane prace: "+repair.wykonane_prace);
    if(repair.suma!=null && repair.suma!=="") detailsParts.push("Suma: "+repair.suma+" zł");
    const photoCount=getPhotoPaths(repair.zdjecia_lokalne).length;
    if(photoCount) detailsParts.push("Zdjęcia: "+photoCount);
    details.textContent=detailsParts.join("\n")||"Brak dodatkowych szczegółów.";
    details.style.whiteSpace="pre-line";
    entry.appendChild(details);

    const open=document.createElement("button");
    open.type="button";
    open.className="secondary";
    open.textContent="Otwórz zlecenie";
    open.style.cssText="width:100%;margin-top:8px;";
    open.onclick=()=>{dlg.close();editRepair(repair);};
    entry.appendChild(open);
    dlg.appendChild(entry);
  });

  if(typeof dlg.showModal==="function") dlg.showModal();
  else dlg.setAttribute("open","");
}
async function deleteVehicle(vehicle){
  const title=vehicle.marka_model||vehicle.rejestracja||"ten pojazd";
  if(!confirm(`Czy na pewno chcesz usunąć pojazd: ${title}?\\n\\nNaprawy powiązane z tym pojazdem nie będą usuwane.`)) return;
  try{
    const checks=[sb.from("naprawy").select("id",{count:"exact",head:true}).eq("pojazd_id",vehicle.id)];
    const registration=String(vehicle.rejestracja||"").trim();
    if(registration) checks.push(sb.from("naprawy").select("id",{count:"exact",head:true}).eq("rejestracja",registration));
    const results=await Promise.all(checks);
    for(const result of results) if(result.error) throw result.error;
    const repairCount=Math.max(...results.map(result=>result.count||0));
    if(repairCount){
      alert(`Nie można usunąć pojazdu. Jest powiązany z ${repairCount} naprawami.\\n\\nNajpierw zmień powiązania tych napraw. Żadne dane nie zostały usunięte.`);
      return;
    }
    const {error}=await sb.from("pojazdy").delete().eq("id",vehicle.id);
    if(error) throw error;
    toast("Pojazd został usunięty.");
    await loadAll();
  }catch(error){
    alert("Nie udało się usunąć pojazdu.\\n\\n"+error.message);
  }
}
["searchRepairs","searchCompleted","searchClients","searchVehicles"].forEach(id=>$(id).oninput=render);
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{
  const tabs=Array.from(document.querySelectorAll(".tab"));
  const previousIndex=tabs.findIndex(x=>x.classList.contains("active"));
  const nextIndex=tabs.indexOf(b);
  const target=document.getElementById(b.dataset.tab);

  tabs.forEach(x=>x.classList.toggle("active",x===b));
  document.querySelectorAll(".tabview").forEach(view=>{
    if(view!==target){
      view.classList.remove("tab-enter-forward","tab-enter-backward");
      show(view.id,false);
    }
  });

  if(target){
    show(target.id,true);
    if(previousIndex!==-1 && nextIndex!==previousIndex){
      target.classList.remove("tab-enter-forward","tab-enter-backward");
      // Ponowne uruchomienie animacji także przy szybkim przełączaniu zakładek.
      void target.offsetWidth;
      target.classList.add(nextIndex>previousIndex?"tab-enter-forward":"tab-enter-backward");
    }else{
      target.classList.remove("tab-enter-forward","tab-enter-backward");
    }
  }
  if(b.dataset.tab==="parts")renderPartsCatalog();
});

// Nawigacja gestem: przesunięcie po treści przełącza sąsiednią zakładkę.
// Pasek zakładek nadal można przewijać i obsługiwać kliknięciem.
(()=>{
  const app=document.getElementById("app");
  if(!app) return;
  let touchStart=null;
  const ignoredSelector='nav, input, textarea, select, button, a, [contenteditable="true"], dialog, .no-tab-swipe';
  app.addEventListener("touchstart",event=>{
    if(event.touches.length!==1 || event.target.closest(ignoredSelector)){touchStart=null;return;}
    const touch=event.touches[0];
    touchStart={x:touch.clientX,y:touch.clientY};
  },{passive:true});
  app.addEventListener("touchend",event=>{
    if(!touchStart || event.changedTouches.length!==1 || document.querySelector("dialog[open]")){touchStart=null;return;}
    const touch=event.changedTouches[0];
    const dx=touch.clientX-touchStart.x;
    const dy=touch.clientY-touchStart.y;
    touchStart=null;
    if(Math.abs(dx)<65 || Math.abs(dx)<Math.abs(dy)*1.25) return;
    const tabs=Array.from(app.querySelectorAll("nav .tab"));
    const activeIndex=tabs.findIndex(tab=>tab.classList.contains("active"));
    if(activeIndex<0) return;
    const nextIndex=activeIndex+(dx<0?1:-1);
    if(nextIndex<0 || nextIndex>=tabs.length) return;
    tabs[nextIndex].click();
  },{passive:true});
  app.addEventListener("touchcancel",()=>{touchStart=null;},{passive:true});
})();

// STATYSTYKI: sumujemy wyłącznie pole "zaplacono".
// Okres przypisujemy do daty przyjęcia zlecenia (data_przyjecia),
// ponieważ w bazie nie ma osobnego pola daty otrzymania wpłaty.
function paidAmount(repair){
  const raw=String(repair.zaplacono??"").trim().replace(/\s/g,"").replace(",",".");
  const amount=Number(raw);
  return Number.isFinite(amount)&&amount>0?amount:0;
}
function localDateKey(date){
  const y=date.getFullYear(),m=String(date.getMonth()+1).padStart(2,"0"),d=String(date.getDate()).padStart(2,"0");
  return `${y}-${m}-${d}`;
}
function parseLocalDate(value){
  if(!value) return null;
  const text=String(value);
  const match=text.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if(match) return new Date(Number(match[1]),Number(match[2])-1,Number(match[3]));
  const date=new Date(value);
  return Number.isNaN(date.getTime())?null:new Date(date.getFullYear(),date.getMonth(),date.getDate());
}
function currentPeriodValue(mode){
  const now=new Date();
  if(mode==="daily") return localDateKey(now);
  if(mode==="weekly"){
    const d=new Date(now);d.setDate(d.getDate()-((d.getDay()+6)%7));
    const jan4=new Date(d.getFullYear(),0,4);const week1=new Date(jan4);week1.setDate(jan4.getDate()-((jan4.getDay()+6)%7));
    const week=Math.floor((d-week1)/604800000)+1;
    return `${d.getFullYear()}-W${String(week).padStart(2,"0")}`;
  }
  if(mode==="monthly") return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}`;
  return String(now.getFullYear());
}
function setStatsPeriodInput(){
  const mode=$("statsPeriodType").value,input=$("statsPeriodValue");
  const types={daily:"date",weekly:"week",monthly:"month",yearly:"number"};
  input.type=types[mode];
  input.min=mode==="yearly"?"2000":"";input.max=mode==="yearly"?"2100":"";
  input.value=currentPeriodValue(mode);
  input.step="1";
  renderStats();
}
function statsRange(mode,value){
  let start,end;
  if(mode==="daily"){
    start=parseLocalDate(value);if(!start)return null;end=new Date(start);end.setDate(end.getDate()+1);
  }else if(mode==="weekly"){
    const m=String(value||"").match(/^(\d{4})-W(\d{2})$/);if(!m)return null;
    const year=Number(m[1]),week=Number(m[2]);
    const jan4=new Date(year,0,4);start=new Date(jan4);start.setDate(jan4.getDate()-((jan4.getDay()+6)%7)+(week-1)*7);
    end=new Date(start);end.setDate(end.getDate()+7);
  }else if(mode==="monthly"){
    const m=String(value||"").match(/^(\d{4})-(\d{2})$/);if(!m)return null;
    start=new Date(Number(m[1]),Number(m[2])-1,1);end=new Date(Number(m[1]),Number(m[2]),1);
  }else{
    const year=Number(value);if(!Number.isInteger(year)||year<2000||year>2100)return null;
    start=new Date(year,0,1);end=new Date(year+1,0,1);
  }
  return {start,end};
}
function moneyPL(value){return (Number(value)||0).toLocaleString("pl-PL",{minimumFractionDigits:2,maximumFractionDigits:2})+" zł";}
function renderStats(){
  const host=$("statsResults");if(!host)return;
  const mode=$("statsPeriodType")?.value||"monthly";
  const value=$("statsPeriodValue")?.value||currentPeriodValue(mode);
  const range=statsRange(mode,value);
  host.replaceChildren();
  if(!range){host.textContent="Wybierz prawidłowy okres.";return;}
  const paidRows=repairs.map(repair=>({repair,amount:paidAmount(repair),date:parseLocalDate(repair.data_przyjecia||repair.created_at)}))
    .filter(row=>row.amount>0&&row.date&&row.date>=range.start&&row.date<range.end);
  const total=paidRows.reduce((sum,row)=>sum+row.amount,0);
  const average=paidRows.length?total/paidRows.length:0;
  const title=document.createElement("p");title.className="muted";
  const periodLabels={daily:"Dzień",weekly:"Tydzień",monthly:"Miesiąc",yearly:"Rok"};
  title.textContent=`${periodLabels[mode]}: ${value}`;host.appendChild(title);
  const summary=document.createElement("div");summary.className="stats-summary";
  const makeMetric=(label,val,accent=false)=>{const box=document.createElement("div");box.className="stats-metric";const small=document.createElement("span");small.textContent=label;const strong=document.createElement("strong");strong.textContent=val;if(accent)strong.classList.add("stats-accent");box.append(small,strong);return box;};
  summary.append(makeMetric("Otrzymano",moneyPL(total),true),makeMetric("Zlecenia z wpłatą",String(paidRows.length)),makeMetric("Średnia wpłata na zlecenie",moneyPL(average)));
  host.appendChild(summary);
  const note=document.createElement("p");note.className="stats-note";
  note.textContent="Liczone wyłącznie z pola „Zapłacono”. Okres przypisany według daty przyjęcia zlecenia, ponieważ zlecenia nie mają osobnej daty wpłaty.";
  host.appendChild(note);
  const heading=document.createElement("h3");heading.textContent=mode==="daily"?"Wpłaty w tym dniu":"Podział wpłat w okresie";host.appendChild(heading);
  if(!paidRows.length){const empty=document.createElement("p");empty.className="muted";empty.textContent="Brak zleceń z wpisaną wpłatą w wybranym okresie.";host.appendChild(empty);}
  else if(mode==="daily"){
    paidRows.sort((a,b)=>String(a.repair.numer_protokolu||a.repair.numer||"").localeCompare(String(b.repair.numer_protokolu||b.repair.numer||""),"pl"));
    paidRows.forEach(row=>{
      const item=document.createElement("div");item.className="stats-row";
      const left=document.createElement("div");const name=document.createElement("strong");name.textContent=row.repair.numer_protokolu||row.repair.numer||"Naprawa";
      const sub=document.createElement("small");sub.textContent=[row.repair.klient,row.repair.pojazd,row.repair.rejestracja].filter(Boolean).join(" • ");left.append(name,sub);
      const amount=document.createElement("strong");amount.textContent=moneyPL(row.amount);item.append(left,amount);host.appendChild(item);
    });
  }else{
    const buckets=new Map();
    paidRows.forEach(row=>{
      let key,label;
      if(mode==="yearly") {key=`${row.date.getFullYear()}-${String(row.date.getMonth()+1).padStart(2,"0")}`;label=row.date.toLocaleDateString("pl-PL",{month:"long"});}
      else {key=localDateKey(row.date);label=row.date.toLocaleDateString("pl-PL",{day:"2-digit",month:"2-digit",year:"numeric"});}
      buckets.set(key,{label,total:(buckets.get(key)?.total||0)+row.amount});
    });
    const entries=[...buckets.entries()].sort((a,b)=>a[0].localeCompare(b[0]));
    const max=Math.max(...entries.map(entry=>entry[1].total),1);
    entries.forEach(([,bucket])=>{
      const row=document.createElement("div");row.className="stats-breakdown";
      const line=document.createElement("div");line.className="stats-row";
      const label=document.createElement("strong");label.textContent=bucket.label;
      const amount=document.createElement("strong");amount.textContent=moneyPL(bucket.total);line.append(label,amount);
      const track=document.createElement("div");track.className="stats-bar-track";
      const fill=document.createElement("div");fill.className="stats-bar-fill";fill.style.width=`${Math.max(2,bucket.total/max*100)}%`;track.appendChild(fill);
      row.append(line,track);host.appendChild(row);
    });
  }
}
async function exportStatsPdf(){
  try{
    const mode=$("statsPeriodType").value,value=$("statsPeriodValue").value,range=statsRange(mode,value);
    if(!range)throw new Error("Wybierz prawidłowy okres.");
    const rows=repairs.map(repair=>({repair,amount:paidAmount(repair),date:parseLocalDate(repair.data_przyjecia||repair.created_at)}))
      .filter(row=>row.amount>0&&row.date&&row.date>=range.start&&row.date<range.end);
    const total=rows.reduce((sum,row)=>sum+row.amount,0);
    const JsPDF=await loadJsPDF();const doc=new JsPDF({unit:"mm",format:"a4"});
    doc.setFont("helvetica","bold");doc.setFontSize(17);doc.text("DWA I CZTERY KOLA",15,18);
    doc.setFontSize(13);doc.text("ZESTAWIENIE WPLAT",15,28);
    doc.setFont("helvetica","normal");doc.setFontSize(10);
    const labels={daily:"Dzien",weekly:"Tydzien",monthly:"Miesiac",yearly:"Rok"};
    doc.text(`${labels[mode]}: ${value}`,15,38);
    doc.text(`Suma pola ZAPŁACONO: ${total.toFixed(2)} PLN`,15,47);
    doc.text(`Liczba zlecen z wplata: ${rows.length}`,15,55);
    doc.text("Okres wedlug daty przyjecia zlecenia.",15,63);
    let y=76;doc.setFont("helvetica","bold");doc.text("Numer zlecenia",15,y);doc.text("Klient",75,y);doc.text("Zapłacono (PLN)",150,y);y+=7;
    doc.setFont("helvetica","normal");
    rows.sort((a,b)=>a.date-b.date).forEach(row=>{
      if(y>275){doc.addPage();y=20;}
      const number=String(row.repair.numer_protokolu||row.repair.numer||"—").slice(0,28);
      const client=String(row.repair.klient||"—").slice(0,32);
      doc.text(number,15,y);doc.text(client,75,y);doc.text(row.amount.toFixed(2),155,y);y+=7;
    });
    doc.save(`Zestawienie_wplat_${mode}_${value}.pdf`);
  }catch(error){toast("Nie udało się przygotować PDF: "+error.message);}
}
$("statsPeriodType").onchange=setStatsPeriodInput;
$("statsPeriodValue").onchange=renderStats;
$("exportStatsPdf").onclick=exportStatsPdf;

function field(label,name,value="",type="text"){
  let v=value??"";
  if(type==="datetime-local" && v){
    const dt=new Date(v);
    if(!Number.isNaN(dt.getTime())){
      const pad=n=>String(n).padStart(2,"0");
      v=`${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())}T${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
    } else v="";
  }
  const safe=String(v).replaceAll("&","&amp;").replaceAll('"',"&quot;");
  return `<label>${label}<input name="${name}" type="${type}" value="${safe}" /></label>`;
}
function area(label,name,value=""){return `<label>${label}<textarea name="${name}">${String(value??"")}</textarea></label>`}
function checkboxField(label,name,checked=false){return `<label style="display:flex;gap:10px;align-items:center;margin:12px 0"><input type="checkbox" name="${name}" value="true" ${checked?"checked":""} style="width:auto">${label}</label>`}
async function sendStatusSms(phone, message){
  if(!window.Capacitor?.isNativePlatform?.() || !window.Capacitor?.registerPlugin){
    throw new Error("Otwieranie SMS jest dostępne tylko w natywnej aplikacji Android.");
  }
  const SmsSender=window.Capacitor.registerPlugin("SmsSender");
  await SmsSender.send({phone,message});
}
const REPAIR_STATUSES=[
  "PRZYJĘTY",
  "OCZEKUJE NA DIAGNOZĘ",
  "OCZEKUJE NA CZĘŚCI",
  "W TRAKCIE NAPRAWY",
  "GOTOWY DO ODBIORU",
  "Wydano Klientowi",
  "Rezygnacja z naprawy"
];
function selectField(label,name,options,value=""){
  const normalizedStatus=normalizeSearch(value);
  const current=name==="status"&&["wydanoklientowi","wydanyklientowi"].includes(normalizedStatus)?"Wydano Klientowi":name==="status"&&normalizedStatus==="rezygnacjaznaprawy"?"Rezygnacja z naprawy":(value||options[0]);
  const html=options.map(option=>`<option value="${option.replaceAll("&","&amp;").replaceAll('"',"&quot;")}" ${option===current?"selected":""}>${option}</option>`).join("");
  return `<label>${label}<select name="${name}">${html}</select></label>`;
}
function closeEditor(){
  const dlg=$("editor");
  if(dlg && dlg.open){ dlg.close(); }
  // Reset submit state so the next form opens normally.
  const btn=$("saveRecord");
  if(btn){ btn.disabled=false; btn.textContent="Zapisz"; }
}
// Udostępnij funkcję przyciskom inline w HTML (działa w przeglądarkach desktop i mobile).
window.closeEditor=closeEditor;
$("editor").addEventListener("click",e=>{ if(e.target===$("editor")) closeEditor(); });
$("editor").addEventListener("cancel",e=>{ e.preventDefault(); closeEditor(); });
function openEditor(title,html,save){$("editTitle").textContent=title;$("fields").innerHTML=html;const dlg=$("editor");
                                                                                                  if(typeof dlg.showModal==="function"){
                                                                                                    dlg.showModal();
                                                                                                  }else{
                                                                                                    dlg.setAttribute("open","");
                                                                                                  };$("editForm").onsubmit=async e=>{e.preventDefault();const btn=$("saveRecord");btn.disabled=true;btn.textContent="Zapisywanie…";const data=Object.fromEntries(new FormData(e.target).entries());try{await save(data);closeEditor();await loadAll();toast("Zapisano")}catch(err){toast("Nie zapisano: "+err.message)}finally{btn.disabled=false;btn.textContent="Zapisz"}}}
$("newClient").onclick=()=>openEditor("Nowy klient",field("Imię i nazwisko","imie_nazwisko")+field("Telefon","telefon")+field("E-mail","email","", "email")+field("Ulica","ulica")+field("Numer domu","numer_domu")+field("Kod pocztowy","kod_pocztowy")+field("Miasto","miasto")+area("Uwagi","uwagi"),async d=>{const {error}=await sb.from("klienci").insert(d);if(error)throw error});
$("newRepair").onclick=()=>editRepair({});
async function nextRepairNumber(){
  const now=new Date(), day=now.getDate(), month=now.getMonth()+1, year=now.getFullYear();
  const {data,error}=await sb.from("naprawy").select("numer,numer_protokolu").limit(5000);
  if(error) throw error;
  let max=0;
  for(const row of (data||[])) for(const raw of [row.numer,row.numer_protokolu]){
    const m=String(raw||"").trim().match(/^(\d+)\/(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if(m && +m[2]===day && +m[3]===month && +m[4]===year) max=Math.max(max,+m[1]);
  }
  return `${max+1}/${day}/${month}/${year}`;
}
const PHOTO_BUCKET="zdjecia-serwisowe";
function getPhotoPaths(value){
  if(!value) return [];
  if(Array.isArray(value)) return value;
  try { const parsed=JSON.parse(value); return Array.isArray(parsed)?parsed:[]; }
  catch(_){ return String(value).split("|").filter(Boolean); }
}
const DRIVE_FUNCTION_URL=PROJECT_URL+"/functions/v1/google-drive";
async function driveRequest(action,options={}){
  const {data:{session}}=await sb.auth.getSession();
  if(!session?.access_token) throw new Error("Sesja wygasła. Zaloguj się ponownie.");
  const headers={"Authorization":"Bearer "+session.access_token,"apikey":localStorage.getItem("dk_publishable"),...(options.headers||{})};
  const response=await fetch(DRIVE_FUNCTION_URL+"?action="+encodeURIComponent(action)+(options.query||""),{...options,headers});
  if(!response.ok){let message="Błąd Google Drive (HTTP "+response.status+")";try{const body=await response.json();message=body.error||message;}catch(_){}throw new Error(message);}
  return response;
}
function isDrivePhoto(path){return typeof path==="string"&&path.startsWith("gdrive:");}
function drivePhotoId(path){return String(path).slice(7);}
async function getPhotoBlob(path){
  if(isDrivePhoto(path)) return await (await driveRequest("download",{query:"&fileId="+encodeURIComponent(drivePhotoId(path))})).blob();
  const {data,error}=await sb.storage.from(PHOTO_BUCKET).download(path);if(error)throw error;return data;
}
async function deleteDrivePhoto(path){
  return driveRequest("delete",{method:"DELETE",query:"&fileId="+encodeURIComponent(drivePhotoId(path))});
}
const BACKUP_PAGE_SIZE=500;
const BACKUP_CHUNK_SIZE=48*1024;

function getBackupPlugin(){
  if(!window.Capacitor?.isNativePlatform?.() || !window.Capacitor?.registerPlugin) return null;
  return window.Capacitor.registerPlugin("Backup");
}

function setBackupStatus(message){
  const status=$("backupStatus");
  if(status) status.textContent=message;
}

async function fetchAllBackupRows(table){
  const all=[];
  for(let from=0;;from+=BACKUP_PAGE_SIZE){
    const {data,error}=await sb.from(table)
      .select("*")
      .order("id",{ascending:true})
      .range(from,from+BACKUP_PAGE_SIZE-1);
    if(error) throw error;
    const rows=data||[];
    all.push(...rows);
    if(rows.length<BACKUP_PAGE_SIZE) break;
  }
  return all;
}

async function addBlobToBackup(plugin,entryName,blob){
  if(!(blob instanceof Blob)) throw new Error("Nieprawidłowe dane pliku kopii: "+entryName);
  await plugin.beginBackupEntry({entryName});
  for(let offset=0;offset<blob.size;offset+=BACKUP_CHUNK_SIZE){
    const bytes=new Uint8Array(await blob.slice(offset,offset+BACKUP_CHUNK_SIZE).arrayBuffer());
    let binary="";
    for(let i=0;i<bytes.length;i++) binary+=String.fromCharCode(bytes[i]);
    await plugin.writeBackupChunk({chunk:btoa(binary)});
  }
  await plugin.endBackupEntry();
}

function getSafeBackupPhotoPath(value){
  if(typeof value!=="string" || !value.trim()) throw new Error("Znaleziono nieprawidłową ścieżkę zdjęcia.");
  const path=value.replace(/\\/g,"/");
  if(path.startsWith("/") || path.split("/").some(part=>!part || part==="." || part==="..")){
    throw new Error("Nieprawidłowa ścieżka zdjęcia w danych.");
  }
  return path;
}

async function buildBackupArchive(plugin){
  const [repairs,clients,vehicles]=await Promise.all([
    fetchAllBackupRows("naprawy"),
    fetchAllBackupRows("klienci"),
    fetchAllBackupRows("pojazdy")
  ]);

  setBackupStatus("Zebrano dane. Przygotowywanie listy zdjęć…");

  const photoPaths=new Set();
  for(const repair of repairs){
    for(const rawPath of getPhotoPaths(repair.zdjecia_lokalne)){
      photoPaths.add(getSafeBackupPhotoPath(rawPath));
    }
  }

  const manifest={
    format:"DWA_I_CZTERY_KOLA_BACKUP",
    formatVersion:1,
    createdAt:new Date().toISOString(),
    tables:{
      naprawy:repairs.length,
      klienci:clients.length,
      pojazdy:vehicles.length
    },
    photoCount:photoPaths.size,
    photoBucket:PHOTO_BUCKET
  };

  await addBlobToBackup(plugin,"manifest.json",new Blob(
    [JSON.stringify(manifest,null,2)],
    {type:"application/json"}
  ));

  const tableFiles=[
    ["data/naprawy.json",repairs],
    ["data/klienci.json",clients],
    ["data/pojazdy.json",vehicles]
  ];

  for(const [entryName,rows] of tableFiles){
    await addBlobToBackup(plugin,entryName,new Blob(
      [JSON.stringify(rows)],
      {type:"application/json"}
    ));
  }

  let photoNumber=0;
  for(const path of photoPaths){
    photoNumber++;
    setBackupStatus("Pobieranie zdjęć: "+photoNumber+" z "+photoPaths.size+"…");
    let data;
    try{data=await getPhotoBlob(path);}catch(error){throw new Error("Nie udało się pobrać pliku "+path+": "+(error.message||error));}
    if(!data) throw new Error("Brak pliku w chmurze: "+path);
    const entryName=isDrivePhoto(path)?"photos/google-drive/"+drivePhotoId(path):"photos/"+path;
    await addBlobToBackup(plugin,entryName,data);
  }

  return manifest;
}

async function uploadRepairPhotos(repairId, files, existingPaths, customerId){
  const paths=[...existingPaths];
  const valid=files.filter(file=>file.type&&(file.type.startsWith("image/")||file.type==="application/pdf"));
  let number=0;
  for(const file of valid){
    number++;
    const btn=$("saveRecord");
    if(btn) btn.textContent=`Wysyłanie zdjęcia ${number}/${valid.length}…`;
    if(file.size>25*1024*1024) throw new Error(`Plik „${file.name}” przekracza limit 25 MB.`);
    const form=new FormData();form.append("file",file,file.name||("zalacznik_"+Date.now()));
    form.append("repairId",String(repairId));if(customerId!=null)form.append("customerId",String(customerId));
    form.append("category",file.type.startsWith("image/")?"photo":"attachment");
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),90000);
    let response;
    try{
      response=await driveRequest("upload",{method:"POST",body:form,signal:controller.signal});
    }catch(error){
      if(error.name==="AbortError") throw new Error(`Przekroczono 90 sekund podczas wysyłania „${file.name}”. Sprawdź internet i spróbuj ponownie.`);
      throw error;
    }finally{clearTimeout(timeout);}
    const result=await response.json();
    if(!result?.ok||!result.file?.id) throw new Error("Google Drive nie zwrócił identyfikatora wysłanego pliku.");
    paths.push("gdrive:"+result.file.id);
  }
  return paths;
}
async function showRepairPhotos(paths){
  const host=$("photoCurrent"); if(!host) return;
  host.replaceChildren();
  for(const path of paths){
    try{
      let url;
      if(isDrivePhoto(path)){const blob=await getPhotoBlob(path);url=URL.createObjectURL(blob);}
      else {const {data,error}=await sb.storage.from(PHOTO_BUCKET).createSignedUrl(path,3600);if(error)continue;url=data.signedUrl;}
      const a=document.createElement("a");a.href=url;a.target="_blank";a.rel="noopener";
      const img=document.createElement("img");img.src=url;img.alt="Zdjęcie naprawy";
      img.style.cssText="width:88px;height:88px;object-fit:cover;border-radius:9px;border:1px solid #344963";
      a.appendChild(img);host.appendChild(a);
    }catch(error){console.warn("Nie udało się wyświetlić pliku",path,error);}
  }
}

async function loadJsPDF(){
  if(window.jspdf && window.jspdf.jsPDF) return window.jspdf.jsPDF;
  if(window.__dkPdfLoading) return window.__dkPdfLoading;
  window.__dkPdfLoading=new Promise((resolve,reject)=>{
    const script=document.createElement("script");
    script.src="./lib/jspdf.umd.min.js";
    script.onload=()=>resolve(window.jspdf.jsPDF);
    script.onerror=()=>reject(new Error("Nie udało się załadować biblioteki PDF. Sprawdź połączenie z internetem."));
    document.head.appendChild(script);
  });
  return window.__dkPdfLoading;
}
function pdfText(value){
  return String(value??"—").replace(/\s+/g," ").trim() || "—";
}
async function loadPdfFont(doc, filename, family, style){
  const response=await fetch("./lib/"+filename);
  if(!response.ok)throw new Error("Nie udało się załadować czcionki PDF: "+filename);
  const bytes=new Uint8Array(await response.arrayBuffer());
  let binary="";
  for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
  const base64=btoa(binary);
  doc.addFileToVFS(filename,base64);
  doc.addFont(filename,family,style);
}
async function loadPdfFont(doc, filename, family, style){
  const response=await fetch("./lib/"+filename);
  if(!response.ok)throw new Error("Nie udało się załadować czcionki PDF: "+filename);
  const bytes=new Uint8Array(await response.arrayBuffer());
  let binary="";
  for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
  const base64=btoa(binary);
  doc.addFileToVFS(filename,base64);
  doc.addFont(filename,family,style);
}
async function createRepairPdf(x, action="print"){
  const JsPDF=await loadJsPDF();
  const doc=new JsPDF({unit:"mm",format:"a4",compress:true});
  await loadPdfFont(doc,"Lato-Regular.ttf","Lato","normal");
  await loadPdfFont(doc,"Lato-Bold.ttf","Lato","bold");
  const W=210,H=297,M=14,CW=W-M*2;
  const navy=[24,39,59], orange=[226,145,47], ink=[42,52,65], muted=[104,116,130], pale=[244,247,250], line=[222,228,234];
  let y=14;
  const fmtDate=v=>{if(!v)return "—";const d=new Date(v);return Number.isNaN(d.getTime())?"—":d.toLocaleString("pl-PL",{dateStyle:"short",timeStyle:"short"});};
  const money=v=>v==null||v===""?"—":String(v).replace(".",",")+" zł";
  const txt=v=>String(v??"—").trim()||"—";
  const setFont=(style="normal",size=9,color=ink)=>{doc.setFont("Lato",style);doc.setFontSize(size);doc.setTextColor(...color);};
  const ensure=(h)=>{if(y+h>H-15){doc.addPage();y=16;}};
  const section=(title)=>{
    ensure(13);doc.setFillColor(...pale);doc.roundedRect(M,y,CW,8,1.5,1.5,"F");
    setFont("bold",9,navy);doc.text(title.toUpperCase(),M+3,y+5.4);y+=12;
  };
  const card=(label,value,x0,w,opts={})=>{
    const val=txt(value), font=opts.small?8.5:9.5;
    setFont("normal",font,ink);
    const lines=doc.splitTextToSize(val,w-6);
    const h=Math.max(15,8+lines.length*4.2);
    ensure(h+3);
    doc.setDrawColor(...line);doc.setFillColor(255,255,255);doc.roundedRect(x0,y,w,h,1.5,1.5,"FD");
    setFont("bold",7.2,muted);doc.text(label.toUpperCase(),x0+3,y+4.5);
    setFont("normal",font,ink);doc.text(lines,x0+3,y+9.5);
    return h;
  };
  const grid=(items,cols=2)=>{
    const gap=3,w=(CW-gap*(cols-1))/cols;
    for(let i=0;i<items.length;i+=cols){
      const row=items.slice(i,i+cols);
      let maxH=15;
      row.forEach((it,j)=>{const val=txt(it[1]);setFont("normal",9);const lines=doc.splitTextToSize(val,w-6);maxH=Math.max(maxH,8+lines.length*4.2);});
      ensure(maxH+3);
      row.forEach((it,j)=>card(it[0],it[1],M+j*(w+gap),w));
      y+=maxH+3;
    }
  };
  const paragraph=(label,value)=>{
    const val=txt(value);setFont("normal",9.2,ink);const lines=doc.splitTextToSize(val,CW-8);
    const h=Math.max(16,10+lines.length*4.3);ensure(h+3);
    doc.setDrawColor(...line);doc.setFillColor(255,255,255);doc.roundedRect(M,y,CW,h,1.5,1.5,"FD");
    setFont("bold",7.2,muted);doc.text(label.toUpperCase(),M+4,y+4.5);
    setFont("normal",9.2,ink);doc.text(lines,M+4,y+10);
    y+=h+3;
  };
  // Pobierz pozycje faktycznie dodane do tego zlecenia.
  let usedMaterials=[];
  if(x.id){
    const {data,error}=await sb.from("naprawy_materialy").select("nazwa,jednostka,ilosc,cena_klienta").eq("naprawa_id",x.id).order("created_at");
    if(error)throw new Error("Nie udało się pobrać materiałów do PDF: "+error.message);
    usedMaterials=data||[];
  }
  const materialsSection=()=>{
    section("Wykorzystane części i materiały");
    if(!usedMaterials.length){
      paragraph("Pozycje materiałowe","Nie dodano części ani materiałów do tego zlecenia.");
      return;
    }
    const cols=[M,M+88,M+119,M+151];
    const widths=[85,28,29,31];
    const headers=["Nazwa","Ilość","Cena / jedn.","Wartość"];
    const rowHeight=8;
    const drawRow=(cells,bold=false)=>{
      ensure(rowHeight+1);
      // jsPDF oczekuje osobnych wartości RGB, a nie tablicy przekazanej jako pojedynczy argument.
      doc.setDrawColor(...line);if(bold)doc.setFillColor(...navy);else doc.setFillColor(255,255,255);
      doc.rect(M,y,CW,rowHeight,"FD");
      cells.forEach((v,i)=>{
        setFont(bold?"bold":"normal",bold?7.5:8,bold?[255,255,255]:ink);
        const value=doc.splitTextToSize(String(v),widths[i]-3);
        doc.text(value.slice(0,2),cols[i]+2,y+5.2);
      });
      y+=rowHeight;
    };
    drawRow(headers,true);
    let total=0;
    for(const r of usedMaterials){
      const qty=Number(r.ilosc)||0, price=Number(r.cena_klienta)||0, value=qty*price;
      total+=value;
      drawRow([txt(r.nazwa)+(r.jednostka?" ("+r.jednostka+")":""),String(qty).replace(".",","),money(price),money(value)]);
    }
    ensure(11);setFont("bold",9,navy);doc.text("Razem materiały dla klienta: "+money(total),W-M,y+7,{align:"right"});y+=12;
  };
  // Header
  doc.setFillColor(...navy);doc.roundedRect(0,0,W,42,0,0,"F");
  doc.setFillColor(...orange);doc.roundedRect(M,9,19,19,3,3,"F");
  setFont("bold",13,[255,255,255]);doc.text("2|4",M+3.2,21);
  setFont("bold",15,[255,255,255]);doc.text("DWA I CZTERY KOŁA",M+25,16);
  setFont("normal",9,[224,231,239]);doc.text("SERWIS SAMOCHODOWY  •  ZLECENIE SERWISOWE",M+25,22);
  setFont("bold",10,[255,255,255]);doc.text("NR "+txt(x.numer_protokolu||x.numer),M+25,31);
  y=49;
  section("Dane klienta i pojazdu");
  grid([
    ["Klient",x.klient],["Telefon",x.telefon],
    ["Pojazd",x.pojazd],["Rok pojazdu",x.rok_pojazdu],
    ["Numer rejestracyjny",x.rejestracja],["VIN",x.vin],
    ["Przebieg",x.przebieg==null?"—":String(x.przebieg)+" km"],["Status",x.status]
  ],2);
  section("Terminy i przyjęcie");
  grid([
    ["Data przyjęcia",fmtDate(x.data_przyjecia)],
    ["Planowany termin",fmtDate(x.termin_naprawy)],
    ["Data wydania / odbioru",fmtDate(x.data_odbior||x.data_odbioru)]
  ],2);
  section("Informacje o naprawie");
  paragraph("Zgłoszona usterka",x.opis_usterki||x.zgloszenie);
  paragraph("Diagnoza",x.diagnoza);
  paragraph("Wykonane prace",x.wykonane_prace);
  materialsSection();
  if(x.czesci)paragraph("Dodatkowe uwagi o częściach",x.czesci);
  paragraph("Uwagi",x.uwagi);
  section("Rozliczenie");
  grid([["Suma",money(x.suma)],["Zaliczka",money(x.zaliczka)],["Zapłacono",money(x.zaplacono)]],3);
  ensure(25);
  y=Math.max(y,H-31);
  doc.setDrawColor(...muted);doc.setLineWidth(.25);
  doc.line(M,y,M+78,y);doc.line(W-M-78,y,W-M,y);
  setFont("normal",8,muted);doc.text("Podpis klienta",M,y+5);doc.text("Podpis serwisu",W-M-78,y+5);
  setFont("normal",7,[140,148,158]);doc.text("DWA I CZTERY KOŁA – SERWIS",W/2,H-5,{align:"center"});
  const filename="Zlecenie_"+txt(x.numer_protokolu||x.numer||"serwis").replace(/[^a-zA-Z0-9_-]/g,"_")+".pdf";
  const blob=doc.output("blob");
  const dataUrl=await new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>resolve(String(reader.result||""));
    reader.onerror=()=>reject(new Error("Nie udało się przygotować dokumentu PDF."));
    reader.readAsDataURL(blob);
  });
  const separator=dataUrl.indexOf(",");
  if(separator<0)throw new Error("Nieprawidłowy format pliku PDF.");
  const base64=dataUrl.substring(separator+1);
  const nativeAndroid=window.Capacitor?.isNativePlatform?.() && window.Capacitor?.registerPlugin;

  if(action==="email"){
    const subject="Zlecenie serwisowe nr "+txt(x.numer_protokolu||x.numer||"");
    const emailText=[
      "Dzień dobry,",
      "",
      "W załączeniu przesyłamy dokument zlecenia serwisowego.",
      "Klient: "+txt(x.klient),
      "Pojazd: "+txt(x.pojazd),
      "Numer rejestracyjny: "+txt(x.rejestracja),
      "",
      "DWA I CZTERY KOŁA"
    ].join("\\n");
    if(nativeAndroid){
      const sharing=window.Capacitor.registerPlugin("PrintPdf");
      await sharing.sharePdf({filename,data:base64,subject,text:emailText});
      toast("Otworzono wybór aplikacji do wysłania zlecenia.");
      return;
    }
    const file=new File([blob],filename,{type:"application/pdf"});
    if(navigator.share && navigator.canShare && navigator.canShare({files:[file]})){
      await navigator.share({files:[file],title:subject,text:emailText});
      return;
    }
    const downloadUrl=URL.createObjectURL(blob);
    const link=document.createElement("a");
    link.href=downloadUrl;link.download=filename;document.body.appendChild(link);link.click();link.remove();
    setTimeout(()=>URL.revokeObjectURL(downloadUrl),60000);
    const mailto="mailto:?subject="+encodeURIComponent(subject)+"&body="+encodeURIComponent(emailText+"\\n\\nPDF został pobrany — dołącz go do wiadomości.");
    window.location.href=mailto;
    toast("PDF pobrano. Dołącz go do wiadomości e-mail.");
    return;
  }

  if(nativeAndroid){
    const printer=window.Capacitor.registerPlugin("PrintPdf");
    await printer.printPdf({filename,data:base64});
    toast("Otwarto systemowe okno drukowania Androida.");
    return;
  }
  const url=URL.createObjectURL(blob);
  const printWindow=window.open(url,"_blank");
  if(!printWindow){URL.revokeObjectURL(url);throw new Error("Przeglądarka zablokowała okno podglądu wydruku.");}
  printWindow.addEventListener("load",()=>{
    try{printWindow.focus();printWindow.print();}
    catch(error){toast("PDF jest gotowy. Użyj polecenia Drukuj w podglądzie dokumentu.");}
  },{once:true});
  setTimeout(()=>URL.revokeObjectURL(url),120000);
}

async function recognizeVinFromImage(file){
  if(!window.Tesseract) await new Promise((resolve,reject)=>{
    const script=document.createElement("script");
    script.src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js";
    script.onload=resolve;script.onerror=()=>reject(new Error("Nie udało się załadować OCR. Sprawdź internet."));
    document.head.appendChild(script);
  });
  const result=await window.Tesseract.recognize(file,"eng");
  const match=String(result?.data?.text||"").toUpperCase().match(/[A-HJ-NPR-Z0-9]{17}/);
  if(!match)throw new Error("Nie odczytano pełnego VIN. Zrób wyraźniejsze zdjęcie lub wpisz numer ręcznie.");
  return match[0];
}


async function renderPartsCatalog(){
  const escapeHtml=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
  const host=$("catalogPartsList");
  if(!host)return;
  host.innerHTML='<p class="muted">Pobieranie katalogu…</p>';
  try{
    const {data,error}=await sb.from("materialy_magazyn").select("*").order("nazwa");
    if(error)throw error;
    const all=data||[];
    const draw=()=>{
      const term=String($("searchCatalogParts")?.value||"").trim().toLocaleLowerCase("pl");
      const rows=all.filter(m=>[m.nazwa,m.jednostka].some(v=>String(v||"").toLocaleLowerCase("pl").includes(term)));
      host.innerHTML=rows.map(m=>`<article class="card catalog-part-card"><div class="card-main"><h3>${escapeHtml(m.nazwa)}</h3><div class="catalog-part-prices"><span class="catalog-part-unit">${escapeHtml(m.jednostka||"szt.")}</span><span class="catalog-part-buy">Zakup: <strong>${Number(m.cena_zakupu||0).toFixed(2)} zł</strong></span><span class="catalog-part-client">Klient: <strong>${Number(m.cena_klienta||0).toFixed(2)} zł</strong></span></div><span class="catalog-part-status ${m.aktywny===false?"is-inactive":"is-active"}">${m.aktywny===false?"Nieaktywny":"Aktywny"}</span></div><div class="card-actions catalog-part-actions"><button type="button" data-edit-part="${escapeHtml(m.id)}" class="secondary catalog-edit-btn">Edytuj</button><button type="button" data-delete-part="${escapeHtml(m.id)}" class="secondary catalog-delete-btn">Usuń</button></div></article>`).join("")||'<p class="muted">Brak części w katalogu. Dodaj pierwszą pozycję przyciskiem „Dodaj część”.</p>';
      host.querySelectorAll("[data-edit-part]").forEach(b=>b.onclick=async()=>{
        const m=all.find(v=>String(v.id)===String(b.dataset.editPart));if(!m)return;
        const name=prompt("Nazwa części:",m.nazwa);if(name===null)return;if(!name.trim()){alert("Nazwa nie może być pusta.");return;}
        const unit=prompt("Jednostka (np. szt., litr, komplet):",m.jednostka||"szt.");if(unit===null)return;
        const buy=Number(String(prompt("Cena zakupu za jednostkę:",m.cena_zakupu??0)||"").replace(",","."));
        const sell=Number(String(prompt("Cena dla klienta za jednostkę:",m.cena_klienta??0)||"").replace(",","."));
        if(!Number.isFinite(buy)||buy<0||!Number.isFinite(sell)||sell<0){alert("Podaj prawidłowe, nieujemne ceny.");return;}
        const {data:updated,error}=await sb.from("materialy_magazyn").update({nazwa:name.trim(),jednostka:unit.trim()||"szt.",cena_zakupu:buy,cena_klienta:sell,updated_at:new Date().toISOString()}).eq("id",m.id).select("*").single();
        if(error){alert("Nie udało się zapisać zmian: "+error.message);return;}
        all.splice(all.indexOf(m),1,updated);all.sort((a,b)=>String(a.nazwa).localeCompare(String(b.nazwa),"pl"));draw();
      });
      host.querySelectorAll("[data-delete-part]").forEach(b=>b.onclick=async()=>{
        const m=all.find(v=>String(v.id)===String(b.dataset.deletePart));if(!m)return;
        if(!confirm(`Usunąć „${m.nazwa}” z katalogu?\n\nCzęści już zapisane w zleceniach pozostaną bez zmian.`))return;
        const {error}=await sb.from("materialy_magazyn").delete().eq("id",m.id);
        if(error){alert("Nie udało się usunąć części: "+error.message);return;}
        all.splice(all.indexOf(m),1);draw();
      });
    };
    $("searchCatalogParts").oninput=draw;
    $("addCatalogPart").onclick=async()=>{
      const name=prompt("Nazwa części:");if(!name?.trim())return;
      const unit=prompt("Jednostka (np. szt., litr, komplet):","szt.")||"szt.";
      const buy=Number(String(prompt("Cena zakupu za jednostkę:","0")||"").replace(",","."));
      const sell=Number(String(prompt("Cena dla klienta za jednostkę:","0")||"").replace(",","."));
      if(!Number.isFinite(buy)||buy<0||!Number.isFinite(sell)||sell<0){alert("Podaj prawidłowe, nieujemne ceny.");return;}
      const {data,error}=await sb.from("materialy_magazyn").insert({nazwa:name.trim(),jednostka:unit.trim()||"szt.",cena_zakupu:buy,cena_klienta:sell}).select("*").single();
      if(error){alert("Nie udało się dodać części: "+error.message);return;}
      all.push(data);all.sort((a,b)=>String(a.nazwa).localeCompare(String(b.nazwa),"pl"));draw();
    };
    draw();
  }catch(e){host.innerHTML=`<p class="muted">Nie udało się pobrać katalogu: ${escapeHtml(e.message)}</p>`;}
}

async function openRepairMaterials(repairId){
  const {data:catalog,error:catalogError}=await sb.from("materialy_magazyn").select("*").eq("aktywny",true).order("nazwa");
  if(catalogError)throw catalogError;
  const {data:used,error:usedError}=await sb.from("naprawy_materialy").select("*").eq("naprawa_id",repairId).order("created_at");
  if(usedError)throw usedError;
  let rows=used||[];
  const dlg=document.createElement("dialog");
  dlg.style.cssText="width:min(720px,94vw);max-height:90vh;overflow:auto;border:1px solid #344963;border-radius:16px;padding:18px;background:#101b2b;color:#fff";
  const money=n=>(Number(n)||0).toLocaleString("pl-PL",{minimumFractionDigits:2,maximumFractionDigits:2})+" zł";
  const escapeHtml=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const render=()=>{
    const cost=rows.reduce((s,r)=>s+Number(r.ilosc)*Number(r.cena_zakupu),0);
    const sell=rows.reduce((s,r)=>s+Number(r.ilosc)*Number(r.cena_klienta),0);
    dlg.innerHTML=`<h2 style="margin:0 0 6px">Wykorzystane materiały</h2><p class="muted">Prywatne dane serwisu — klient nie zobaczy cen zakupu ani marży.</p>
      <div style="overflow:auto"><table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr><th>Materiał</th><th>Ilość</th><th>Zakup/szt.</th><th>Klient/szt.</th><th></th></tr></thead><tbody>
      ${rows.map(r=>`<tr><td>${escapeHtml(r.nazwa)}<br><small>${escapeHtml(r.jednostka)}</small></td><td>${Number(r.ilosc)}</td><td>${money(r.cena_zakupu)}</td><td>${money(r.cena_klienta)}</td><td><button type="button" data-del="${r.id}" class="secondary">Usuń</button></td></tr>`).join("")||'<tr><td colspan="5">Brak dodanych materiałów.</td></tr>'}
      </tbody></table></div>
      <div style="padding:12px;background:#1b2b40;border-radius:10px;margin:12px 0">
      <div>Koszt zakupu: <b>${money(cost)}</b></div><div>Wartość dla klienta: <b>${money(sell)}</b></div><div style="font-size:18px;margin-top:5px">Marża: <b style="color:#36b37e">${money(sell-cost)}</b></div></div>
      <button type="button" id="addUsedMaterial">＋ Dodaj materiał do zlecenia</button>
      <button type="button" id="manageMaterialCatalog" class="secondary" style="margin-left:6px">＋ Nowy materiał w bazie</button>
      <button type="button" id="closeMaterials" class="secondary" style="margin-top:12px;width:100%">Zamknij</button>`;
    dlg.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{
      const row=rows.find(r=>String(r.id)===String(b.dataset.del));
      if(!row)return;
      if(!confirm(`Usunąć pozycję „${row.nazwa}” z tego zlecenia?`))return;
      b.disabled=true;
      try{
        const {error}=await sb.from("naprawy_materialy").delete().eq("id",row.id);
        if(error)throw error;
        rows=rows.filter(r=>String(r.id)!==String(row.id));
        render();
      }catch(e){b.disabled=false;alert("Nie udało się usunąć pozycji: "+e.message);}
    });
    dlg.querySelector("#closeMaterials").onclick=()=>dlg.close();
    dlg.querySelector("#addUsedMaterial").onclick=async()=>{
      if(!catalog.length){alert("Najpierw dodaj materiał do bazy.");return;}
      const picker=document.createElement("dialog");
      picker.style.cssText="border:1px solid #34465d;border-radius:16px;padding:18px;width:min(92vw,520px);max-height:85vh;background:#101b2b;color:#fff";
      picker.innerHTML=`<h3 style="margin:0 0 12px">Wybierz materiał</h3>
        <input id="materialSearch" type="search" placeholder="Szukaj materiału, np. olej, filtr, świece..." style="width:100%;box-sizing:border-box;padding:13px;border-radius:10px;border:1px solid #52647b;background:#17263a;color:#fff;font-size:16px">
        <div id="materialResults" style="overflow:auto;max-height:48vh;margin-top:12px"></div>
        <button type="button" id="cancelMaterialPicker" class="secondary" style="width:100%;margin-top:12px">Anuluj</button>`;
      const results=picker.querySelector("#materialResults");
      const search=picker.querySelector("#materialSearch");
      const chooseMaterial=async id=>{
        const m=catalog.find(item=>String(item.id)===String(id));if(!m)return;
        const raw=prompt("Ilość ("+m.jednostka+")","1");if(raw===null)return;
        const qty=Number(String(raw).replace(",","."));
        if(!Number.isFinite(qty)||qty<=0){alert("Podaj prawidłową ilość.");return;}
        picker.close();picker.remove();
        const {data,error}=await sb.from("naprawy_materialy").insert({naprawa_id:repairId,material_id:m.id,nazwa:m.nazwa,jednostka:m.jednostka,ilosc:qty,cena_zakupu:m.cena_zakupu,cena_klienta:m.cena_klienta}).select("*").single();
        if(error){alert(error.message);return;}rows.push(data);render();
      };
      const drawResults=()=>{
        const q=search.value.trim().toLocaleLowerCase("pl");
        const found=catalog.filter(m=>(m.nazwa+" "+(m.jednostka||"")).toLocaleLowerCase("pl").includes(q));
        results.innerHTML=found.map(m=>`<div style="background:#20334c;border-radius:12px;padding:12px;margin:0 0 10px">
          <div style="font-weight:700;font-size:16px;margin-bottom:4px">${escapeHtml(m.nazwa)}</div>
          <div style="font-size:13px;color:#d2dbea;margin-bottom:10px">${escapeHtml(m.jednostka||"szt.")} · zakup ${money(m.cena_zakupu)} · klient ${money(m.cena_klienta)}</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button type="button" data-select-material="${escapeHtml(m.id)}" style="flex:1;min-width:100px">Wybierz</button>
            <button type="button" data-edit-material="${escapeHtml(m.id)}" class="secondary" style="flex:1;min-width:85px">Edytuj</button>
            <button type="button" data-delete-material="${escapeHtml(m.id)}" class="secondary" style="flex:1;min-width:85px;background:#8f3038;color:#fff">Usuń</button>
          </div>
        </div>`).join("")||'<p style="color:#aab7c7;text-align:center;padding:16px">Nie znaleziono materiałów.</p>';
        results.querySelectorAll("[data-select-material]").forEach(btn=>btn.onclick=()=>chooseMaterial(btn.dataset.selectMaterial));
        results.querySelectorAll("[data-edit-material]").forEach(btn=>btn.onclick=async()=>{
          const m=catalog.find(item=>String(item.id)===String(btn.dataset.editMaterial));if(!m)return;
          const nazwa=prompt("Popraw nazwę materiału:",m.nazwa);if(nazwa===null)return;
          if(!nazwa.trim()){alert("Nazwa nie może być pusta.");return;}
          const jednostka=prompt("Popraw jednostkę:",m.jednostka||"szt.");if(jednostka===null)return;
          if(!jednostka.trim()){alert("Jednostka nie może być pusta.");return;}
          const zakupRaw=prompt("Popraw cenę zakupu za jednostkę:",String(m.cena_zakupu).replace(".",","));if(zakupRaw===null)return;
          const klientRaw=prompt("Popraw cenę dla klienta za jednostkę:",String(m.cena_klienta).replace(".",","));if(klientRaw===null)return;
          const zakup=Number(String(zakupRaw).replace(",","."));
          const klient=Number(String(klientRaw).replace(",","."));
          if(!Number.isFinite(zakup)||zakup<0||!Number.isFinite(klient)||klient<0){alert("Ceny muszą być prawidłowymi kwotami większymi lub równymi zero.");return;}
          btn.disabled=true;
          const {data,error}=await sb.from("materialy_magazyn").update({nazwa:nazwa.trim(),jednostka:jednostka.trim(),cena_zakupu:zakup,cena_klienta:klient,updated_at:new Date().toISOString()}).eq("id",m.id).select("*").single();
          if(error){btn.disabled=false;alert("Nie udało się poprawić materiału: "+error.message);return;}
          Object.assign(m,data);catalog.sort((a,b)=>a.nazwa.localeCompare(b.nazwa,"pl"));drawResults();
        });
        results.querySelectorAll("[data-delete-material]").forEach(btn=>btn.onclick=async()=>{
          const m=catalog.find(item=>String(item.id)===String(btn.dataset.deleteMaterial));if(!m)return;
          if(!confirm(`Czy na pewno całkowicie usunąć „${m.nazwa}” z bazy materiałów?\n\nPozycje już zapisane w zleceniach zachowają swoje nazwy, ilości i ceny.`))return;
          btn.disabled=true;
          const {error}=await sb.from("materialy_magazyn").delete().eq("id",m.id);
          if(error){btn.disabled=false;alert("Nie udało się usunąć materiału: "+error.message);return;}
          catalog=catalog.filter(item=>String(item.id)!==String(m.id));
          drawResults();
        });
      };
      search.addEventListener("input",drawResults);
      picker.querySelector("#cancelMaterialPicker").onclick=()=>{picker.close();picker.remove();};
      document.body.appendChild(picker);drawResults();
      if(picker.showModal)picker.showModal();else picker.setAttribute("open","");
      search.focus();
    };
    dlg.querySelector("#manageMaterialCatalog").onclick=async()=>{
      const nazwa=prompt("Nazwa nowego materiału:");if(!nazwa?.trim())return;
      const jednostka=prompt("Jednostka (np. szt., litr, komplet):","szt.")||"szt.";
      const zakup=Number(String(prompt("Cena zakupu za jednostkę:","0")||"").replace(",","."));
      const klient=Number(String(prompt("Cena dla klienta za jednostkę:","0")||"").replace(",","."));
      if(!Number.isFinite(zakup)||zakup<0||!Number.isFinite(klient)||klient<0){alert("Ceny muszą być prawidłowymi kwotami.");return;}
      const {data,error}=await sb.from("materialy_magazyn").insert({nazwa:nazwa.trim(),jednostka,cena_zakupu:zakup,cena_klienta:klient}).select("*").single();
      if(error){alert(error.message);return;}catalog.push(data);catalog.sort((a,b)=>a.nazwa.localeCompare(b.nazwa,"pl"));render();
    };
  };
  document.body.appendChild(dlg);render();
  if(dlg.showModal)dlg.showModal();else dlg.setAttribute("open","");
  dlg.addEventListener("close",()=>dlg.remove(),{once:true});
}

async function editRepair(x){
  let assignedNumber=x.numer_protokolu||x.numer||"";
  if(!x.id && !assignedNumber){
    try{assignedNumber=await nextRepairNumber();}
    catch(err){toast("Nie udało się nadać numeru zlecenia: "+err.message);return;}
  }
  const existingPhotos=getPhotoPaths(x.zdjecia_lokalne);
  openEditor(x.id?"Edycja naprawy":"Nowa naprawa",
    field("Numer protokołu","numer_protokolu",assignedNumber)+
    field("Klient","klient",x.klient)+field("Telefon","telefon",x.telefon)+checkboxField("Klient wyraził zgodę na powiadomienia SMS","sms_zgoda",x.sms_zgoda===true)+
    field("Pojazd","pojazd",x.pojazd)+field("Rok pojazdu","rok_pojazdu",x.rok_pojazdu??"","number")+
    field("Rejestracja","rejestracja",x.rejestracja)+
    field("VIN (17 znaków)","vin",x.vin||vehicles.find(v=>String(v.id)===String(x.pojazd_id))?.vin||"")+
    field("Przebieg (km)","przebieg",x.przebieg??"","number")+

    field("Data i godzina przyjęcia","data_przyjecia",x.data_przyjecia||(!x.id?new Date().toISOString():""),"datetime-local")+
    field("Planowany termin (data i godzina)","termin_naprawy",x.termin_naprawy,"datetime-local")+
    field("Data i godzina odbioru","data_odbioru",x.data_odbior??x.data_odbioru,"datetime-local")+
    selectField("Status naprawy","status",REPAIR_STATUSES,x.status||"PRZYJĘTY")+
    area("Zgłoszona usterka","opis_usterki",x.opis_usterki||x.zgloszenie)+
    area("Diagnoza","diagnoza",x.diagnoza)+area("Wykonane prace","wykonane_prace",x.wykonane_prace)+
    area("Części","czesci",x.czesci)+
    field("Suma","suma",x.suma)+field("Zaliczka","zaliczka",x.zaliczka)+
    field("Zapłacono","zaplacono",x.zaplacono)+area("Uwagi","uwagi",x.uwagi)+
    `<div class="photo-picker" style="display:flex;gap:10px;flex-wrap:wrap;margin:10px 0">
      <button type="button" id="takeRepairPhoto" class="secondary">📷 Zrób zdjęcie</button>
      <button type="button" id="chooseRepairPhotos" class="secondary">🖼️ Wybierz z galerii</button>
      <input id="repairCameraPhotos" type="file" accept="image/*" capture="environment" multiple style="display:none">
      <input id="repairGalleryPhotos" type="file" accept="image/*" multiple style="display:none">
    </div><div id="photoCurrent" style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0"></div><p class="muted">Możesz zrobić zdjęcie aparatem albo zaznaczyć kilka zdjęć z galerii. Wybrane zdjęcia zostaną dodane do tego zlecenia.</p>`,
    async d=>{
      const assigned=d.numer_protokolu||assignedNumber;
      const payload={...d,numer:assigned,numer_protokolu:assigned,
        sms_zgoda:d.sms_zgoda==="true",
        klient_id:x.klient_id||null,pojazd_id:x.pojazd_id||null};
      // data_odbioru is only the form field name; the database column is data_odbior.
      // Remove the empty UI alias so Supabase never receives "" for a timestamp column.
      delete payload.data_odbioru;
      const vin=String(d.vin||"").toUpperCase().replace(/[^A-Z0-9]/g,"");
      if(vin&&!/^[A-HJ-NPR-Z0-9]{17}$/.test(vin))throw new Error("VIN musi mieć 17 znaków i nie może zawierać I, O ani Q.");
      delete payload.vin;
      const mileageRaw=String(d.przebieg??"").trim();
      payload.przebieg=mileageRaw===""?null:Number(mileageRaw);
      if(payload.przebieg!==null&&(!Number.isSafeInteger(payload.przebieg)||payload.przebieg<0))throw new Error("Przebieg musi być nieujemną liczbą całkowitą.");
      const toIso=value=>value?new Date(value).toISOString():null;
      payload.data_przyjecia=toIso(d.data_przyjecia)||(!x.id?new Date().toISOString():null);
      payload.termin_naprawy=toIso(d.termin_naprawy);
      payload.data_odbior=toIso(d.data_odbioru);
      const yearRaw=String(d.rok_pojazdu??"").trim();
      payload.rok_pojazdu=yearRaw===""?null:Number(yearRaw);
      if(payload.rok_pojazdu!==null&&(!Number.isInteger(payload.rok_pojazdu)||payload.rok_pojazdu<1886||payload.rok_pojazdu>new Date().getFullYear()+2))throw new Error("Wpisz prawidłowy rok pojazdu.");
      if(payload.termin_naprawy&&payload.data_przyjecia&&new Date(payload.termin_naprawy)<new Date(payload.data_przyjecia))throw new Error("Planowany termin nie może być wcześniejszy niż przyjęcie pojazdu.");
      for(const key of ["suma","zaliczka","zaplacono"]){const raw=String(d[key]??"").trim();payload[key]=raw===""?null:Number(raw.replace(",","."));if(payload[key]!==null&&!Number.isFinite(payload[key]))throw new Error(`Nieprawidłowa wartość w polu: ${key}`)}
      delete payload.numer_protokolu;
      // Automatyczne znalezienie lub utworzenie klienta.
      const clientName=String(d.klient||"").trim().replace(/\s+/g," ");
      const clientPhone=String(d.telefon||"").trim();
      if(!payload.klient_id && clientName){
        const {data:knownClients,error:clientLookupError}=await sb
          .from("klienci").select("id,imie_nazwisko,telefon").limit(5000);
        if(clientLookupError) throw clientLookupError;

        const digits=value=>String(value||"").replace(/\D/g,"");
        const normName=value=>String(value||"").trim().replace(/\s+/g," ").toLowerCase();
        const phoneDigits=digits(clientPhone);
        let matchedClient=null;

        if(phoneDigits){
          matchedClient=(knownClients||[]).find(c=>digits(c.telefon)===phoneDigits);
        }
        if(!matchedClient){
          matchedClient=(knownClients||[]).find(c=>
            normName(c.imie_nazwisko)===normName(clientName) &&
            (!phoneDigits || !digits(c.telefon))
          );
        }

        if(matchedClient){
          payload.klient_id=matchedClient.id;
        }else{
          const {data:newClient,error:clientInsertError}=await sb
            .from("klienci")
            .insert({imie_nazwisko:clientName,telefon:clientPhone||null})
            .select("id").single();
          if(clientInsertError) throw clientInsertError;
          payload.klient_id=newClient.id;
        }
      }

      let repairId=x.id;

      // Znajdź lub utwórz pojazd na podstawie numeru rejestracyjnego
      // (jeśli go brak, użyj nazwy pojazdu). Nie twórz duplikatu.
      const reg=String(d.rejestracja||"").trim().toUpperCase();
      const nazwaPojazdu=String(d.pojazd||"").trim();

      if(!x.pojazd_id && (reg || nazwaPojazdu)){
        let query=sb.from("pojazdy").select("id,vin");

        if(reg){
          query=query.eq("rejestracja",reg);
        }else{
          query=query.eq("marka_model",nazwaPojazdu);
        }

        const {data:existingVehicle,error:vehicleLookupError}=await query.limit(1).maybeSingle();
        if(vehicleLookupError) throw vehicleLookupError;

        if(existingVehicle){
          payload.pojazd_id=existingVehicle.id;
          if(vin){const {error:ve}=await sb.from("pojazdy").update({vin}).eq("id",existingVehicle.id);if(ve)throw ve;}
        }else{
          const normalizedClient=String(d.klient||"").trim().toLowerCase();
          const matchedClient=clients.find(c=>
            String(c.imie_nazwisko||"").trim().toLowerCase()===normalizedClient
          );
          const vehicleData={
            klient_id:x.klient_id||matchedClient?.id||null,
            marka_model:nazwaPojazdu||null,
            rejestracja:reg||null,
            vin:vin||null
          };

          const {data:newVehicle,error:vehicleInsertError}=await sb
            .from("pojazdy")
            .insert(vehicleData)
            .select("id")
            .single();

          if(vehicleInsertError) throw vehicleInsertError;
          payload.pojazd_id=newVehicle.id;
        }
      }

      if(payload.pojazd_id&&vin){const {error:ve}=await sb.from("pojazdy").update({vin}).eq("id",payload.pojazd_id);if(ve)throw ve;}
      const previousStatus=String(x.status||"").trim();
      const normalizeStatus=value=>String(value||"").normalize("NFD").replace(/[\\u0300-\\u036f]/g,"").toLowerCase().trim();
      if(normalizeStatus(d.status)==="wydano klientowi" && !payload.data_odbior){
        payload.data_odbior=new Date().toISOString();
      }
      if(x.id){
        const {error}=await sb.from("naprawy").update(payload).eq("id",x.id);
        if(error) throw error;
      }else{
        const {data,error}=await sb.from("naprawy").insert(payload).select("id").single();
        if(error) throw error;
        repairId=data.id;
      }
      const files=[
        ...Array.from($("repairCameraPhotos")?.files||[]),
        ...Array.from($("repairGalleryPhotos")?.files||[])
      ];
      if(files.length){
        const paths=await uploadRepairPhotos(repairId,files,existingPhotos,payload.klient_id||x.klient_id||null);
        const {error}=await sb.from("naprawy").update({zdjecia_lokalne:JSON.stringify(paths)}).eq("id",repairId);
        if(error)throw error;
        toast(`Wysłano ${files.length} plik(ów) na Dysk Google.`);

      }

      // Po zapisaniu nowej naprawy zapytaj o wysłanie klientowi bezpiecznego linku SMS.
      // SMS jest tylko przygotowywany w aplikacji telefonu — użytkownik sam go wysyła.
      if(!x.id && payload.sms_zgoda && clientPhone && repairId){
        const shouldSendLink=confirm("Naprawa została zapisana. Czy przygotować SMS dla klienta z bezpiecznym linkiem do podglądu naprawy?");
        if(shouldSendLink){
          try{
            const {data:{session}}=await sb.auth.getSession();
            if(!session) throw new Error("Sesja wygasła. Zaloguj się ponownie.");
            const response=await fetch(PROJECT_URL+"/functions/v1/klient-qr",{
              method:"POST",
              headers:{
                "Content-Type":"application/json",
                "Authorization":"Bearer "+session.access_token,
                "apikey":localStorage.getItem("dk_publishable")
              },
              body:JSON.stringify({action:"create",repair_id:repairId})
            });
            const result=await response.json();
            if(!response.ok) throw new Error(result.error||"Nie udało się utworzyć linku.");
            if(!result.url) throw new Error("Serwer nie zwrócił adresu podglądu.");
            const label=assigned||`#${repairId}`;
            const message=`Dwa i Cztery Koła: Twoje zlecenie ${label} zostało przyjęte. Bezpieczny podgląd statusu naprawy: ${result.url}`;
            await sendStatusSms(clientPhone,message);
            toast("Otworzono SMS z linkiem. Naciśnij Wyślij w aplikacji wiadomości.");
          }catch(smsError){
            console.error("SMS z linkiem klienta:",smsError);
            alert("NAPRAWA ZOSTAŁA ZAPISANA, ALE NIE UDAŁO SIĘ PRZYGOTOWAĆ SMS.\\n\\n"+smsError.message);
          }
        }
      }
      const newStatus=String(d.status||"").trim();
      if(x.id && previousStatus && newStatus && previousStatus!==newStatus && payload.sms_zgoda){
        const phone=String(d.telefon||x.telefon||"").trim();
        const label=assigned||`#${repairId}`;
        const message=`Dwa i Cztery Koła: status naprawy ${label} zmienił się na: ${newStatus}.`;
        try{
          if(!phone) throw new Error("Brak numeru telefonu klienta.");
          await sendStatusSms(phone,message);
          toast("Status zapisany. SMS wysłany.");
        }catch(smsError){
          console.error("SMS status error",smsError);
          alert("STATUS ZAPISANY, ALE SMS NIE ZOSTAŁ WYSŁANY.\n\nPRZYCZYNA:\n" + smsError.message);
        }
      }
    });
   const cameraInput=$("repairCameraPhotos");
  const galleryInput=$("repairGalleryPhotos");
  const previewSelectedPhotos=()=>{
    const host=$("photoCurrent"); if(!host) return;
    host.querySelectorAll("[data-pending-photo]").forEach(node=>node.remove());
    const chosen=[...Array.from(cameraInput?.files||[]),...Array.from(galleryInput?.files||[])];
    for(const file of chosen){
      if(!file.type.startsWith("image/")) continue;
      const url=URL.createObjectURL(file);
      const img=document.createElement("img");img.src=url;img.alt="Wybrane zdjęcie — oczekuje na zapis";
      img.dataset.pendingPhoto="1";
      img.style.cssText="width:88px;height:88px;object-fit:cover;border-radius:9px;border:2px solid #e5a23b";
      img.onload=()=>URL.revokeObjectURL(url);
      host.appendChild(img);
    }
    if(chosen.length) toast(`Wybrano ${chosen.length} plik(ów). Zapisz zlecenie, aby wysłać je na Dysk Google.`);
  };
  cameraInput?.addEventListener("change",previewSelectedPhotos);
  galleryInput?.addEventListener("change",previewSelectedPhotos);
  

function decodeAztecRegistrationPayload(raw){
  const clean=String(raw||"").trim().replace(/\s+/g,"");
  if(!clean) throw new Error("Kod Aztec jest pusty.");
  const candidates=[clean,clean.slice(0,-1)];
  let lastError=null;
  for(const candidate of candidates){
    try{
      const binary=atob(candidate.replace(/-/g,"+").replace(/_/g,"/").replace(/[^A-Za-z0-9+/=]/g,""));
      const src=Uint8Array.from(binary,c=>c.charCodeAt(0));
      if(src.length<8) continue;
      const size=(src[0]|(src[1]<<8)|(src[2]<<16)|(src[3]<<24))>>>0;
      if(!size||size>200000) continue;
      const out=new Uint8Array(size);let ip=4,op=0,bit=0,cur=0,lastOffset=1;
      const readBit=()=>{if(ip>=src.length)throw new Error("Niepełne dane");if(bit===0){cur=src[ip++];bit=8;}return (cur>>--bit)&1;};
      const readByte=()=>{if(ip>=src.length)throw new Error("Niepełne dane");return src[ip++];};
      let ended=false,guard=0;
      while(!ended&&op<size&&guard++<size*4){
        while(readBit()===1){if(op>=size)throw new Error("Przekroczony rozmiar");out[op++]=readByte();}
        let off=1;
        while(true){off=off*2+readBit();if(readBit()===1)break;off=(off-1)*2+readBit();if(off>0x100000)throw new Error("Nieprawidłowy offset");}
        let len;
        if(off===2){off=lastOffset;len=readBit();}
        else{off=(off-3)*256+readByte();if(off===1){ended=true;break;}len=(off^1)&1;off=Math.floor(off/2);lastOffset=++off;}
        if(len>0)len=1+readBit();
        else if(readBit()===1)len=3+readBit();
        else{len++;do{len=len*2+readBit();}while(readBit()===0);len+=3;}
        len+=(off>0x500?1:0);
        let pos=op-off;if(pos<0||op+len+1>size)throw new Error("Nieprawidłowe odwołanie danych");
        out[op++]=out[pos++];while(len-->0)out[op++]=out[pos++];
      }
      if(op!==size) throw new Error("Niepełny wynik dekompresji");
      return new TextDecoder("utf-16le").decode(out).replace(/\0+$/g,"");
    }catch(e){lastError=e;}
  }
  throw new Error("Kod został zeskanowany, ale nie udało się odczytać jego zawartości."+(lastError?" ("+lastError.message+")":""));
}
function extractSafeAztecVehicleData(text){
  const fields=String(text||"").split("|");
  const clean=value=>String(value||"").replace(/[\u0000-\u001F\u007F-\u009F]/g,"").trim().slice(0,80);
  const unavailable="Niedostępne";
  let result;

  if(clean(fields[0]).toUpperCase()==="XXC1"){
    result={
      format:clean(fields[0])||unavailable,
      marka:clean(fields[8])||unavailable,
      typ:clean(fields[9])||unavailable,
      model:clean(fields[12])||unavailable
    };
  }else{
    result={
      format:unavailable,
      marka:clean(fields[6])||unavailable,
      typ:unavailable,
      model:clean(fields[10])||unavailable
    };
  }

  if(result.marka===unavailable&&result.model===unavailable){
    throw new Error("Nie rozpoznano obs?ugiwanego uk?adu danych pojazdu.");
  }
  return result;
}
  $("takeRepairPhoto").onclick=()=>cameraInput?.click();
  $("chooseRepairPhotos").onclick=()=>galleryInput?.click();
  showRepairPhotos(existingPhotos);
}
$("saveRecord").onclick=()=>{};
async function createBackupNow(){
  const button=$("createBackupButton");
  if(!button || button.disabled) return;
  const plugin=getBackupPlugin();
  if(!plugin){
    setBackupStatus("Tworzenie kopii jest dostępne w aplikacji na Androidzie.");
    return;
  }
  button.disabled=true;
  let archivePath=null;
  let archiveOpen=false;
  try{
    setBackupStatus("Wybierz miejsce zapisania kopii…");
    const destination=await plugin.chooseSaveLocation();
    if(destination?.cancelled){
      setBackupStatus("Anulowano tworzenie kopii zapasowej.");
      return;
    }
    if(!destination?.uri) throw new Error("Nie otrzymano miejsca zapisu pliku.");
    setBackupStatus("Przygotowywanie archiwum kopii zapasowej…");
    const started=await plugin.beginBackupArchive();
    if(!started?.success || !started?.filePath){
      throw new Error("Nie udało się rozpocząć tworzenia archiwum.");
    }
    archivePath=started.filePath;
    archiveOpen=true;
    await buildBackupArchive(plugin);
    setBackupStatus("Kończenie archiwum…");
    const finished=await plugin.finishBackupArchive();
    archiveOpen=false;
    if(!finished?.success || !finished?.filePath){
      throw new Error("Nie udało się zakończyć archiwum ZIP.");
    }
    archivePath=finished.filePath;
    setBackupStatus("Szyfrowanie i zapisywanie kopii na telefonie…");
    const encrypted=await plugin.encryptFileToUri({
      sourcePath:archivePath,
      destinationUri:destination.uri
    });
    if(!encrypted?.success) throw new Error("Nie udało się zapisać zaszyfrowanej kopii.");
    try{
      const cleanup=await plugin.deleteTemporaryBackupFile({filePath:archivePath});
      if(!cleanup?.success){
        setBackupStatus("Kopia została zapisana, ale nie udało się usunąć pliku tymczasowego.");
        return;
      }
      archivePath=null;
    }catch(cleanupError){
      setBackupStatus("Kopia została zapisana, ale pozostał plik tymczasowy w pamięci aplikacji.");
      return;
    }
    setBackupStatus("Kopia zapasowa została zapisana i zaszyfrowana.");
  }catch(error){
    if(archiveOpen){
      try{await plugin.abortBackupArchive();}catch(abortError){}
    }
    if(archivePath){
      try{await plugin.deleteTemporaryBackupFile({filePath:archivePath});}catch(cleanupError){}
    }
    setBackupStatus("Nie udało się utworzyć kopii: "+(error?.message||String(error)));
  }finally{
    button.disabled=false;
  }
}
$("createBackupButton").onclick=createBackupNow;
$("restoreBackupButton").onclick=()=>{
  setBackupStatus("Przywracanie kopii nie jest jeszcze dostępne. Obecne dane nie zostały zmienione.");
};
$("updateAppButton").onclick=installAvailableAppUpdate;
$("checkAppUpdateButton").onclick=()=>checkForAppUpdate(true);
init();
checkForAppUpdate();
window.addEventListener("focus",checkForAppUpdate);
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js"));


// ===== SYSTEMOWA BLOKADA ANDROIDA =====
(()=>{
 const el=id=>document.getElementById(id);
 const isNative=()=>!!(window.Capacitor?.isNativePlatform?.());
 const security=()=>isNative()?window.Capacitor.registerPlugin("Security"):null;
 let lockReady=false,locked=false,backgrounded=false,authBusy=false;
 const showLock=(message)=>{
   const panel=el("securityLock"); if(!panel||locked)return;
   locked=true; panel.classList.remove("hidden");
   el("securityLockHint").textContent=message||"Potwierdź tożsamość blokadą ustawioną w telefonie.";
   el("securityLockError").textContent="";
   document.body.style.overflow="hidden";
 };
 const hideLock=()=>{
   locked=false;el("securityLock").classList.add("hidden");
   document.body.style.overflow="";
 };
 const status=async()=>{
   const p=security(); if(!p)throw Error("Zabezpieczenia systemowe są dostępne w aplikacji Android.");
   return await p.getDeviceSecurityStatus();
 };
 const unlock=async()=>{
   if(authBusy)return;authBusy=true;
   const btn=el("securityUnlockButton");if(btn){btn.disabled=true;btn.textContent="Oczekiwanie na potwierdzenie…";}
   try{
     const p=security();if(!p)throw Error("Zabezpieczenia systemowe są dostępne w aplikacji Android.");
     const st=await p.getDeviceSecurityStatus();
     if(!st.deviceSecure){
       el("securityLockError").textContent="W telefonie nie ma ustawionej blokady ekranu. Ustaw PIN, wzór lub hasło Androida.";
       await p.openDeviceSecuritySettings();return;
     }
     const result=await p.authenticateDevice();
     if(result?.success)hideLock();
     else throw Error("Nie udało się potwierdzić tożsamości.");
   }catch(e){el("securityLockError").textContent=e?.message||"Nie udało się uruchomić zabezpieczenia telefonu.";}
   finally{authBusy=false;if(btn){btn.disabled=false;btn.textContent="Odblokuj telefon";}}
 };
 const openSettings=async()=>{
   try{const p=security();if(!p)throw Error("Ta funkcja działa w aplikacji Android.");await p.openDeviceSecuritySettings();}
   catch(e){el("securitySettingsStatus").textContent=e?.message||"Nie można otworzyć ustawień telefonu.";}
 };
 el("securityUnlockButton").addEventListener("click",unlock);
 el("securityOpenSettings").addEventListener("click",openSettings);
 el("securityOpenSettingsDialog").addEventListener("click",openSettings);
 el("securitySettingsButton").addEventListener("click",async()=>{
   el("securitySettingsDialog").showModal();
   try{const s=await status();el("securitySettingsStatus").textContent=s.deviceSecure?"Blokada ekranu telefonu jest skonfigurowana. Aplikacja używa systemowego PIN-u, wzoru, hasła lub biometrii.":"Nie ustawiono blokady ekranu. Skonfiguruj ją w ustawieniach Androida.";}
   catch(e){el("securitySettingsStatus").textContent=e?.message||"Moduł zabezpieczeń jest niedostępny.";}
 });
 const close=()=>el("securitySettingsDialog").close();
 el("securitySettingsClose").addEventListener("click",close);
 el("securitySettingsDone").addEventListener("click",close);
 document.addEventListener("visibilitychange",()=>{
   if(document.visibilityState==="hidden"&&lockReady){backgrounded=true;showLock("Aplikacja została przeniesiona do tła. Odblokuj ją zabezpieczeniem telefonu.");}
   else if(document.visibilityState==="visible"&&backgrounded&&lockReady){showLock("Wróciłeś do aplikacji. Potwierdź tożsamość zabezpieczeniem telefonu.");backgrounded=false;unlock();}
 });
 window.addEventListener("pagehide",()=>{if(lockReady)showLock("Aplikacja została ukryta. Wymagane ponowne odblokowanie.");});
 const observer=new MutationObserver(()=>{
   const appVisible=!el("app").classList.contains("hidden");
   el("securitySettingsButton").classList.toggle("hidden",!appVisible);
   if(appVisible&&!lockReady){lockReady=true;showLock("Potwierdź tożsamość zabezpieczeniem ustawionym w telefonie.");unlock();}
 });
 observer.observe(el("app"),{attributes:true,attributeFilter:["class"]});
 if(!el("app").classList.contains("hidden")){lockReady=true;showLock("Potwierdź tożsamość zabezpieczeniem ustawionym w telefonie.");unlock();}
})();



// ===== LOKALNY DZIENNIK BŁĘDÓW =====
(()=>{
 const byId=id=>document.getElementById(id);
 const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
 const get=()=>window.DKErrorLog?.read?.()||[];
 const refresh=()=>{
   const list=byId("errorLogList"),status=byId("errorLogStatus"); if(!list||!status)return;
   const entries=get();
   status.textContent=entries.length?`Zapisane błędy: ${entries.length} (maksymalnie 50). Dane pozostają na tym urządzeniu.`:"Nie zapisano jeszcze żadnych błędów.";
   if(!entries.length){list.textContent="Brak zapisanych błędów. Gdy aplikacja napotka błąd JavaScript, pojawi się tutaj.";return;}
   list.innerHTML=entries.slice().reverse().map((e,i)=>`<details style="border:1px solid var(--border,#d5dbe3);border-radius:8px;padding:9px;margin:7px 0"><summary><strong>${esc(e.type)}</strong> – ${esc(new Date(e.time).toLocaleString("pl-PL"))}<br>${esc(e.message)}</summary><div style="white-space:pre-wrap;overflow-wrap:anywhere;margin-top:8px;font-size:12px">${esc(e.source||"")}${e.line?`:${e.line}:${e.column||0}`:""}${e.stack?"\\n"+esc(e.stack):""}</div></details>`).join("");
 };
 byId("refreshErrorLog")?.addEventListener("click",refresh);
 byId("clearErrorLog")?.addEventListener("click",()=>{
   if(!confirm("Czy na pewno usunąć wszystkie zapisane błędy?"))return;
   window.DKErrorLog?.clear?.();refresh();
 });
 byId("exportErrorLog")?.addEventListener("click",()=>{
   const entries=get();
   if(!entries.length){alert("Nie ma jeszcze zapisanych błędów do pobrania.");return;}
   const blob=new Blob([JSON.stringify({application:"DWA I CZTERY KOŁA",exportedAt:new Date().toISOString(),errors:entries},null,2)],{type:"application/json;charset=utf-8"});
   const url=URL.createObjectURL(blob),a=document.createElement("a");
   a.href=url;a.download="raport-bledow-dwa-i-cztery-kola.json";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
 });
 refresh();
})();
