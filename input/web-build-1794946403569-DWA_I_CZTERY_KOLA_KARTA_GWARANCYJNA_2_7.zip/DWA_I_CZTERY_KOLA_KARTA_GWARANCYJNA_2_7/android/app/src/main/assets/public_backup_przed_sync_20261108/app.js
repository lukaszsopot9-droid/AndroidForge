const PROJECT_URL="https://xyayfisbuyfqsbumdiax.supabase.co";
const $=id=>document.getElementById(id);
let sb=null, repairs=[], clients=[], vehicles=[], activeEdit=null;
const show=(id,on)=>$(id).classList.toggle("hidden",!on);
function toast(s){$("toast").textContent=s;$("toast").style.display="block";setTimeout(()=>$("toast").style.display="none",3500)}
// Aktualizacje aplikacji Android — manifest i APK są publikowane na stronie WWW.
const UPDATE_MANIFEST_URL="https://dwaiczterykola.pl/pobierz/pliki/latest.json";
let availableAppUpdate=null;
let updateOperationRunning=false;
let updateCheckRunning=false;
let updateDownloadRunning=false;
function getAppUpdater(){
  if(!window.Capacitor?.isNativePlatform?.() || !window.Capacitor?.registerPlugin) return null;
  return window.Capacitor.registerPlugin("AppUpdater");
}
function setUpdateStatus(message){
  const el=$("appUpdateStatus");
  if(el) el.textContent=message;
}
async function checkForAppUpdate(manual=false){
  if(updateCheckRunning || updateOperationRunning) return;
  updateCheckRunning=true;
  const checkButton=$("checkAppUpdateButton");
  if(manual && checkButton){checkButton.disabled=true;checkButton.textContent="Sprawdzanie…";}
  try{
    const updater=getAppUpdater();
    if(!updater) throw new Error("Aktualizacje są dostępne w aplikacji Android.");
    const [appInfo,response]=await Promise.all([
      updater.getAppInfo(),
      fetch(UPDATE_MANIFEST_URL+"?t="+Date.now(),{cache:"no-store"})
    ]);
    if(!response.ok) throw new Error("Serwer aktualizacji zwrócił HTTP "+response.status+".");
    const manifest=await response.json();
    const remoteCode=Number(manifest.versionCode);
    if(!Number.isInteger(remoteCode) || remoteCode<1 || !manifest.apkUrl || !/^https:\/\//i.test(manifest.apkUrl))
      throw new Error("Plik latest.json ma nieprawidłowy format (wymagane versionCode i apkUrl).");
    const localCode=Number(appInfo.versionCode||0);
    if(remoteCode<=localCode){
      availableAppUpdate=null;
      $("appUpdateNotice")?.classList.add("hidden");
      if(manual) toast("Masz aktualną wersję aplikacji.");
      return;
    }
    availableAppUpdate=manifest;
    $("appUpdateVersion").textContent="Dostępna wersja "+(manifest.versionName||remoteCode);
    $("appUpdateNotes").textContent=manifest.changelog||manifest.releaseNotes||"Dostępna jest nowa wersja aplikacji.";
    $("appUpdateNotice").classList.remove("hidden");
    const status=await updater.getDownloadStatus();
    if(status.status==="successful"){
      setUpdateStatus("Plik APK jest już w folderze Pobrane. Możesz rozpocząć instalację.");
      $("updateAppButton").textContent="Zainstaluj pobraną aktualizację";
    }else if(status.status==="pending" || status.status==="running"){
      setUpdateStatus("Pobieranie APK do folderu Pobrane trwa w tle…");
      $("updateAppButton").textContent="Sprawdź pobieranie i zainstaluj";
    }else if(!updateDownloadRunning){
      updateDownloadRunning=true;
      setUpdateStatus("Wykryto nową wersję. Pobieram APK do folderu Pobrane…");
      $("updateAppButton").textContent="Ponów pobieranie";
      try{
        const queued=await updater.downloadUpdate({url:manifest.apkUrl});
        setUpdateStatus("Pobieranie rozpoczęte. Plik zostanie zapisany w folderze Pobrane ("+(queued.fileName||"APK")+").");
      }catch(downloadError){
        setUpdateStatus("Nie udało się rozpocząć pobierania: "+(downloadError.message||"błąd Androida"));
      }finally{updateDownloadRunning=false;}
    }
    if(manual) toast("Znaleziono aktualizację "+(manifest.versionName||remoteCode)+".");
  }catch(error){
    console.warn("Sprawdzanie aktualizacji:",error);
    if(manual) toast("Nie udało się sprawdzić aktualizacji: "+(error.message||error));
    setUpdateStatus(error.message||"Nie udało się sprawdzić aktualizacji.");
  }finally{
    updateCheckRunning=false;
    if(manual && checkButton){checkButton.disabled=false;checkButton.textContent="Sprawdź aktualizacje";}
  }
}
async function installAvailableAppUpdate(){
  if(updateOperationRunning) return;
  if(!availableAppUpdate){await checkForAppUpdate(true);if(!availableAppUpdate)return;}
  const updater=getAppUpdater();
  if(!updater) return;
  updateOperationRunning=true;
  const button=$("updateAppButton");
  button.disabled=true;
  try{
    let status=await updater.getDownloadStatus();
    if(status.status!=="successful"){
      if(status.status!=="pending" && status.status!=="running"){
        setUpdateStatus("Uruchamiam pobieranie APK do folderu Pobrane…");
        await updater.downloadUpdate({url:availableAppUpdate.apkUrl});
      }else setUpdateStatus("Pobieranie APK trwa. Czekaj…");
      let finished=false;
      for(let i=0;i<300;i++){
        await new Promise(resolve=>setTimeout(resolve,1000));
        status=await updater.getDownloadStatus();
        if(status.status==="successful"){finished=true;break;}
        if(status.status==="failed") throw new Error(status.error||"Android nie ukończył pobierania APK.");
        setUpdateStatus("Pobieranie APK do folderu Pobrane…");
      }
      if(!finished) throw new Error("Pobieranie trwa zbyt długo. Sprawdź internet i folder Pobrane.");
    }
    setUpdateStatus("APK zapisany w folderze Pobrane. Otwieram instalator Androida…");
    const result=await updater.installDownloadedUpdate();
    if(result.needsPermission){
      setUpdateStatus("Zezwól aplikacji na instalowanie nieznanych aplikacji w ustawieniach Androida. Wróć tutaj i naciśnij przycisk ponownie.");
      button.textContent="Zainstaluj pobraną aktualizację";
    }else{
      setUpdateStatus("Potwierdź aktualizację w systemowym oknie Androida.");
      button.textContent="Otwórz instalator ponownie";
    }
  }catch(error){
    setUpdateStatus(error.message||"Nie udało się zaktualizować aplikacji.");
  }finally{
    button.disabled=false;
    updateOperationRunning=false;
  }
}
function init(){const key=localStorage.getItem("dk_publishable");if(!key){show("setup",true);return}sb=window.supabase.createClient(PROJECT_URL,key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});sb.auth.onAuthStateChange((_e,session)=>{if(session){show("login",false);show("setup",false);show("app",true);show("logout",true);loadAll()}else{show("app",false);show("logout",false);show("login",true)}});sb.auth.getSession().then(({data})=>{if(data.session){show("app",true);show("logout",true);loadAll()}else show("login",true)})}
$("saveConfig").onclick=()=>{const k=$("apiKey").value.trim();if(!k.startsWith("sb_publishable_")){toast("Wpisz klucz sb_publishable.");return}localStorage.setItem("dk_publishable",k);location.reload()};
$("signIn").onclick=async()=>{ $("loginMsg").textContent="Logowanie…";const {error}=await sb.auth.signInWithPassword({email:$("email").value.trim(),password:$("password").value});$("loginMsg").textContent=error?error.message:"Zalogowano."};
$("logout").onclick=async()=>{await sb.auth.signOut()};
$("refresh").onclick=loadAll;
async function loadAll(){ $("statusLine").textContent="Pobieranie danych z chmury…";try{const [a,b,c]=await Promise.all([sb.from("naprawy").select("*").order("created_at",{ascending:false}).limit(500),sb.from("klienci").select("*").order("id").limit(500),sb.from("pojazdy").select("*").order("id").limit(500)]);for(const r of [a,b,c])if(r.error)throw r.error;repairs=a.data||[];clients=b.data||[];vehicles=c.data||[];render();$("statusLine").textContent=`Połączono • ${repairs.length} napraw • ${clients.length} klientów`;}catch(e){$("statusLine").textContent="Błąd pobierania danych";toast(e.message)}}
function card(title,sub,meta,click){const d=document.createElement("article");d.className="item";d.innerHTML=`<strong></strong><p></p><span class="pill"></span>`;d.querySelector("strong").textContent=title||"—";d.querySelector("p").textContent=sub||"";d.querySelector("span").textContent=meta||"";if(click)d.onclick=click;return d}
function normalizeSearch(value){
  return String(value??"").normalize("NFD").replace(/[\\u0300-\\u036f]/g,"").toLowerCase().replace(/[\\s-]/g,"");
}
function render(){
  const q=normalizeSearch($("searchRepairs").value);
  $("repairList").replaceChildren(...repairs.filter(x=>[x.numer_protokolu,x.numer,x.klient,x.pojazd,x.rejestracja].some(v=>normalizeSearch(v).includes(q))).map(repairCard));
  const cq=normalizeSearch($("searchClients").value);
  $("clientList").replaceChildren(...clients.filter(client=>{
    const clientId=String(client.id??"");
    const clientName=normalizeSearch(client.imie_nazwisko);
    const clientVehicles=vehicles.filter(vehicle=>String(vehicle.klient_id??"")===clientId);
    const clientRepairs=repairs.filter(repair=>
      (repair.klient_id!=null && String(repair.klient_id)===clientId) ||
      (clientName && normalizeSearch(repair.klient)===clientName) ||
      clientVehicles.some(vehicle=>vehicle.id!=null && repair.pojazd_id!=null && String(repair.pojazd_id)===String(vehicle.id))
    );
    const searchable=[
      client.imie_nazwisko,client.telefon,client.email,client.miasto,
      ...clientVehicles.flatMap(vehicle=>[vehicle.rejestracja,vehicle.vin,vehicle.marka_model,vehicle.marka,vehicle.model]),
      ...clientRepairs.flatMap(repair=>[repair.rejestracja,repair.vin,repair.pojazd,repair.klient])
    ].map(normalizeSearch).join(" ");
    return searchable.includes(cq);
  }).map(clientCard));
  const vq=normalizeSearch($("searchVehicles").value);
  $("vehicleList").replaceChildren(...vehicles.filter(x=>normalizeSearch(`${x.marka_model||x.marka+" "+x.model} ${x.rejestracja} ${x.vin}`).includes(vq)).map(vehicleCard));
  renderStats();
}
function repairCard(repair){
  const item=card(repair.numer_protokolu||repair.numer||"Naprawa",`${repair.klient||""} • ${repair.pojazd||""} • ${repair.rejestracja||""}`,repair.status||"—",()=>editRepair(repair));
  const button=document.createElement("button");
  button.type="button";
  button.className="secondary";
  button.textContent="Usuń naprawę";
  button.style.cssText="margin-top:10px;width:100%;";
  button.onclick=e=>{e.stopPropagation();deleteRepair(repair);};
  item.appendChild(button);
  return item;
}
async function deleteRepair(repair){
  const label=repair.numer_protokolu||repair.numer||`#${repair.id}`;
  if(!confirm(`Czy na pewno chcesz usunąć naprawę ${label}?\n\nTej operacji nie można cofnąć.`)) return;
  try{
    const photoPaths=getPhotoPaths(repair.zdjecia_lokalne);
    if(photoPaths.length){
      const {error:photoError}=await sb.storage.from(PHOTO_BUCKET).remove(photoPaths);
      if(photoError) throw photoError;
    }
    const {error}=await sb.from("naprawy").delete().eq("id",repair.id);
    if(error) throw error;
    toast("Naprawa została usunięta.");
    await loadAll();
  }catch(error){
    alert("Nie udało się usunąć naprawy.\n\n"+error.message);
  }
}
function clientCard(client){
  const clientId=String(client.id??"");
  const clientName=normalizeSearch(client.imie_nazwisko);
  const clientVehicles=vehicles.filter(vehicle=>String(vehicle.klient_id??"")===clientId);
  const clientRepairs=repairs.filter(repair=>(repair.klient_id!=null && String(repair.klient_id)===clientId) || (clientName && normalizeSearch(repair.klient)===clientName));
  const registrations=[...clientVehicles.map(vehicle=>vehicle.rejestracja),...clientRepairs.map(repair=>repair.rejestracja)].map(value=>String(value||"").trim()).filter(Boolean);
  const uniqueRegistrations=[...new Set(registrations)];
  const item=card(client.imie_nazwisko,client.email||client.miasto,uniqueRegistrations.length?"Rejestracje: "+uniqueRegistrations.join(", "):"");
  const phone=String(client.telefon||"").trim();
  if(phone){
    const link=document.createElement("a");
    link.href="tel:"+phone.replace(/[^0-9+*#,;]/g,"");
    link.textContent="☎ "+phone;
    link.style.cssText="display:block;margin-top:8px;color:#36b37e;font-weight:600;text-decoration:none;";
    link.onclick=e=>e.stopPropagation();
    item.appendChild(link);
  }
  const button=document.createElement("button");
  button.type="button";
  button.className="secondary";
  button.textContent="Usuń klienta";
  button.style.cssText="margin-top:10px;width:100%;";
  button.onclick=e=>{e.stopPropagation();deleteClient(client);};
  item.appendChild(button);
  return item;
}
async function deleteClient(client){
  const name=client.imie_nazwisko||"tego klienta";
  if(!confirm(`Czy na pewno chcesz usunąć klienta: ${name}?\\n\\nPowiązane naprawy i pojazdy nie będą usuwane.`)) return;
  try{
    const [repairsById,repairsByName,vehiclesByClient]=await Promise.all([
      sb.from("naprawy").select("id",{count:"exact",head:true}).eq("klient_id",client.id),
      sb.from("naprawy").select("id",{count:"exact",head:true}).eq("klient",client.imie_nazwisko||""),
      sb.from("pojazdy").select("id",{count:"exact",head:true}).eq("klient_id",client.id)
    ]);
    for(const result of [repairsById,repairsByName,vehiclesByClient]) if(result.error) throw result.error;
    const repairCount=Math.max(repairsById.count||0,repairsByName.count||0);
    const vehicleCount=vehiclesByClient.count||0;
    if(repairCount||vehicleCount){
      const details=[];
      if(repairCount) details.push(`powiązane naprawy: ${repairCount}`);
      if(vehicleCount) details.push(`powiązane pojazdy: ${vehicleCount}`);
      alert(`Nie można usunąć klienta. Najpierw trzeba przenieść lub usunąć powiązane dane (${details.join(", ")}).\\n\\nŻadne dane nie zostały usunięte.`);
      return;
    }
    const {error}=await sb.from("klienci").delete().eq("id",client.id);
    if(error) throw error;
    toast("Klient został usunięty.");
    await loadAll();
  }catch(error){
    alert("Nie udało się usunąć klienta.\\n\\n"+error.message);
  }
}
function vehicleCard(vehicle){
  const title=vehicle.marka_model||`${vehicle.marka||""} ${vehicle.model||""}`.trim()||"Pojazd";
  const item=card(title,vehicle.rejestracja||"",vehicle.vin||"");
  const historyButton=document.createElement("button");
  historyButton.type="button";
  historyButton.className="secondary";
  historyButton.textContent="Historia napraw";
  historyButton.style.cssText="margin-top:10px;width:100%;";
  historyButton.onclick=e=>{e.stopPropagation();showVehicleHistory(vehicle);};
  item.appendChild(historyButton);
  const button=document.createElement("button");
  button.type="button";
  button.className="secondary";
  button.textContent="Usuń pojazd";
  button.style.cssText="margin-top:10px;width:100%;";
  button.onclick=e=>{e.stopPropagation();deleteVehicle(vehicle);};
  item.appendChild(button);
  return item;
}
function showVehicleHistory(vehicle){
  const registration=String(vehicle.rejestracja||"").trim().toUpperCase().replace(/[\s-]/g,"");
  const related=repairs.filter(repair=>{
    if(vehicle.id!=null && repair.pojazd_id!=null && String(repair.pojazd_id)===String(vehicle.id)) return true;
    const repairRegistration=String(repair.rejestracja||"").trim().toUpperCase().replace(/[\s-]/g,"");
    return Boolean(registration && repairRegistration===registration);
  }).sort((a,b)=>{
    const da=new Date(a.data_przyjecia||a.created_at||0).getTime();
    const db=new Date(b.data_przyjecia||b.created_at||0).getTime();
    return db-da;
  });

  let dlg=$("vehicleHistoryDialog");
  if(!dlg){
    dlg=document.createElement("dialog");
    dlg.id="vehicleHistoryDialog";
    document.body.appendChild(dlg);
  }
  dlg.replaceChildren();

  const header=document.createElement("div");
  header.className="dialogHead";
  const heading=document.createElement("h2");
  heading.textContent="Historia pojazdu";
  const close=document.createElement("button");
  close.type="button";
  close.className="ghost";
  close.textContent="Zamknij";
  close.onclick=()=>dlg.close();
  header.append(heading,close);
  dlg.appendChild(header);

  const vehicleName=vehicle.marka_model||`${vehicle.marka||""} ${vehicle.model||""}`.trim()||"Pojazd";
  const subtitle=document.createElement("p");
  subtitle.className="muted";
  subtitle.textContent=[vehicleName,vehicle.rejestracja||"",vehicle.vin||""].filter(Boolean).join(" • ");
  dlg.appendChild(subtitle);

  const count=document.createElement("p");
  count.className="muted";
  count.textContent=`Liczba znalezionych napraw: ${related.length}`;
  dlg.appendChild(count);

  if(!related.length){
    const empty=document.createElement("p");
    empty.textContent="Nie znaleziono jeszcze napraw przypisanych do tego pojazdu.";
    dlg.appendChild(empty);
  }

  related.forEach(repair=>{
    const entry=document.createElement("article");
    entry.className="item";
    entry.style.marginTop="10px";

    const title=document.createElement("strong");
    title.textContent=repair.numer_protokolu||repair.numer||"Naprawa";
    entry.appendChild(title);

    const dateValue=repair.data_przyjecia||repair.created_at;
    const dateText=dateValue&&!Number.isNaN(new Date(dateValue).getTime())
      ?new Date(dateValue).toLocaleString("pl-PL")
      :"Brak daty";
    const meta=document.createElement("p");
    meta.textContent=[dateText,repair.status||""].filter(Boolean).join(" • ");
    entry.appendChild(meta);

    const details=document.createElement("p");
    const detailsParts=[];
    if(repair.klient) detailsParts.push("Klient: "+repair.klient);
    if(repair.opis_usterki||repair.zgloszenie) detailsParts.push("Usterka: "+(repair.opis_usterki||repair.zgloszenie));
    if(repair.diagnoza) detailsParts.push("Diagnoza: "+repair.diagnoza);
    if(repair.wykonane_prace) detailsParts.push("Wykonane prace: "+repair.wykonane_prace);
    if(repair.suma!=null && repair.suma!=="") detailsParts.push("Suma: "+repair.suma+" zł");
    const photoCount=getPhotoPaths(repair.zdjecia_lokalne).length;
    if(photoCount) detailsParts.push("Zdjęcia: "+photoCount);
    details.textContent=detailsParts.join("\n")||"Brak dodatkowych szczegółów.";
    details.style.whiteSpace="pre-line";
    entry.appendChild(details);

    const open=document.createElement("button");
    open.type="button";
    open.className="secondary";
    open.textContent="Otwórz zlecenie";
    open.style.cssText="width:100%;margin-top:8px;";
    open.onclick=()=>{dlg.close();editRepair(repair);};
    entry.appendChild(open);
    dlg.appendChild(entry);
  });

  if(typeof dlg.showModal==="function") dlg.showModal();
  else dlg.setAttribute("open","");
}
async function deleteVehicle(vehicle){
  const title=vehicle.marka_model||vehicle.rejestracja||"ten pojazd";
  if(!confirm(`Czy na pewno chcesz usunąć pojazd: ${title}?\\n\\nNaprawy powiązane z tym pojazdem nie będą usuwane.`)) return;
  try{
    const checks=[sb.from("naprawy").select("id",{count:"exact",head:true}).eq("pojazd_id",vehicle.id)];
    const registration=String(vehicle.rejestracja||"").trim();
    if(registration) checks.push(sb.from("naprawy").select("id",{count:"exact",head:true}).eq("rejestracja",registration));
    const results=await Promise.all(checks);
    for(const result of results) if(result.error) throw result.error;
    const repairCount=Math.max(...results.map(result=>result.count||0));
    if(repairCount){
      alert(`Nie można usunąć pojazdu. Jest powiązany z ${repairCount} naprawami.\\n\\nNajpierw zmień powiązania tych napraw. Żadne dane nie zostały usunięte.`);
      return;
    }
    const {error}=await sb.from("pojazdy").delete().eq("id",vehicle.id);
    if(error) throw error;
    toast("Pojazd został usunięty.");
    await loadAll();
  }catch(error){
    alert("Nie udało się usunąć pojazdu.\\n\\n"+error.message);
  }
}
["searchRepairs","searchClients","searchVehicles"].forEach(id=>$(id).oninput=render);
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".tabview").forEach(x=>show(x.id,x.id===b.dataset.tab))});

// STATYSTYKI: sumujemy wyłącznie pole "zaplacono".
// Okres przypisujemy do daty przyjęcia zlecenia (data_przyjecia),
// ponieważ w bazie nie ma osobnego pola daty otrzymania wpłaty.
function paidAmount(repair){
  const raw=String(repair.zaplacono??"").trim().replace(/\s/g,"").replace(",",".");
  const amount=Number(raw);
  return Number.isFinite(amount)&&amount>0?amount:0;
}
function localDateKey(date){
  const y=date.getFullYear(),m=String(date.getMonth()+1).padStart(2,"0"),d=String(date.getDate()).padStart(2,"0");
  return `${y}-${m}-${d}`;
}
function parseLocalDate(value){
  if(!value) return null;
  const text=String(value);
  const match=text.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if(match) return new Date(Number(match[1]),Number(match[2])-1,Number(match[3]));
  const date=new Date(value);
  return Number.isNaN(date.getTime())?null:new Date(date.getFullYear(),date.getMonth(),date.getDate());
}
function currentPeriodValue(mode){
  const now=new Date();
  if(mode==="daily") return localDateKey(now);
  if(mode==="weekly"){
    const d=new Date(now);d.setDate(d.getDate()-((d.getDay()+6)%7));
    const jan4=new Date(d.getFullYear(),0,4);const week1=new Date(jan4);week1.setDate(jan4.getDate()-((jan4.getDay()+6)%7));
    const week=Math.floor((d-week1)/604800000)+1;
    return `${d.getFullYear()}-W${String(week).padStart(2,"0")}`;
  }
  if(mode==="monthly") return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}`;
  return String(now.getFullYear());
}
function setStatsPeriodInput(){
  const mode=$("statsPeriodType").value,input=$("statsPeriodValue");
  const types={daily:"date",weekly:"week",monthly:"month",yearly:"number"};
  input.type=types[mode];
  input.min=mode==="yearly"?"2000":"";input.max=mode==="yearly"?"2100":"";
  input.value=currentPeriodValue(mode);
  input.step="1";
  renderStats();
}
function statsRange(mode,value){
  let start,end;
  if(mode==="daily"){
    start=parseLocalDate(value);if(!start)return null;end=new Date(start);end.setDate(end.getDate()+1);
  }else if(mode==="weekly"){
    const m=String(value||"").match(/^(\d{4})-W(\d{2})$/);if(!m)return null;
    const year=Number(m[1]),week=Number(m[2]);
    const jan4=new Date(year,0,4);start=new Date(jan4);start.setDate(jan4.getDate()-((jan4.getDay()+6)%7)+(week-1)*7);
    end=new Date(start);end.setDate(end.getDate()+7);
  }else if(mode==="monthly"){
    const m=String(value||"").match(/^(\d{4})-(\d{2})$/);if(!m)return null;
    start=new Date(Number(m[1]),Number(m[2])-1,1);end=new Date(Number(m[1]),Number(m[2]),1);
  }else{
    const year=Number(value);if(!Number.isInteger(year)||year<2000||year>2100)return null;
    start=new Date(year,0,1);end=new Date(year+1,0,1);
  }
  return {start,end};
}
function moneyPL(value){return (Number(value)||0).toLocaleString("pl-PL",{minimumFractionDigits:2,maximumFractionDigits:2})+" zł";}
function renderStats(){
  const host=$("statsResults");if(!host)return;
  const mode=$("statsPeriodType")?.value||"monthly";
  const value=$("statsPeriodValue")?.value||currentPeriodValue(mode);
  const range=statsRange(mode,value);
  host.replaceChildren();
  if(!range){host.textContent="Wybierz prawidłowy okres.";return;}
  const paidRows=repairs.map(repair=>({repair,amount:paidAmount(repair),date:parseLocalDate(repair.data_przyjecia||repair.created_at)}))
    .filter(row=>row.amount>0&&row.date&&row.date>=range.start&&row.date<range.end);
  const total=paidRows.reduce((sum,row)=>sum+row.amount,0);
  const average=paidRows.length?total/paidRows.length:0;
  const title=document.createElement("p");title.className="muted";
  const periodLabels={daily:"Dzień",weekly:"Tydzień",monthly:"Miesiąc",yearly:"Rok"};
  title.textContent=`${periodLabels[mode]}: ${value}`;host.appendChild(title);
  const summary=document.createElement("div");summary.className="stats-summary";
  const makeMetric=(label,val,accent=false)=>{const box=document.createElement("div");box.className="stats-metric";const small=document.createElement("span");small.textContent=label;const strong=document.createElement("strong");strong.textContent=val;if(accent)strong.classList.add("stats-accent");box.append(small,strong);return box;};
  summary.append(makeMetric("Otrzymano",moneyPL(total),true),makeMetric("Zlecenia z wpłatą",String(paidRows.length)),makeMetric("Średnia wpłata na zlecenie",moneyPL(average)));
  host.appendChild(summary);
  const note=document.createElement("p");note.className="stats-note";
  note.textContent="Liczone wyłącznie z pola „Zapłacono”. Okres przypisany według daty przyjęcia zlecenia, ponieważ zlecenia nie mają osobnej daty wpłaty.";
  host.appendChild(note);
  const heading=document.createElement("h3");heading.textContent=mode==="daily"?"Wpłaty w tym dniu":"Podział wpłat w okresie";host.appendChild(heading);
  if(!paidRows.length){const empty=document.createElement("p");empty.className="muted";empty.textContent="Brak zleceń z wpisaną wpłatą w wybranym okresie.";host.appendChild(empty);}
  else if(mode==="daily"){
    paidRows.sort((a,b)=>String(a.repair.numer_protokolu||a.repair.numer||"").localeCompare(String(b.repair.numer_protokolu||b.repair.numer||""),"pl"));
    paidRows.forEach(row=>{
      const item=document.createElement("div");item.className="stats-row";
      const left=document.createElement("div");const name=document.createElement("strong");name.textContent=row.repair.numer_protokolu||row.repair.numer||"Naprawa";
      const sub=document.createElement("small");sub.textContent=[row.repair.klient,row.repair.pojazd,row.repair.rejestracja].filter(Boolean).join(" • ");left.append(name,sub);
      const amount=document.createElement("strong");amount.textContent=moneyPL(row.amount);item.append(left,amount);host.appendChild(item);
    });
  }else{
    const buckets=new Map();
    paidRows.forEach(row=>{
      let key,label;
      if(mode==="yearly") {key=`${row.date.getFullYear()}-${String(row.date.getMonth()+1).padStart(2,"0")}`;label=row.date.toLocaleDateString("pl-PL",{month:"long"});}
      else {key=localDateKey(row.date);label=row.date.toLocaleDateString("pl-PL",{day:"2-digit",month:"2-digit",year:"numeric"});}
      buckets.set(key,{label,total:(buckets.get(key)?.total||0)+row.amount});
    });
    const entries=[...buckets.entries()].sort((a,b)=>a[0].localeCompare(b[0]));
    const max=Math.max(...entries.map(entry=>entry[1].total),1);
    entries.forEach(([,bucket])=>{
      const row=document.createElement("div");row.className="stats-breakdown";
      const line=document.createElement("div");line.className="stats-row";
      const label=document.createElement("strong");label.textContent=bucket.label;
      const amount=document.createElement("strong");amount.textContent=moneyPL(bucket.total);line.append(label,amount);
      const track=document.createElement("div");track.className="stats-bar-track";
      const fill=document.createElement("div");fill.className="stats-bar-fill";fill.style.width=`${Math.max(2,bucket.total/max*100)}%`;track.appendChild(fill);
      row.append(line,track);host.appendChild(row);
    });
  }
}
async function exportStatsPdf(){
  try{
    const mode=$("statsPeriodType").value,value=$("statsPeriodValue").value,range=statsRange(mode,value);
    if(!range)throw new Error("Wybierz prawidłowy okres.");
    const rows=repairs.map(repair=>({repair,amount:paidAmount(repair),date:parseLocalDate(repair.data_przyjecia||repair.created_at)}))
      .filter(row=>row.amount>0&&row.date&&row.date>=range.start&&row.date<range.end);
    const total=rows.reduce((sum,row)=>sum+row.amount,0);
    const JsPDF=await loadJsPDF();const doc=new JsPDF({unit:"mm",format:"a4"});
    doc.setFont("helvetica","bold");doc.setFontSize(17);doc.text("DWA I CZTERY KOLA",15,18);
    doc.setFontSize(13);doc.text("ZESTAWIENIE WPLAT",15,28);
    doc.setFont("helvetica","normal");doc.setFontSize(10);
    const labels={daily:"Dzien",weekly:"Tydzien",monthly:"Miesiac",yearly:"Rok"};
    doc.text(`${labels[mode]}: ${value}`,15,38);
    doc.text(`Suma pola ZAPŁACONO: ${total.toFixed(2)} PLN`,15,47);
    doc.text(`Liczba zlecen z wplata: ${rows.length}`,15,55);
    doc.text("Okres wedlug daty przyjecia zlecenia.",15,63);
    let y=76;doc.setFont("helvetica","bold");doc.text("Numer zlecenia",15,y);doc.text("Klient",75,y);doc.text("Zapłacono (PLN)",150,y);y+=7;
    doc.setFont("helvetica","normal");
    rows.sort((a,b)=>a.date-b.date).forEach(row=>{
      if(y>275){doc.addPage();y=20;}
      const number=String(row.repair.numer_protokolu||row.repair.numer||"—").slice(0,28);
      const client=String(row.repair.klient||"—").slice(0,32);
      doc.text(number,15,y);doc.text(client,75,y);doc.text(row.amount.toFixed(2),155,y);y+=7;
    });
    doc.save(`Zestawienie_wplat_${mode}_${value}.pdf`);
  }catch(error){toast("Nie udało się przygotować PDF: "+error.message);}
}
$("statsPeriodType").onchange=setStatsPeriodInput;
$("statsPeriodValue").onchange=renderStats;
$("exportStatsPdf").onclick=exportStatsPdf;

function field(label,name,value="",type="text"){
  let v=value??"";
  if(type==="datetime-local" && v){
    const dt=new Date(v);
    if(!Number.isNaN(dt.getTime())){
      const pad=n=>String(n).padStart(2,"0");
      v=`${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())}T${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
    } else v="";
  }
  const safe=String(v).replaceAll("&","&amp;").replaceAll('"',"&quot;");
  return `<label>${label}<input name="${name}" type="${type}" value="${safe}" /></label>`;
}
function area(label,name,value=""){return `<label>${label}<textarea name="${name}">${String(value??"")}</textarea></label>`}
function checkboxField(label,name,checked=false){return `<label style="display:flex;gap:10px;align-items:center;margin:12px 0"><input type="checkbox" name="${name}" value="true" ${checked?"checked":""} style="width:auto">${label}</label>`}
async function sendStatusSms(phone, message){
  if(!window.Capacitor?.isNativePlatform?.() || !window.Capacitor?.registerPlugin){
    throw new Error("Otwieranie SMS jest dostępne tylko w natywnej aplikacji Android.");
  }
  const SmsSender=window.Capacitor.registerPlugin("SmsSender");
  await SmsSender.send({phone,message});
}
const REPAIR_STATUSES=[
  "PRZYJĘTY",
  "OCZEKUJE NA DIAGNOZĘ",
  "OCZEKUJE NA CZĘŚCI",
  "W TRAKCIE NAPRAWY",
  "GOTOWY DO ODBIORU",
  "WYDANY KLIENTOWI"
];
function selectField(label,name,options,value=""){
  const current=value||options[0];
  const html=options.map(option=>`<option value="${option.replaceAll("&","&amp;").replaceAll('"',"&quot;")}" ${option===current?"selected":""}>${option}</option>`).join("");
  return `<label>${label}<select name="${name}">${html}</select></label>`;
}
function closeEditor(){
  const dlg=$("editor");
  if(dlg && dlg.open){ dlg.close(); }
  // Reset submit state so the next form opens normally.
  const btn=$("saveRecord");
  if(btn){ btn.disabled=false; btn.textContent="Zapisz"; }
}
// Udostępnij funkcję przyciskom inline w HTML (działa w przeglądarkach desktop i mobile).
window.closeEditor=closeEditor;
$("editor").addEventListener("click",e=>{ if(e.target===$("editor")) closeEditor(); });
$("editor").addEventListener("cancel",e=>{ e.preventDefault(); closeEditor(); });
function openEditor(title,html,save){$("editTitle").textContent=title;$("fields").innerHTML=html;const dlg=$("editor");
                                                                                                  if(typeof dlg.showModal==="function"){
                                                                                                    dlg.showModal();
                                                                                                  }else{
                                                                                                    dlg.setAttribute("open","");
                                                                                                  };$("editForm").onsubmit=async e=>{e.preventDefault();const btn=$("saveRecord");btn.disabled=true;btn.textContent="Zapisywanie…";const data=Object.fromEntries(new FormData(e.target).entries());try{await save(data);closeEditor();await loadAll();toast("Zapisano")}catch(err){toast("Nie zapisano: "+err.message)}finally{btn.disabled=false;btn.textContent="Zapisz"}}}
$("newClient").onclick=()=>openEditor("Nowy klient",field("Imię i nazwisko","imie_nazwisko")+field("Telefon","telefon")+field("E-mail","email","", "email")+field("Ulica","ulica")+field("Numer domu","numer_domu")+field("Kod pocztowy","kod_pocztowy")+field("Miasto","miasto")+area("Uwagi","uwagi"),async d=>{const {error}=await sb.from("klienci").insert(d);if(error)throw error});
$("newRepair").onclick=()=>editRepair({});
async function nextRepairNumber(){
  const now=new Date(), day=now.getDate(), month=now.getMonth()+1, year=now.getFullYear();
  const {data,error}=await sb.from("naprawy").select("numer,numer_protokolu").limit(5000);
  if(error) throw error;
  let max=0;
  for(const row of (data||[])) for(const raw of [row.numer,row.numer_protokolu]){
    const m=String(raw||"").trim().match(/^(\d+)\/(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if(m && +m[2]===day && +m[3]===month && +m[4]===year) max=Math.max(max,+m[1]);
  }
  return `${max+1}/${day}/${month}/${year}`;
}
const PHOTO_BUCKET="zdjecia-serwisowe";
function getPhotoPaths(value){
  if(!value) return [];
  if(Array.isArray(value)) return value;
  try { const parsed=JSON.parse(value); return Array.isArray(parsed)?parsed:[]; }
  catch(_){ return String(value).split("|").filter(Boolean); }
}
async function uploadRepairPhotos(repairId, files, existingPaths){
  const paths=[...existingPaths];
  for(const file of files){
    if(!file.type || !file.type.startsWith("image/")) continue;
    const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
    const path=`${repairId}/${Date.now()}_${Math.random().toString(36).slice(2,8)}_${safeName}`;
    const {error}=await sb.storage.from(PHOTO_BUCKET).upload(path,file,{contentType:file.type,upsert:false});
    if(error) throw error;
    paths.push(path);
  }
  return paths;
}
async function showRepairPhotos(paths){
  const host=$("photoCurrent"); if(!host) return;
  host.replaceChildren();
  for(const path of paths){
    const {data,error}=await sb.storage.from(PHOTO_BUCKET).createSignedUrl(path,3600);
    if(error) continue;
    const a=document.createElement("a"); a.href=data.signedUrl; a.target="_blank"; a.rel="noopener";
    const img=document.createElement("img"); img.src=data.signedUrl; img.alt="Zdjęcie naprawy";
    img.style.cssText="width:88px;height:88px;object-fit:cover;border-radius:9px;border:1px solid #344963";
    a.appendChild(img); host.appendChild(a);
  }
}

async function loadJsPDF(){
  if(window.jspdf && window.jspdf.jsPDF) return window.jspdf.jsPDF;
  if(window.__dkPdfLoading) return window.__dkPdfLoading;
  window.__dkPdfLoading=new Promise((resolve,reject)=>{
    const script=document.createElement("script");
    script.src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.2/jspdf.umd.min.js";
    script.onload=()=>resolve(window.jspdf.jsPDF);
    script.onerror=()=>reject(new Error("Nie udało się załadować biblioteki PDF. Sprawdź połączenie z internetem."));
    document.head.appendChild(script);
  });
  return window.__dkPdfLoading;
}
function pdfText(value){
  return String(value??"—").replace(/\s+/g," ").trim() || "—";
}
async function createRepairPdf(x){
  const JsPDF=await loadJsPDF();
  const doc=new JsPDF({unit:"mm",format:"a4"});
  const margin=16, pageW=210, pageH=297;
  let y=18;
  const orange=[233,162,59], navy=[16,27,43], grey=[90,105,123];
  const addText=(label,value)=>{
    const text=pdfText(value);
    const lines=doc.splitTextToSize(text, pageW-margin*2-2);
    const needed=7+lines.length*5;
    if(y+needed>pageH-18){doc.addPage();y=18;}
    doc.setFont("helvetica","bold");doc.setFontSize(9);doc.setTextColor(...grey);
    doc.text(label.toUpperCase(),margin,y);
    y+=5;
    doc.setFont("helvetica","normal");doc.setFontSize(11);doc.setTextColor(...navy);
    doc.text(lines,margin,y);
    y+=lines.length*5+4;
  };
  doc.setFillColor(...navy);doc.rect(0,0,pageW,37,"F");
  doc.setFillColor(...orange);doc.roundedRect(margin,9,18,18,3,3,"F");
  doc.setTextColor(20,29,42);doc.setFont("helvetica","bold");doc.setFontSize(15);doc.text("2|4",margin+3.5,20);
  doc.setTextColor(255,255,255);doc.setFontSize(14);doc.text("DWA I CZTERY KOŁA",margin+24,16);
  doc.setFont("helvetica","normal");doc.setFontSize(9);doc.text("ZLECENIE SERWISOWE",margin+24,23);
  doc.setFontSize(10);doc.text("Numer: "+pdfText(x.numer_protokolu||x.numer),margin+24,30);
  y=48;
  doc.setTextColor(...navy);doc.setFont("helvetica","bold");doc.setFontSize(13);doc.text("DANE ZLECENIA",margin,y);y+=8;
  addText("Data przyjęcia",x.data_przyjecia?new Date(x.data_przyjecia).toLocaleString("pl-PL"):"—");
  addText("Status",x.status);
  addText("Klient",x.klient);
  addText("Telefon",x.telefon);
  addText("Pojazd",x.pojazd);
  addText("Numer rejestracyjny",x.rejestracja);
  addText("VIN",x.vin);
  addText("Przebieg",x.przebieg==null?"—":String(x.przebieg)+" km");
  addText("Zgłoszona usterka",x.opis_usterki||x.zgloszenie);
  addText("Diagnoza",x.diagnoza);
  addText("Wykonane prace",x.wykonane_prace);
  addText("Uwagi",x.uwagi);
  doc.setDrawColor(...orange);doc.line(margin,y,pageW-margin,y);y+=7;
  addText("Suma",x.suma==null?"—":String(x.suma)+" zł");
  addText("Zaliczka",x.zaliczka==null?"—":String(x.zaliczka)+" zł");
  addText("Zapłacono",x.zaplacono==null?"—":String(x.zaplacono)+" zł");
  if(y+28>pageH-16){doc.addPage();y=20;}
  y=Math.max(y, pageH-53);
  doc.setDrawColor(130,140,150);
  doc.line(margin,y,88,y);doc.line(122,y,pageW-margin,y);
  doc.setFont("helvetica","normal");doc.setFontSize(8);doc.setTextColor(...grey);
  doc.text("Podpis klienta",margin,y+5);doc.text("Podpis serwisu",122,y+5);
  const filename=("Zlecenie_"+pdfText(x.numer_protokolu||x.numer||"serwis").replace(/[^a-zA-Z0-9_-]/g,"_")+".pdf");
  const blob=doc.output("blob");
  const file=new File([blob],filename,{type:"application/pdf"});
  if(navigator.canShare && navigator.canShare({files:[file]}) && navigator.share){
    await navigator.share({files:[file],title:"Zlecenie serwisowe"});
  }else{
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");a.href=url;a.download=filename;
    document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),60000);
    toast("PDF przygotowany. Jeśli nie pojawił się automatycznie, sprawdź Pobrane.");
  }
}

async function recognizeVinFromImage(file){
  if(!window.Tesseract) await new Promise((resolve,reject)=>{
    const script=document.createElement("script");
    script.src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js";
    script.onload=resolve;script.onerror=()=>reject(new Error("Nie udało się załadować OCR. Sprawdź internet."));
    document.head.appendChild(script);
  });
  const result=await window.Tesseract.recognize(file,"eng");
  const match=String(result?.data?.text||"").toUpperCase().match(/[A-HJ-NPR-Z0-9]{17}/);
  if(!match)throw new Error("Nie odczytano pełnego VIN. Zrób wyraźniejsze zdjęcie lub wpisz numer ręcznie.");
  return match[0];
}
async function editRepair(x){
  let assignedNumber=x.numer_protokolu||x.numer||"";
  if(!x.id && !assignedNumber){
    try{assignedNumber=await nextRepairNumber();}
    catch(err){toast("Nie udało się nadać numeru zlecenia: "+err.message);return;}
  }
  const existingPhotos=getPhotoPaths(x.zdjecia_lokalne);
  openEditor(x.id?"Edycja naprawy":"Nowa naprawa",
    field("Numer protokołu","numer_protokolu",assignedNumber)+
    field("Klient","klient",x.klient)+field("Telefon","telefon",x.telefon)+checkboxField("Klient wyraził zgodę na powiadomienia SMS","sms_zgoda",x.sms_zgoda===true)+
    field("Pojazd","pojazd",x.pojazd)+field("Rejestracja","rejestracja",x.rejestracja)+
    field("VIN (17 znaków)","vin",x.vin||vehicles.find(v=>String(v.id)===String(x.pojazd_id))?.vin||"")+
    field("Przebieg (km)","przebieg",x.przebieg??"","number")+
    `<button type="button" id="scanVinButton" class="secondary" style="width:100%;margin:6px 0">📷 Skanuj VIN aparatem</button><input id="vinCameraInput" type="file" accept="image/*" capture="environment" style="display:none"><p class="muted" id="vinScanStatus">Sprawdź odczyt VIN przed zapisem.</p>
    <button type="button" id="scanRegistrationButton" class="secondary" style="width:100%;margin:8px 0">▦ Odczytaj dowód rejestracyjny (Aztec)</button>
    <div id="aztecScannerPanel" class="hidden" style="margin:10px 0;padding:12px;border:1px solid #344963;border-radius:12px;background:#101b2b">
      <video id="aztecScannerVideo" playsinline muted style="display:block;width:100%;max-height:280px;object-fit:contain;background:#000;border-radius:8px"></video>
      <p id="aztecScannerStatus" class="muted">Uruchamianie aparatu…</p>
      <button type="button" id="stopAztecScanner" class="secondary" style="width:100%">Zamknij skaner</button>
    </div>
    <div id="aztecReadResult" class="hidden" style="margin:8px 0;padding:10px;border:1px solid #344963;border-radius:10px">
      <p class="muted" id="aztecReadSummary">Odczytano kod. Sprawdź dane przed zapisaniem.</p>
      <details><summary>Pokaż surowe dane kodu (diagnostyka)</summary><textarea id="aztecRawData" rows="5" readonly style="width:100%;margin-top:8px"></textarea></details>
    </div>`+
    field("Data przyjęcia","data_przyjecia",x.data_przyjecia,"datetime-local")+
    selectField("Status naprawy","status",REPAIR_STATUSES,x.status||"PRZYJĘTY")+
    area("Zgłoszona usterka","opis_usterki",x.opis_usterki||x.zgloszenie)+
    area("Diagnoza","diagnoza",x.diagnoza)+area("Wykonane prace","wykonane_prace",x.wykonane_prace)+
    field("Suma","suma",x.suma)+field("Zaliczka","zaliczka",x.zaliczka)+
    field("Zapłacono","zaplacono",x.zaplacono)+area("Uwagi","uwagi",x.uwagi)+
    `<button type="button" id="sendWorkshopLocationSms" class="secondary" style="width:100%;margin:8px 0">📍 Wyślij klientowi lokalizację SMS</button><button type="button" id="makeRepairPdf" class="secondary" style="width:100%;margin:8px 0">Utwórz PDF i udostępnij</button><button type="button" id="shareClientQr" class="secondary" style="width:100%;margin:8px 0">🔳 Udostępnij klientowi — wygeneruj QR</button><div id="clientQrResult" class="hidden" style="padding:14px;border:1px solid #344963;border-radius:12px;margin:10px 0"><p class="muted">Kod dostępu do podglądu klienta</p><div id="clientQrCode" style="display:flex;justify-content:center;background:#fff;padding:12px;border-radius:10px"></div><p id="clientQrLink" class="muted" style="overflow-wrap:anywhere"></p><button type="button" id="copyClientQrLink" class="secondary">Kopiuj link</button><button type="button" id="printClientQr" class="secondary">Drukuj QR</button></div><div class="photo-picker" style="display:flex;gap:10px;flex-wrap:wrap;margin:10px 0">
      <button type="button" id="takeRepairPhoto" class="secondary">📷 Zrób zdjęcie</button>
      <button type="button" id="chooseRepairPhotos" class="secondary">🖼️ Wybierz z galerii</button>
      <input id="repairCameraPhotos" type="file" accept="image/*" capture="environment" multiple style="display:none">
      <input id="repairGalleryPhotos" type="file" accept="image/*" multiple style="display:none">
    </div><div id="photoCurrent" style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0"></div><p class="muted">Możesz zrobić zdjęcie aparatem albo zaznaczyć kilka zdjęć z galerii. Wybrane zdjęcia zostaną dodane do tego zlecenia.</p>`,
    async d=>{
      const assigned=d.numer_protokolu||assignedNumber;
      const payload={...d,numer:assigned,numer_protokolu:assigned,
        sms_zgoda:d.sms_zgoda==="true",
        klient_id:x.klient_id||null,pojazd_id:x.pojazd_id||null};
      const vin=String(d.vin||"").toUpperCase().replace(/[^A-Z0-9]/g,"");
      if(vin&&!/^[A-HJ-NPR-Z0-9]{17}$/.test(vin))throw new Error("VIN musi mieć 17 znaków i nie może zawierać I, O ani Q.");
      delete payload.vin;
      const mileageRaw=String(d.przebieg??"").trim();
      payload.przebieg=mileageRaw===""?null:Number(mileageRaw);
      if(payload.przebieg!==null&&(!Number.isSafeInteger(payload.przebieg)||payload.przebieg<0))throw new Error("Przebieg musi być nieujemną liczbą całkowitą.");
      payload.data_przyjecia=d.data_przyjecia ? new Date(d.data_przyjecia).toISOString() : null;
      for(const key of ["suma","zaliczka","zaplacono"]){const raw=String(d[key]??"").trim();payload[key]=raw===""?null:Number(raw.replace(",","."));if(payload[key]!==null&&!Number.isFinite(payload[key]))throw new Error(`Nieprawidłowa wartość w polu: ${key}`)}
      delete payload.numer_protokolu;
      // Automatyczne znalezienie lub utworzenie klienta.
      const clientName=String(d.klient||"").trim().replace(/\s+/g," ");
      const clientPhone=String(d.telefon||"").trim();
      if(!payload.klient_id && clientName){
        const {data:knownClients,error:clientLookupError}=await sb
          .from("klienci").select("id,imie_nazwisko,telefon").limit(5000);
        if(clientLookupError) throw clientLookupError;

        const digits=value=>String(value||"").replace(/\D/g,"");
        const normName=value=>String(value||"").trim().replace(/\s+/g," ").toLowerCase();
        const phoneDigits=digits(clientPhone);
        let matchedClient=null;

        if(phoneDigits){
          matchedClient=(knownClients||[]).find(c=>digits(c.telefon)===phoneDigits);
        }
        if(!matchedClient){
          matchedClient=(knownClients||[]).find(c=>
            normName(c.imie_nazwisko)===normName(clientName) &&
            (!phoneDigits || !digits(c.telefon))
          );
        }

        if(matchedClient){
          payload.klient_id=matchedClient.id;
        }else{
          const {data:newClient,error:clientInsertError}=await sb
            .from("klienci")
            .insert({imie_nazwisko:clientName,telefon:clientPhone||null})
            .select("id").single();
          if(clientInsertError) throw clientInsertError;
          payload.klient_id=newClient.id;
        }
      }

      let repairId=x.id;

      // Znajdź lub utwórz pojazd na podstawie numeru rejestracyjnego
      // (jeśli go brak, użyj nazwy pojazdu). Nie twórz duplikatu.
      const reg=String(d.rejestracja||"").trim().toUpperCase();
      const nazwaPojazdu=String(d.pojazd||"").trim();

      if(!x.pojazd_id && (reg || nazwaPojazdu)){
        let query=sb.from("pojazdy").select("id,vin");

        if(reg){
          query=query.eq("rejestracja",reg);
        }else{
          query=query.eq("marka_model",nazwaPojazdu);
        }

        const {data:existingVehicle,error:vehicleLookupError}=await query.limit(1).maybeSingle();
        if(vehicleLookupError) throw vehicleLookupError;

        if(existingVehicle){
          payload.pojazd_id=existingVehicle.id;
          if(vin){const {error:ve}=await sb.from("pojazdy").update({vin}).eq("id",existingVehicle.id);if(ve)throw ve;}
        }else{
          const normalizedClient=String(d.klient||"").trim().toLowerCase();
          const matchedClient=clients.find(c=>
            String(c.imie_nazwisko||"").trim().toLowerCase()===normalizedClient
          );
          const vehicleData={
            klient_id:x.klient_id||matchedClient?.id||null,
            marka_model:nazwaPojazdu||null,
            rejestracja:reg||null,
            vin:vin||null
          };

          const {data:newVehicle,error:vehicleInsertError}=await sb
            .from("pojazdy")
            .insert(vehicleData)
            .select("id")
            .single();

          if(vehicleInsertError) throw vehicleInsertError;
          payload.pojazd_id=newVehicle.id;
        }
      }

      if(payload.pojazd_id&&vin){const {error:ve}=await sb.from("pojazdy").update({vin}).eq("id",payload.pojazd_id);if(ve)throw ve;}
      const previousStatus=String(x.status||"").trim();
      if(x.id){
        const {error}=await sb.from("naprawy").update(payload).eq("id",x.id);
        if(error) throw error;
      }else{
        const {data,error}=await sb.from("naprawy").insert(payload).select("id").single();
        if(error) throw error;
        repairId=data.id;
      }
      const files=[
        ...Array.from($("repairCameraPhotos")?.files||[]),
        ...Array.from($("repairGalleryPhotos")?.files||[])
      ];
      if(files.length){
        const paths=await uploadRepairPhotos(repairId,files,existingPhotos);
        const {error}=await sb.from("naprawy").update({zdjecia_lokalne:JSON.stringify(paths)}).eq("id",repairId);
        if(error)throw error;
      }

      // Po zapisaniu nowej naprawy zapytaj o wysłanie klientowi bezpiecznego linku SMS.
      // SMS jest tylko przygotowywany w aplikacji telefonu — użytkownik sam go wysyła.
      if(!x.id && payload.sms_zgoda && clientPhone && repairId){
        const shouldSendLink=confirm("Naprawa została zapisana. Czy przygotować SMS dla klienta z bezpiecznym linkiem do podglądu naprawy?");
        if(shouldSendLink){
          try{
            const {data:{session}}=await sb.auth.getSession();
            if(!session) throw new Error("Sesja wygasła. Zaloguj się ponownie.");
            const response=await fetch(PROJECT_URL+"/functions/v1/klient-qr",{
              method:"POST",
              headers:{
                "Content-Type":"application/json",
                "Authorization":"Bearer "+session.access_token,
                "apikey":localStorage.getItem("dk_publishable")
              },
              body:JSON.stringify({action:"create",repair_id:repairId})
            });
            const result=await response.json();
            if(!response.ok) throw new Error(result.error||"Nie udało się utworzyć linku.");
            if(!result.url) throw new Error("Serwer nie zwrócił adresu podglądu.");
            const label=assigned||`#${repairId}`;
            const message=`Dwa i Cztery Koła: Twoje zlecenie ${label} zostało przyjęte. Bezpieczny podgląd statusu naprawy: ${result.url}`;
            await sendStatusSms(clientPhone,message);
            toast("Otworzono SMS z linkiem. Naciśnij Wyślij w aplikacji wiadomości.");
          }catch(smsError){
            console.error("SMS z linkiem klienta:",smsError);
            alert("NAPRAWA ZOSTAŁA ZAPISANA, ALE NIE UDAŁO SIĘ PRZYGOTOWAĆ SMS.\\n\\n"+smsError.message);
          }
        }
      }
      const newStatus=String(d.status||"").trim();
      if(x.id && previousStatus && newStatus && previousStatus!==newStatus && payload.sms_zgoda){
        const phone=String(d.telefon||x.telefon||"").trim();
        const label=assigned||`#${repairId}`;
        const message=`Dwa i Cztery Koła: status naprawy ${label} zmienił się na: ${newStatus}.`;
        try{
          if(!phone) throw new Error("Brak numeru telefonu klienta.");
          await sendStatusSms(phone,message);
          toast("Status zapisany. SMS wysłany.");
        }catch(smsError){
          console.error("SMS status error",smsError);
          alert("STATUS ZAPISANY, ALE SMS NIE ZOSTAŁ WYSŁANY.\n\nPRZYCZYNA:\n" + smsError.message);
        }
      }
    });
  const locationSmsButton=$("sendWorkshopLocationSms");
  if(locationSmsButton){
    locationSmsButton.onclick=async()=>{
      const formData=Object.fromEntries(new FormData($("editForm")).entries());
      const phone=String(formData.telefon||x.telefon||"").trim();
      if(!phone){toast("Wpisz numer telefonu klienta.");return;}
      const mapsUrl="https://www.google.com/maps/dir/?api=1&destination=To%C5%82stoja+5B%2C+42-600+Tarnowskie+G%C3%B3ry&travelmode=driving";
      const message="DWA I CZTERY KOŁA – zapraszamy do naszego serwisu!\nAdres: ul. Tołstoja 5B, 42-600 Tarnowskie Góry.\nNawigacja Google Maps: "+mapsUrl;
      const oldText=locationSmsButton.textContent;
      locationSmsButton.disabled=true;
      locationSmsButton.textContent="Otwieranie SMS…";
      try{
        await sendStatusSms(phone,message);
        toast("Otworzono wysyłanie SMS z lokalizacją.");
      }catch(error){
        toast("Nie udało się otworzyć SMS: "+error.message);
      }finally{
        locationSmsButton.disabled=false;
        locationSmsButton.textContent=oldText;
      }
    };
  }
  const pdfButton=$("makeRepairPdf");
   if(pdfButton){
     pdfButton.onclick=async()=>{
       const formData=Object.fromEntries(new FormData($("editForm")).entries());
       const pdfData={...x,...formData,numer:formData.numer_protokolu||assignedNumber};
       try{pdfButton.disabled=true;pdfButton.textContent="Przygotowywanie PDF…";await createRepairPdf(pdfData);}
       catch(err){toast("Nie udało się utworzyć PDF: "+err.message);}
       finally{pdfButton.disabled=false;pdfButton.textContent="Utwórz PDF i udostępnij";}
     };
   }
   const cameraInput=$("repairCameraPhotos");
  const galleryInput=$("repairGalleryPhotos");
  
  const qrButton=$("shareClientQr");
  if(qrButton){
    qrButton.onclick=async()=>{
      if(!x.id){toast("Najpierw zapisz zlecenie, a potem wygeneruj kod QR.");return;}
      const old=qrButton.textContent;qrButton.disabled=true;qrButton.textContent="Tworzenie bezpiecznego linku…";
      try{
        const {data:{session}}=await sb.auth.getSession();
        if(!session) throw new Error("Sesja wygasła. Zaloguj się ponownie.");
        const response=await fetch(PROJECT_URL+"/functions/v1/klient-qr",{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+session.access_token,"apikey":localStorage.getItem("dk_publishable")},body:JSON.stringify({action:"create",repair_id:x.id})});
        const result=await response.json();
        if(!response.ok) throw new Error(result.error||"Nie udało się utworzyć linku.");
        const link=result.url;
        if(!link) throw new Error("Serwer nie zwrócił adresu podglądu.");
        if(!window.QRCode) throw new Error("Nie załadowała się biblioteka QR. Sprawdź internet.");
        const host=$("clientQrCode");host.replaceChildren();
        new QRCode(host,{text:link,width:240,height:240,colorDark:"#101b2b",colorLight:"#ffffff",correctLevel:QRCode.CorrectLevel.M});
        $("clientQrLink").textContent=link;
        $("clientQrResult").classList.remove("hidden");
        $("copyClientQrLink").onclick=async()=>{await navigator.clipboard.writeText(link);toast("Skopiowano link klienta.");};
        $("printClientQr").onclick=()=>{const w=window.open("","_blank");if(!w){toast("Zezwól na wyskakujące okna, aby wydrukować QR.");return;}w.document.write("<html><head><title>Kod QR — zlecenie</title><style>body{font-family:Arial;text-align:center;padding:30px}img{width:260px;height:260px}</style></head><body><h2>DWA I CZTERY KOŁA</h2><p>Zeskanuj kod, aby sprawdzić status zlecenia</p>"+host.innerHTML+"<p>"+link+"</p></body></html>");w.document.close();w.focus();w.print();};
        toast("Bezpieczny link klienta utworzony.");
      }catch(e){toast("QR: "+e.message);}
      finally{qrButton.disabled=false;qrButton.textContent=old;}
    };
  }
function decodeAztecRegistrationPayload(raw){
  const clean=String(raw||"").trim().replace(/\s+/g,"");
  if(!clean) throw new Error("Kod Aztec jest pusty.");
  const candidates=[clean,clean.slice(0,-1)];
  let lastError=null;
  for(const candidate of candidates){
    try{
      const binary=atob(candidate.replace(/-/g,"+").replace(/_/g,"/").replace(/[^A-Za-z0-9+/=]/g,""));
      const src=Uint8Array.from(binary,c=>c.charCodeAt(0));
      if(src.length<8) continue;
      const size=(src[0]|(src[1]<<8)|(src[2]<<16)|(src[3]<<24))>>>0;
      if(!size||size>200000) continue;
      const out=new Uint8Array(size);let ip=4,op=0,bit=0,cur=0,lastOffset=1;
      const readBit=()=>{if(ip>=src.length)throw new Error("Niepełne dane");if(bit===0){cur=src[ip++];bit=8;}return (cur>>--bit)&1;};
      const readByte=()=>{if(ip>=src.length)throw new Error("Niepełne dane");return src[ip++];};
      let ended=false,guard=0;
      while(!ended&&op<size&&guard++<size*4){
        while(readBit()===1){if(op>=size)throw new Error("Przekroczony rozmiar");out[op++]=readByte();}
        let off=1;
        while(true){off=off*2+readBit();if(readBit()===1)break;off=(off-1)*2+readBit();if(off>0x100000)throw new Error("Nieprawidłowy offset");}
        let len;
        if(off===2){off=lastOffset;len=readBit();}
        else{off=(off-3)*256+readByte();if(off===1){ended=true;break;}len=(off^1)&1;off=Math.floor(off/2);lastOffset=++off;}
        if(len>0)len=1+readBit();
        else if(readBit()===1)len=3+readBit();
        else{len++;do{len=len*2+readBit();}while(readBit()===0);len+=3;}
        len+=(off>0x500?1:0);
        let pos=op-off;if(pos<0||op+len+1>size)throw new Error("Nieprawidłowe odwołanie danych");
        out[op++]=out[pos++];while(len-->0)out[op++]=out[pos++];
      }
      if(op!==size) throw new Error("Niepełny wynik dekompresji");
      return new TextDecoder("utf-16le").decode(out).replace(/\0+$/g,"");
    }catch(e){lastError=e;}
  }
  throw new Error("Kod został zeskanowany, ale nie udało się odczytać jego zawartości."+(lastError?" ("+lastError.message+")":""));
}
function applyAztecDataToRepairForm(text){
  const fields=String(text||"").split("|").map(v=>v.trim()).filter(Boolean);
  const joined=fields.join(" ");
  const vin=(joined.match(/\b[A-HJ-NPR-Z0-9]{17}\b/i)||[])[0]||"";
  const plate=(joined.match(/\b[A-Z]{2,3}[A-Z0-9]{4,5}\b/i)||[])[0]||"";
  const vinInput=$("editForm")?.elements.namedItem("vin");
  const regInput=$("editForm")?.elements.namedItem("rejestracja");
  if(vin&&vinInput)vinInput.value=vin.toUpperCase();
  if(plate&&regInput)regInput.value=plate.toUpperCase();
  const found=[];if(plate)found.push("rejestracja: "+plate.toUpperCase());if(vin)found.push("VIN: "+vin.toUpperCase());
  return found;
}
const vinScanButton=$("scanVinButton"),vinCameraInput=$("vinCameraInput");
  const aztecButton=$("scanRegistrationButton"),aztecPanel=$("aztecScannerPanel"),aztecVideo=$("aztecScannerVideo"),aztecStatus=$("aztecScannerStatus"),aztecClose=$("stopAztecScanner");
  let aztecControls=null,aztecReader=null;
  const stopAztec=()=>{try{aztecControls?.stop();}catch(_){}aztecControls=null;try{aztecVideo?.srcObject?.getTracks?.().forEach(t=>t.stop());}catch(_){}if(aztecVideo)aztecVideo.srcObject=null;aztecPanel?.classList.add("hidden");};
  if(aztecButton&&aztecPanel&&aztecVideo){
    aztecButton.onclick=async()=>{
      if(!window.ZXingBrowser?.BrowserAztecCodeReader){toast("Nie załadował się moduł skanera. Sprawdź połączenie z Internetem.");return;}
      aztecButton.disabled=true;aztecPanel.classList.remove("hidden");aztecStatus.textContent="Uruchamiam aparat. Skieruj go na kod Aztec w dowodzie…";
      try{
        aztecReader=new ZXingBrowser.BrowserAztecCodeReader();
        aztecControls=await aztecReader.decodeFromConstraints({audio:false,video:{facingMode:{ideal:"environment"}}},aztecVideo,(result,error,controls)=>{
          if(!result)return;
          const raw=result.getText();
          controls?.stop();aztecControls=null;
          try{aztecVideo.srcObject?.getTracks?.().forEach(t=>t.stop());}catch(_){}
          aztecPanel.classList.add("hidden");
          try{
            const decoded=decodeAztecRegistrationPayload(raw);
            const found=applyAztecDataToRepairForm(decoded);
            $("aztecRawData").value=decoded;
            $("aztecReadSummary").textContent=found.length?"Wstępnie rozpoznano: "+found.join(" • ")+". Sprawdź pola formularza. Pozostałe pola wymagają potwierdzenia mapowania formatu.":"Kod odczytany i zdekompresowany. Nie rozpoznano automatycznie numeru rejestracyjnego ani VIN — sprawdź surowe dane.";
            $("aztecReadResult").classList.remove("hidden");
            toast("Odczytano kod Aztec. Sprawdź dane przed zapisem.");
          }catch(e){aztecStatus.textContent=e.message;toast(e.message);}
        });
      }catch(e){stopAztec();aztecStatus.textContent="Nie udało się uruchomić aparatu: "+e.message;toast(aztecStatus.textContent);}
      finally{aztecButton.disabled=false;}
    };
    aztecClose.onclick=stopAztec;
  }
  if(vinScanButton&&vinCameraInput){
    vinScanButton.onclick=()=>vinCameraInput.click();
    vinCameraInput.onchange=async()=>{
      const file=vinCameraInput.files?.[0];if(!file)return;
      const status=$("vinScanStatus"),input=$("editForm").elements.namedItem("vin");
      vinScanButton.disabled=true;vinScanButton.textContent="Odczytywanie VIN…";
      if(status)status.textContent="Analizuję zdjęcie…";
      try{input.value=await recognizeVinFromImage(file);if(status)status.textContent="Sprawdź odczytany VIN przed zapisem.";toast("Odczytano VIN — sprawdź go przed zapisem.");}
      catch(e){if(status)status.textContent=e.message;toast(e.message);}
      finally{vinScanButton.disabled=false;vinScanButton.textContent="📷 Skanuj VIN aparatem";vinCameraInput.value="";}
    };
  }
  $("takeRepairPhoto").onclick=()=>cameraInput?.click();
  $("chooseRepairPhotos").onclick=()=>galleryInput?.click();
  showRepairPhotos(existingPhotos);
}
$("saveRecord").onclick=()=>{};
$("updateAppButton").onclick=installAvailableAppUpdate;
$("checkAppUpdateButton").onclick=()=>checkForAppUpdate(true);
init();
checkForAppUpdate();
window.addEventListener("focus",checkForAppUpdate);
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js"));


// ===== SYSTEMOWA BLOKADA ANDROIDA =====
(()=>{
 const el=id=>document.getElementById(id);
 const isNative=()=>!!(window.Capacitor?.isNativePlatform?.());
 const security=()=>isNative()?window.Capacitor.registerPlugin("Security"):null;
 let lockReady=false,locked=false,backgrounded=false,authBusy=false;
 const showLock=(message)=>{
   const panel=el("securityLock"); if(!panel||locked)return;
   locked=true; panel.classList.remove("hidden");
   el("securityLockHint").textContent=message||"Potwierdź tożsamość blokadą ustawioną w telefonie.";
   el("securityLockError").textContent="";
   document.body.style.overflow="hidden";
 };
 const hideLock=()=>{
   locked=false;el("securityLock").classList.add("hidden");
   document.body.style.overflow="";
 };
 const status=async()=>{
   const p=security(); if(!p)throw Error("Zabezpieczenia systemowe są dostępne w aplikacji Android.");
   return await p.getDeviceSecurityStatus();
 };
 const unlock=async()=>{
   if(authBusy)return;authBusy=true;
   const btn=el("securityUnlockButton");if(btn){btn.disabled=true;btn.textContent="Oczekiwanie na potwierdzenie…";}
   try{
     const p=security();if(!p)throw Error("Zabezpieczenia systemowe są dostępne w aplikacji Android.");
     const st=await p.getDeviceSecurityStatus();
     if(!st.deviceSecure){
       el("securityLockError").textContent="W telefonie nie ma ustawionej blokady ekranu. Ustaw PIN, wzór lub hasło Androida.";
       await p.openDeviceSecuritySettings();return;
     }
     const result=await p.authenticateDevice();
     if(result?.success)hideLock();
     else throw Error("Nie udało się potwierdzić tożsamości.");
   }catch(e){el("securityLockError").textContent=e?.message||"Nie udało się uruchomić zabezpieczenia telefonu.";}
   finally{authBusy=false;if(btn){btn.disabled=false;btn.textContent="Odblokuj telefon";}}
 };
 const openSettings=async()=>{
   try{const p=security();if(!p)throw Error("Ta funkcja działa w aplikacji Android.");await p.openDeviceSecuritySettings();}
   catch(e){el("securitySettingsStatus").textContent=e?.message||"Nie można otworzyć ustawień telefonu.";}
 };
 el("securityUnlockButton").addEventListener("click",unlock);
 el("securityOpenSettings").addEventListener("click",openSettings);
 el("securityOpenSettingsDialog").addEventListener("click",openSettings);
 el("securitySettingsButton").addEventListener("click",async()=>{
   el("securitySettingsDialog").showModal();
   try{const s=await status();el("securitySettingsStatus").textContent=s.deviceSecure?"Blokada ekranu telefonu jest skonfigurowana. Aplikacja używa systemowego PIN-u, wzoru, hasła lub biometrii.":"Nie ustawiono blokady ekranu. Skonfiguruj ją w ustawieniach Androida.";}
   catch(e){el("securitySettingsStatus").textContent=e?.message||"Moduł zabezpieczeń jest niedostępny.";}
 });
 const close=()=>el("securitySettingsDialog").close();
 el("securitySettingsClose").addEventListener("click",close);
 el("securitySettingsDone").addEventListener("click",close);
 document.addEventListener("visibilitychange",()=>{
   if(document.visibilityState==="hidden"&&lockReady){backgrounded=true;showLock("Aplikacja została przeniesiona do tła. Odblokuj ją zabezpieczeniem telefonu.");}
   else if(document.visibilityState==="visible"&&backgrounded&&lockReady){showLock("Wróciłeś do aplikacji. Potwierdź tożsamość zabezpieczeniem telefonu.");backgrounded=false;unlock();}
 });
 window.addEventListener("pagehide",()=>{if(lockReady)showLock("Aplikacja została ukryta. Wymagane ponowne odblokowanie.");});
 const observer=new MutationObserver(()=>{
   const appVisible=!el("app").classList.contains("hidden");
   el("securitySettingsButton").classList.toggle("hidden",!appVisible);
   if(appVisible&&!lockReady){lockReady=true;showLock("Potwierdź tożsamość zabezpieczeniem ustawionym w telefonie.");unlock();}
 });
 observer.observe(el("app"),{attributes:true,attributeFilter:["class"]});
 if(!el("app").classList.contains("hidden")){lockReady=true;showLock("Potwierdź tożsamość zabezpieczeniem ustawionym w telefonie.");unlock();}
})();

