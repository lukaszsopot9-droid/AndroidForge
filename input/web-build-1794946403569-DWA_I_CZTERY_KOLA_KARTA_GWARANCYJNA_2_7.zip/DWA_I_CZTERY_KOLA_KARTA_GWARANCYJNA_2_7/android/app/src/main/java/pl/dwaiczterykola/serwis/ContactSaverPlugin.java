package pl.dwaiczterykola.serwis;

import android.content.Intent;
import android.provider.ContactsContract;
import android.net.Uri;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "ContactSaver")
public class ContactSaverPlugin extends Plugin {
    @PluginMethod
    public void createContact(PluginCall call) {
        String name = call.getString("name", "").trim();
        String phone = call.getString("phone", "").trim();
        if (name.isEmpty() || phone.isEmpty()) {
            call.reject("Brakuje nazwy kontaktu lub numeru telefonu.");
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_INSERT);
            intent.setType(ContactsContract.Contacts.CONTENT_TYPE);
            intent.putExtra(ContactsContract.Intents.Insert.NAME, name);
            intent.putExtra(ContactsContract.Intents.Insert.PHONE, phone);
            intent.putExtra(ContactsContract.Intents.Insert.PHONE_TYPE,
                    ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Nie można otworzyć aplikacji Kontakty.", e);
        }
    }
}
