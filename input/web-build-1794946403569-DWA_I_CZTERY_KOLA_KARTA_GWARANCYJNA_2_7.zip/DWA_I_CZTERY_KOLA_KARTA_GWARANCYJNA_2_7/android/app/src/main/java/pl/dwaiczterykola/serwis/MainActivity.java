package pl.dwaiczterykola.serwis;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        registerPlugin(SmsSenderPlugin.class);
        registerPlugin(AppUpdaterPlugin.class);
        registerPlugin(SecurityPlugin.class);
        registerPlugin(BackupPlugin.class);
        registerPlugin(PrintPdfPlugin.class);
        registerPlugin(ContactSaverPlugin.class);
        super.onCreate(savedInstanceState);
        // Keep Android system bars outside the web content area (status clock, signal and battery).
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        android.view.View webView = getBridge().getWebView();
        if (webView != null) {
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(webView, (view, insets) -> {
                androidx.core.graphics.Insets bars = insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.systemBars()
                );
                view.setPadding(view.getPaddingLeft(), bars.top, view.getPaddingRight(), bars.bottom);
                return insets;
            });
            androidx.core.view.ViewCompat.requestApplyInsets(webView);
        }
    }
}
