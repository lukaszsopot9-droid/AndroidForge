package pl.dwaiczterykola.serwis;

import android.content.Context;
import android.content.Intent;
import android.content.ClipData;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PageRange;
import android.print.PrintManager;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.util.Base64;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

@CapacitorPlugin(name = "PrintPdf")
public class PrintPdfPlugin extends Plugin {

    @PluginMethod
    public void printPdf(PluginCall call) {
        String encoded = call.getString("data");
        String requestedName = call.getString("filename", "Zlecenie_serwisowe.pdf");
        if (encoded == null || encoded.isEmpty()) {
            call.reject("Nie przekazano dokumentu PDF do wydruku.");
            return;
        }

        File pdfFile = null;
        try {
            byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
            if (bytes.length < 8 || bytes[0] != '%' || bytes[1] != 'P'
                    || bytes[2] != 'D' || bytes[3] != 'F') {
                call.reject("Przygotowany dokument nie jest prawidłowym plikiem PDF.");
                return;
            }

            String safeName = requestedName == null ? "Zlecenie_serwisowe.pdf" : requestedName;
            safeName = safeName.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safeName.toLowerCase().endsWith(".pdf")) safeName += ".pdf";

            File directory = new File(getContext().getCacheDir(), "print");
            if (!directory.exists() && !directory.mkdirs()) {
                throw new IOException("Nie można przygotować pliku tymczasowego do wydruku.");
            }
            pdfFile = new File(directory, System.currentTimeMillis() + "_" + safeName);
            try (FileOutputStream output = new FileOutputStream(pdfFile)) {
                output.write(bytes);
                output.flush();
            }

            PrintManager printManager = (PrintManager) getContext().getSystemService(Context.PRINT_SERVICE);
            if (printManager == null) throw new IOException("Usługa drukowania Androida jest niedostępna.");

            PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .build();

            printManager.print(safeName.replaceAll("(?i)\\.pdf$", ""),
                    new PdfFileAdapter(pdfFile, safeName), attributes);

            JSObject result = new JSObject();
            result.put("success", true);
            call.resolve(result);
        } catch (Exception error) {
            if (pdfFile != null && pdfFile.exists()) pdfFile.delete();
            call.reject("Nie udało się otworzyć drukowania: " + error.getMessage(), error);
        }
    }

    @PluginMethod
    public void sharePdf(PluginCall call) {
        String encoded = call.getString("data");
        String requestedName = call.getString("filename", "Zlecenie_serwisowe.pdf");
        String subject = call.getString("subject", "Zlecenie serwisowe");
        String message = call.getString("text", "W załączeniu przesyłamy zlecenie serwisowe.");
        if (encoded == null || encoded.isEmpty()) {
            call.reject("Nie przekazano dokumentu PDF do wysłania.");
            return;
        }

        File pdfFile = null;
        try {
            byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
            if (bytes.length < 8 || bytes[0] != '%' || bytes[1] != 'P'
                    || bytes[2] != 'D' || bytes[3] != 'F') {
                call.reject("Przygotowany dokument nie jest prawidłowym plikiem PDF.");
                return;
            }

            String safeName = requestedName == null ? "Zlecenie_serwisowe.pdf" : requestedName;
            safeName = safeName.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safeName.toLowerCase().endsWith(".pdf")) safeName += ".pdf";

            File directory = new File(getContext().getCacheDir(), "email");
            if (!directory.exists() && !directory.mkdirs()) {
                throw new IOException("Nie można przygotować załącznika do wiadomości.");
            }

            // Usuń stare pliki tymczasowe, aby nie zapełniać pamięci telefonu.
            File[] oldFiles = directory.listFiles();
            if (oldFiles != null) {
                long cutoff = System.currentTimeMillis() - 2L * 24L * 60L * 60L * 1000L;
                for (File oldFile : oldFiles) {
                    if (oldFile.isFile() && oldFile.lastModified() < cutoff) oldFile.delete();
                }
            }

            pdfFile = new File(directory, System.currentTimeMillis() + "_" + safeName);
            try (FileOutputStream output = new FileOutputStream(pdfFile)) {
                output.write(bytes);
                output.flush();
            }

            Uri contentUri = FileProvider.getUriForFile(
                    getContext(),
                    getContext().getPackageName() + ".fileprovider",
                    pdfFile
            );

            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("application/pdf");
            sendIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
            sendIntent.putExtra(Intent.EXTRA_TEXT, message);
            sendIntent.setClipData(ClipData.newUri(
                    getContext().getContentResolver(), safeName, contentUri));
            sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            Intent chooser = Intent.createChooser(sendIntent, "Wyślij zlecenie e-mailem");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);

            JSObject result = new JSObject();
            result.put("success", true);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("Nie udało się przygotować wysyłki e-mail: " + error.getMessage(), error);
        }
    }

    private static class PdfFileAdapter extends PrintDocumentAdapter {
        private final File source;
        private final String name;

        PdfFileAdapter(File source, String name) {
            this.source = source;
            this.name = name;
        }

        @Override
        public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                             CancellationSignal cancellationSignal, LayoutResultCallback callback,
                             android.os.Bundle extras) {
            if (cancellationSignal.isCanceled()) {
                callback.onLayoutCancelled();
                return;
            }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder(name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                    .build();
            callback.onLayoutFinished(info, true);
        }

        @Override
        public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                            CancellationSignal cancellationSignal, WriteResultCallback callback) {
            try (FileInputStream input = new FileInputStream(source);
                 FileOutputStream output = new FileOutputStream(destination.getFileDescriptor())) {
                byte[] buffer = new byte[16 * 1024];
                int count;
                while ((count = input.read(buffer)) >= 0) {
                    if (cancellationSignal.isCanceled()) {
                        callback.onWriteCancelled();
                        return;
                    }
                    output.write(buffer, 0, count);
                }
                output.flush();
                callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (IOException error) {
                callback.onWriteFailed(error.getMessage());
            } finally {
                try { destination.close(); } catch (IOException ignored) { }
            }
        }

        @Override
        public void onFinish() {
            if (source.exists()) source.delete();
            super.onFinish();
        }
    }
}
