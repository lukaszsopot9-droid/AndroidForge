package pl.dwaiczterykola.serwis;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.activity.result.ActivityResult;
import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.concurrent.Executor;

@CapacitorPlugin(name = "Security")
public class SecurityPlugin extends Plugin {

    @PluginMethod
    public void getDeviceSecurityStatus(PluginCall call) {
        KeyguardManager keyguard = (KeyguardManager) getContext().getSystemService(Context.KEYGUARD_SERVICE);
        boolean secure = keyguard != null && keyguard.isDeviceSecure();
        int biometric = BiometricManager.from(getContext()).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        );

        JSObject result = new JSObject();
        result.put("deviceSecure", secure);
        result.put("biometricAvailable", biometric == BiometricManager.BIOMETRIC_SUCCESS);
        result.put("canAuthenticate", secure || biometric == BiometricManager.BIOMETRIC_SUCCESS);
        call.resolve(result);
    }

    @PluginMethod
    public void openDeviceSecuritySettings(PluginCall call) {
        try {
            Intent intent = new Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Nie można otworzyć ustawień zabezpieczeń Androida.", e);
        }
    }

    @PluginMethod
    public void authenticateDevice(PluginCall call) {
        KeyguardManager keyguard = (KeyguardManager) getContext().getSystemService(Context.KEYGUARD_SERVICE);
        boolean secure = keyguard != null && keyguard.isDeviceSecure();
        if (!secure) {
            call.reject("Najpierw ustaw blokadę ekranu telefonu: PIN, wzór lub hasło.");
            return;
        }

        // BiometricPrompt uses FragmentManager internally. Constructing it and calling
        // authenticate() must happen on the Activity's main/UI thread, not Capacitor's worker thread.
        getActivity().runOnUiThread(() -> {
            try {
                Executor executor = ContextCompat.getMainExecutor(getContext());
                BiometricManager manager = BiometricManager.from(getContext());
                boolean biometricAvailable = manager.canAuthenticate(
                    BiometricManager.Authenticators.BIOMETRIC_WEAK
                ) == BiometricManager.BIOMETRIC_SUCCESS;

                BiometricPrompt.AuthenticationCallback callback = new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult authResult) {
                        JSObject result = new JSObject();
                        result.put("success", true);
                        result.put("method", Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ? "system" : "biometric");
                        call.resolve(result);
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R
                            && errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                            launchLegacyDeviceCredential(call);
                        } else {
                            call.reject(errString.toString());
                        }
                    }
                };

                BiometricPrompt prompt = new BiometricPrompt(getActivity(), executor, callback);
                BiometricPrompt.PromptInfo.Builder builder = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Odblokuj DWA I CZTERY KOŁA")
                    .setSubtitle("Użyj odcisku palca lub blokady ekranu telefonu");

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    builder.setAllowedAuthenticators(
                        BiometricManager.Authenticators.BIOMETRIC_WEAK
                            | BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    );
                } else if (biometricAvailable) {
                    builder.setNegativeButtonText("Użyj PIN-u / wzoru telefonu")
                        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK);
                } else {
                    launchLegacyDeviceCredential(call);
                    return;
                }

                prompt.authenticate(builder.build());
            } catch (Exception e) {
                call.reject("Nie udało się uruchomić systemowego uwierzytelniania Androida.", e);
            }
        });
    }

    private void launchLegacyDeviceCredential(PluginCall call) {
        // This method is called from the main thread (including from the biometric callback).
        KeyguardManager keyguard = (KeyguardManager) getContext().getSystemService(Context.KEYGUARD_SERVICE);
        Intent intent = keyguard != null ? keyguard.createConfirmDeviceCredentialIntent(
            "Odblokuj DWA I CZTERY KOŁA",
            "Potwierdź blokadą ekranu telefonu"
        ) : null;

        if (intent == null) {
            call.reject("System nie udostępnia potwierdzenia blokady urządzenia.");
            return;
        }
        startActivityForResult(call, intent, "deviceCredentialResult");
    }

    @ActivityCallback
    private void deviceCredentialResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() == android.app.Activity.RESULT_OK) {
            JSObject response = new JSObject();
            response.put("success", true);
            response.put("method", "device-credential");
            call.resolve(response);
        } else {
            call.reject("Nie potwierdzono blokady ekranu urządzenia.");
        }
    }
}
