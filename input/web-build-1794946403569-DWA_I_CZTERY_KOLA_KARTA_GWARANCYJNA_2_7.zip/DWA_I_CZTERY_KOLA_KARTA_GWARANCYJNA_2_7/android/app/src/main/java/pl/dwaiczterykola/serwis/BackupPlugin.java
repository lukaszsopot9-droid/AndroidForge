package pl.dwaiczterykola.serwis;

import android.content.Intent;
import android.util.Base64;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.security.Key;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

@CapacitorPlugin(name = "Backup")
public class BackupPlugin extends Plugin {

    private static final String KEY_ALIAS = "DWA_I_CZTERY_KOLA_BACKUP_KEY";
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final byte[] MAGIC = new byte[] {
        'D', '4', 'K', 'B', 'A', 'C', 'K', '1'
    };
    private static final int IV_LENGTH = 12;
    private static final int TAG_LENGTH = 128;
    private ZipOutputStream activeZip;
    private File activeZipFile;
    private String activeEntryName;

    @PluginMethod
    public void chooseSaveLocation(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        intent.putExtra(
            Intent.EXTRA_TITLE,
            "Kopia_DWA_I_CZTERY_KOLA.zip"
        );

        startActivityForResult(call, intent, "saveLocationResult");
    }

    @ActivityCallback
    private void saveLocationResult(PluginCall call, ActivityResult result) {
        if (call == null) return;

        if (result.getResultCode() != android.app.Activity.RESULT_OK
            || result.getData() == null
            || result.getData().getData() == null) {
            JSObject response = new JSObject();
            response.put("cancelled", true);
            call.resolve(response);
            return;
        }

        JSObject response = new JSObject();
        response.put("cancelled", false);
        response.put("uri", result.getData().getData().toString());
        call.resolve(response);
    }

    @PluginMethod
    public void choosePdfSaveLocation(PluginCall call) {
        String filename = call.getString("filename", "Zlecenie_serwisowe.pdf");
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(call, intent, "pdfSaveLocationResult");
    }

    @ActivityCallback
    private void pdfSaveLocationResult(PluginCall call, ActivityResult result) {
        if (call == null) return;

        if (result.getResultCode() != android.app.Activity.RESULT_OK
            || result.getData() == null
            || result.getData().getData() == null) {
            JSObject response = new JSObject();
            response.put("cancelled", true);
            call.resolve(response);
            return;
        }

        JSObject response = new JSObject();
        response.put("cancelled", false);
        response.put("uri", result.getData().getData().toString());
        call.resolve(response);
    }

    @PluginMethod
    public void savePdfToUri(PluginCall call) {
        String uriValue = call.getString("uri");
        String data = call.getString("data");

        if (uriValue == null || uriValue.trim().isEmpty()
            || data == null || data.isEmpty()) {
            call.reject("Nie przekazano pliku PDF lub miejsca zapisu.");
            return;
        }

        try {
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            Uri uri = Uri.parse(uriValue);

            try (OutputStream output = getContext().getContentResolver()
                    .openOutputStream(uri, "w")) {
                if (output == null) {
                    call.reject("Nie udało się otworzyć pliku do zapisu.");
                    return;
                }
                output.write(bytes);
                output.flush();
            }

            JSObject response = new JSObject();
            response.put("success", true);
            call.resolve(response);
        } catch (Exception e) {
            call.reject("Nie udało się zapisać pliku PDF.", e);
        }
    }
    @PluginMethod
    public void chooseBackupFile(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");

        startActivityForResult(call, intent, "openBackupResult");
    }

    @ActivityCallback
    private void openBackupResult(PluginCall call, ActivityResult result) {
        if (call == null) return;

        if (result.getResultCode() != android.app.Activity.RESULT_OK
            || result.getData() == null
            || result.getData().getData() == null) {
            JSObject response = new JSObject();
            response.put("cancelled", true);
            call.resolve(response);
            return;
        }

        Uri uri = result.getData().getData();

        int grantedFlags = result.getData().getFlags()
            & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

        if ((grantedFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
            try {
                getContext().getContentResolver().takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (SecurityException ignored) {
                // Plik może być nadal dostępny w ramach bieżącego uprawnienia.
            }
        }

        JSObject response = new JSObject();
        response.put("cancelled", false);
        response.put("uri", uri.toString());
        call.resolve(response);
    }

    @PluginMethod
    public void getCacheDirectory(PluginCall call) {
        JSObject response = new JSObject();
        response.put("path", getContext().getCacheDir().getAbsolutePath());
        call.resolve(response);
    }

    @PluginMethod
    public void encryptFileToUri(PluginCall call) {
        String sourcePath = call.getString("sourcePath");
        String destinationUri = call.getString("destinationUri");

        if (sourcePath == null || destinationUri == null) {
            call.reject("Brakuje ścieżki pliku lub miejsca zapisu kopii.");
            return;
        }

        File source = new File(sourcePath);
        if (!source.isFile()) {
            call.reject("Nie znaleziono pliku przeznaczonego do zaszyfrowania.");
            return;
        }

        try {
            SecretKey key = getOrCreateKey();

            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, key);

            byte[] iv = cipher.getIV();
            Uri uri = Uri.parse(destinationUri);

            try (
                InputStream input = new FileInputStream(source);
                OutputStream output = getContext()
                    .getContentResolver()
                    .openOutputStream(uri, "w")
            ) {
                if (output == null) {
                    throw new IllegalStateException(
                        "Nie można otworzyć wybranego miejsca zapisu."
                    );
                }

                DataOutputStream header = new DataOutputStream(output);
                header.write(MAGIC);
                header.writeInt(iv.length);
                header.write(iv);
                header.flush();

                try (CipherOutputStream encrypted =
                    new CipherOutputStream(output, cipher)) {
                    copyStream(input, encrypted);
                }
            }

            JSObject response = new JSObject();
            response.put("success", true);
            call.resolve(response);

        } catch (Exception e) {
            call.reject("Nie udało się zaszyfrować kopii zapasowej.", e);
        }
    }

    @PluginMethod
    public void decryptBackupToCache(PluginCall call) {
        String sourceUri = call.getString("sourceUri");

        if (sourceUri == null) {
            call.reject("Nie wskazano pliku kopii zapasowej.");
            return;
        }

        File destination = new File(
            getContext().getCacheDir(),
            "backup_" + UUID.randomUUID() + ".zip"
        );

        try (
            InputStream input = getContext()
                .getContentResolver()
                .openInputStream(Uri.parse(sourceUri))
        ) {
            if (input == null) {
                throw new IllegalStateException(
                    "Nie można odczytać wybranego pliku."
                );
            }

            DataInputStream header = new DataInputStream(input);

            byte[] magic = new byte[MAGIC.length];
            header.readFully(magic);

            for (int i = 0; i < MAGIC.length; i++) {
                if (magic[i] != MAGIC[i]) {
                    throw new IllegalArgumentException(
                        "Wybrany plik nie jest prawidłową kopią DWA I CZTERY KOŁA."
                    );
                }
            }

            int ivLength = header.readInt();

            if (ivLength != IV_LENGTH) {
                throw new IllegalArgumentException(
                    "Nieprawidłowy nagłówek zaszyfrowanej kopii."
                );
            }

            byte[] iv = new byte[ivLength];
            header.readFully(iv);

            SecretKey key = getExistingKey();

            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(
                Cipher.DECRYPT_MODE,
                key,
                new GCMParameterSpec(TAG_LENGTH, iv)
            );

            try (OutputStream output = new FileOutputStream(destination)) {
                byte[] encryptedBuffer = new byte[8192];
                int encryptedCount;

                while ((encryptedCount = input.read(encryptedBuffer)) != -1) {
                    byte[] plainChunk = cipher.update(
                        encryptedBuffer, 0, encryptedCount
                    );

                    if (plainChunk != null && plainChunk.length > 0) {
                        output.write(plainChunk);
                    }
                }

                // Weryfikacja znacznika AES-GCM przed uznaniem kopii za poprawną.
                byte[] finalChunk = cipher.doFinal();

                if (finalChunk != null && finalChunk.length > 0) {
                    output.write(finalChunk);
                }

                output.flush();
            }

            JSObject response = new JSObject();
            response.put("success", true);
            response.put("filePath", destination.getAbsolutePath());
            call.resolve(response);

        } catch (Exception e) {
            if (destination.exists()) {
                destination.delete();
            }
            call.reject(
                "Nie udało się odszyfrować kopii. Sprawdź plik i klucz urządzenia.",
                e
            );
        }
    }


    @PluginMethod
    public void beginBackupArchive(PluginCall call) {
        if (activeZip != null) {
            call.reject("Archiwum kopii zapasowej jest już otwarte.");
            return;
        }

        File candidate = new File(
            getContext().getCacheDir(),
            "backup_export_" + UUID.randomUUID() + ".zip"
        );

        try {
            ZipOutputStream zip = new ZipOutputStream(
                new BufferedOutputStream(new FileOutputStream(candidate))
            );

            activeZipFile = candidate;
            activeZip = zip;
            activeEntryName = null;

            JSObject response = new JSObject();
            response.put("success", true);
            response.put("filePath", candidate.getAbsolutePath());
            call.resolve(response);
        } catch (Exception e) {
            candidate.delete();
            call.reject("Nie udało się rozpocząć tworzenia archiwum ZIP.", e);
        }
    }

    @PluginMethod
    public void beginBackupEntry(PluginCall call) {
        String entryName = call.getString("entryName");

        if (activeZip == null) {
            call.reject("Archiwum ZIP nie zostało rozpoczęte.");
            return;
        }

        if (activeEntryName != null) {
            call.reject("Poprzedni plik w archiwum nie został zamknięty.");
            return;
        }

        if (entryName == null || entryName.trim().isEmpty()) {
            call.reject("Nie podano nazwy pliku w archiwum.");
            return;
        }

        String normalized = entryName.replace('\\', '/');

        if (normalized.startsWith("/") || normalized.matches("^[A-Za-z]:.*")) {
            call.reject("Nieprawidłowa ścieżka pliku w archiwum.");
            return;
        }

        for (String part : normalized.split("/")) {
            if ("..".equals(part) || part.isEmpty()) {
                call.reject("Nieprawidłowa ścieżka pliku w archiwum.");
                return;
            }
        }

        try {
            activeZip.putNextEntry(new ZipEntry(normalized));
            activeEntryName = normalized;
            call.resolve();
        } catch (Exception e) {
            call.reject("Nie udało się rozpocząć zapisu pliku ZIP.", e);
        }
    }

    @PluginMethod
    public void writeBackupChunk(PluginCall call) {
        String chunk = call.getString("chunk");

        if (activeZip == null || activeEntryName == null) {
            call.reject("Nie rozpoczęto zapisu pliku w archiwum.");
            return;
        }

        if (chunk == null) {
            call.reject("Brakuje porcji danych do zapisania.");
            return;
        }

        try {
            byte[] bytes = Base64.decode(chunk, Base64.DEFAULT);

            if (bytes.length > 262144) {
                call.reject("Porcja danych jest zbyt duża.");
                return;
            }

            activeZip.write(bytes);
            call.resolve();
        } catch (Exception e) {
            call.reject("Nie udało się zapisać porcji danych w ZIP.", e);
        }
    }

    @PluginMethod
    public void endBackupEntry(PluginCall call) {
        if (activeZip == null || activeEntryName == null) {
            call.reject("Nie ma otwartego pliku w archiwum.");
            return;
        }

        try {
            activeZip.closeEntry();
            activeEntryName = null;
            call.resolve();
        } catch (Exception e) {
            call.reject("Nie udało się zamknąć pliku w archiwum.", e);
        }
    }

    @PluginMethod
    public void finishBackupArchive(PluginCall call) {
        if (activeZip == null || activeZipFile == null) {
            call.reject("Nie rozpoczęto tworzenia archiwum ZIP.");
            return;
        }

        if (activeEntryName != null) {
            call.reject("Przed zamknięciem ZIP trzeba zamknąć ostatni plik.");
            return;
        }

        File finishedFile = activeZipFile;

        try {
            activeZip.close();
            activeZip = null;
            activeZipFile = null;
            activeEntryName = null;

            JSObject response = new JSObject();
            response.put("success", true);
            response.put("filePath", finishedFile.getAbsolutePath());
            call.resolve(response);
        } catch (Exception e) {
            activeZip = null;
            activeZipFile = null;
            activeEntryName = null;
            finishedFile.delete();
            call.reject("Nie udało się prawidłowo zamknąć archiwum ZIP.", e);
        }
    }

    @PluginMethod
    public void abortBackupArchive(PluginCall call) {
        File temporaryFile = activeZipFile;

        try {
            if (activeZip != null) {
                activeZip.close();
            }
        } catch (Exception ignored) {
            // Plik tymczasowy zostanie usunięty poniżej.
        }

        activeZip = null;
        activeZipFile = null;
        activeEntryName = null;

        if (temporaryFile != null && temporaryFile.exists()) {
            temporaryFile.delete();
        }

        JSObject response = new JSObject();
        response.put("success", true);
        call.resolve(response);
    }
    @PluginMethod
    public void deleteTemporaryBackupFile(PluginCall call) {
        String filePath = call.getString("filePath");

        if (filePath == null || filePath.trim().isEmpty()) {
            call.reject("Nie wskazano pliku tymczasowego.");
            return;
        }

        try {
            File cacheDirectory = getContext().getCacheDir().getCanonicalFile();
            File candidate = new File(filePath).getCanonicalFile();
            File parent = candidate.getParentFile();

            if (parent == null
                || !parent.equals(cacheDirectory)
                || !candidate.getName().startsWith("backup_export_")
                || !candidate.getName().endsWith(".zip")) {
                call.reject("Odmowa usunięcia pliku spoza dozwolonego zakresu.");
                return;
            }

            if (candidate.exists() && !candidate.delete()) {
                call.reject("Nie udało się usunąć tymczasowego archiwum.");
                return;
            }

            JSObject response = new JSObject();
            response.put("success", true);
            call.resolve(response);
        } catch (Exception e) {
            call.reject("Nie udało się bezpiecznie usunąć pliku tymczasowego.", e);
        }
    }
    private SecretKey getExistingKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(KEYSTORE);
        keyStore.load(null);

        Key existing = keyStore.getKey(KEY_ALIAS, null);

        if (!(existing instanceof SecretKey)) {
            throw new IllegalStateException(
                "Brak klucza szyfrującego. Tej kopii nie można odszyfrować na tym urządzeniu."
            );
        }

        return (SecretKey) existing;
    }
    private SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(KEYSTORE);
        keyStore.load(null);

        Key existing = keyStore.getKey(KEY_ALIAS, null);

        if (existing instanceof SecretKey) {
            return (SecretKey) existing;
        }

        KeyGenerator generator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            KEYSTORE
        );

        generator.init(
            new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT
                    | KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(
                    KeyProperties.ENCRYPTION_PADDING_NONE
                )
                .setRandomizedEncryptionRequired(true)
                .setKeySize(256)
                .build()
        );

        return generator.generateKey();
    }

    private void copyStream(InputStream input, OutputStream output)
        throws Exception {

        byte[] buffer = new byte[8192];
        int count;

        while ((count = input.read(buffer)) != -1) {
            output.write(buffer, 0, count);
        }

        output.flush();
    }
}