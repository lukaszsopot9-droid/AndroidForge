
package pl.dwaiczterykola.serwis;

import android.content.Intent;
import android.net.Uri;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "SmsSender")
public class SmsSenderPlugin extends Plugin {

    @PluginMethod
    public void send(PluginCall call) {
        String phone = call.getString("phone", "");
        String message = call.getString("message", "");

        if (phone.trim().isEmpty() || message.trim().isEmpty()) {
            call.reject("Brak numeru telefonu lub treści SMS.");
            return;
        }

        try {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.fromParts("smsto", phone, null));
            intent.putExtra("sms_body", message);

            getActivity().startActivity(intent);

            call.resolve();

        } catch (Exception e) {
            call.reject("Nie udało się otworzyć aplikacji SMS: "
                    + e.getMessage(), e);
        }
    }
}
