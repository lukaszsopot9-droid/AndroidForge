package pl.dwaiczterykola.serwis;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.database.Cursor;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "AppUpdater")
public class AppUpdaterPlugin extends Plugin {
    private static final String PREFS = "app_updater";
    private static final String KEY_DOWNLOAD_ID = "download_id";
    private static final String APK_MIME_TYPE = "application/vnd.android.package-archive";

    @PluginMethod
    public void getAppInfo(PluginCall call) {
        try {
            PackageInfo info = getContext().getPackageManager()
                .getPackageInfo(getContext().getPackageName(), 0);

            JSObject result = new JSObject();
            result.put("versionCode", Build.VERSION.SDK_INT >= 28
                ? info.getLongVersionCode() : info.versionCode);
            result.put("versionName", info.versionName);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Nie można odczytać wersji aplikacji: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void downloadUpdate(PluginCall call) {
        String url = call.getString("url");
        if (url == null || !url.trim().toLowerCase().startsWith("https://")) {
            call.reject("Nieprawidłowy adres pobierania aktualizacji.");
            return;
        }

        try {
            Context context = getContext();
            DownloadManager manager = (DownloadManager)
                context.getSystemService(Context.DOWNLOAD_SERVICE);

            if (manager == null) {
                call.reject("Usługa pobierania Androida jest niedostępna.");
                return;
            }

            // Usuń poprzednie pobieranie, aby nie sprawdzać starego identyfikatora.
            long previousId = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getLong(KEY_DOWNLOAD_ID, -1L);
            if (previousId >= 0) {
                manager.remove(previousId);
            }

            // Unikalna nazwa zapobiega konfliktowi z poprzednim plikiem APK.
            String fileName = "serwis-update-" + System.currentTimeMillis() + ".apk";

            DownloadManager.Request request =
                new DownloadManager.Request(Uri.parse(url.trim()));
            request.setTitle("Aktualizacja Dwa i Cztery Koła");
            request.setDescription("Pobieranie aktualizacji aplikacji");
            request.setMimeType(APK_MIME_TYPE);
            request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);

            // Zapis do publicznego katalogu Pobrane telefonu.
            request.setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS, fileName);

            long newId = manager.enqueue(request);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putLong(KEY_DOWNLOAD_ID, newId)
                .putString("download_file_name", fileName)
                .apply();

            JSObject result = new JSObject();
            result.put("downloadId", newId);
            result.put("fileName", fileName);
            result.put("destination", "Pobrane");
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Nie udało się rozpocząć pobierania aktualizacji: "
                + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void getDownloadStatus(PluginCall call) {
        JSObject result = new JSObject();
        Context context = getContext();
        long id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_DOWNLOAD_ID, -1L);

        if (id < 0) {
            result.put("status", "none");
            call.resolve(result);
            return;
        }

        try {
            DownloadManager manager = (DownloadManager)
                context.getSystemService(Context.DOWNLOAD_SERVICE);
            if (manager == null) {
                result.put("status", "failed");
                result.put("error", "Usługa pobierania Androida jest niedostępna.");
                call.resolve(result);
                return;
            }

            DownloadManager.Query query = new DownloadManager.Query().setFilterById(id);
            try (Cursor cursor = manager.query(query)) {
                if (cursor == null || !cursor.moveToFirst()) {
                    result.put("status", "failed");
                    result.put("error", "Nie znaleziono pobierania aktualizacji.");
                } else {
                    int status = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));

                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        result.put("status", "successful");
                        String fileName = context.getSharedPreferences(
                            PREFS, Context.MODE_PRIVATE)
                            .getString("download_file_name", "");
                        result.put("fileName", fileName);
                    } else if (status == DownloadManager.STATUS_PENDING
                            || status == DownloadManager.STATUS_RUNNING
                            || status == DownloadManager.STATUS_PAUSED) {
                        result.put("status", "running");
                        if (status == DownloadManager.STATUS_PAUSED) {
                            int reason = cursor.getInt(cursor.getColumnIndexOrThrow(
                                DownloadManager.COLUMN_REASON));
                            result.put("reason", reason);
                        }
                    } else {
                        result.put("status", "failed");
                        int reason = cursor.getInt(cursor.getColumnIndexOrThrow(
                            DownloadManager.COLUMN_REASON));
                        result.put("reason", reason);
                        result.put("error", "Android nie ukończył pobierania. Kod błędu: "
                            + reason);
                    }
                }
            }
        } catch (Exception e) {
            result.put("status", "failed");
            result.put("error", "Nie udało się sprawdzić pobierania: " + e.getMessage());
        }

        call.resolve(result);
    }

    @PluginMethod
    public void installDownloadedUpdate(PluginCall call) {
        try {
            Context context = getContext();
            long id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getLong(KEY_DOWNLOAD_ID, -1L);

            if (id < 0) {
                call.reject("Brak pobranej aktualizacji. Najpierw pobierz plik APK.");
                return;
            }

            DownloadManager manager = (DownloadManager)
                context.getSystemService(Context.DOWNLOAD_SERVICE);
            if (manager == null) {
                call.reject("Usługa pobierania Androida jest niedostępna.");
                return;
            }

            Uri apkUri = manager.getUriForDownloadedFile(id);
            if (apkUri == null) {
                call.reject("Plik APK nie został jeszcze pobrany. Sprawdź folder Pobrane.");
                return;
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    && !context.getPackageManager().canRequestPackageInstalls()) {
                Intent settings = new Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + context.getPackageName()));
                settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(settings);

                JSObject result = new JSObject();
                result.put("needsPermission", true);
                call.resolve(result);
                return;
            }

            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(apkUri, APK_MIME_TYPE);
            install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(install);

            JSObject result = new JSObject();
            result.put("needsPermission", false);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Nie udało się otworzyć instalatora Androida: "
                + e.getMessage(), e);
        }
    }
}
